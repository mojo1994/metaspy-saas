"use strict";

/* ================================================================
   MetaSpy Floating Widget (F2)
   Widget flutuante, arrastavel e persistente na Biblioteca de
   Anuncios do Meta. Substitui/absorve a antiga #metaspy-topbar.

   Depende do scan compartilhado exposto pelo content-script.js
   em window.MetaSpyScan (nao duplica a logica de varredura).
   ================================================================ */

(function iniciarWidgetMetaSpy() {
  const WIDGET_ID = "metaspy-widget";
  const CHAVE = "metaspy_widget";
  const CHAVE_BIBLIOTECA = "bibliotecaPalavrasChave";

  if (window.__metaspyWidgetIniciado) return;
  window.__metaspyWidgetIniciado = true;
  if (document.getElementById(WIDGET_ID)) return;

  let estado = {
    posicao: { x: 16, y: 120 },
    minimizado: false,
    diasMin: 30,
    copiasMin: 5
  };

  let escaneando = false;
  let sinalParada = false;

  /* Auto-scan: destaca sozinho quando a biblioteca monta/atualiza resultados. */
  let autoScanTimer = null;
  let autoEscaneadoParaUrl = "";
  let ultimaContagemScan = 0;

  async function carregarEstado() {
    try {
      const dados = await chrome.storage.local.get([CHAVE]);
      if (dados && dados[CHAVE]) {
        estado = {
          ...estado,
          ...dados[CHAVE],
          posicao: { ...estado.posicao, ...(dados[CHAVE].posicao || {}) }
        };
      }
    } catch (e) { /* ignore */ }
  }

  function salvarEstado(parcial) {
    estado = { ...estado, ...parcial };
    chrome.storage.local.set({ [CHAVE]: estado }).catch(() => {});
  }

  function getScan() {
    return window.MetaSpyScan || null;
  }

  /* ─── ICONES SVG (sem emojis) ─────────────────────── */

  function criarIconeSVG(d) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "2");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");
    svg.setAttribute("aria-hidden", "true");
    svg.innerHTML = d;
    return svg;
  }

  /* ─── CSS ─────────────────────────────────────────── */

  function criarEstilos() {
    const css = document.createElement("style");
    css.id = "metaspy-widget-css";
    css.textContent = [
      "#" + WIDGET_ID + " * { margin:0; padding:0; box-sizing:border-box; }",
      "#" + WIDGET_ID + " { all:initial; position:fixed; z-index:999996; font-family:system-ui,sans-serif; }",
      "#" + WIDGET_ID + " .ms-w-badge { display:flex; align-items:center; gap:8px; padding:9px 14px; background:#111116; border:1px solid rgba(139,92,246,0.35); border-radius:14px; box-shadow:0 6px 24px rgba(0,0,0,0.45), 0 0 20px rgba(139,92,246,0.18); cursor:pointer; user-select:none; }",
      "#" + WIDGET_ID + " .ms-w-badge:hover { border-color:rgba(139,92,246,0.7); }",
      "#" + WIDGET_ID + " .ms-w-badge .ms-w-nome { color:#fff; font-style:italic; font-weight:700; font-size:12px; }",
      "#" + WIDGET_ID + " .ms-w-badge .ms-w-nome span { color:#8b5cf6; }",
      "#" + WIDGET_ID + " .ms-w-badge .ms-w-contador { color:#9ca3af; font-size:11px; white-space:nowrap; }",
      "#" + WIDGET_ID + " .ms-w-badge .ms-w-contador b { color:#34d399; font-weight:700; }",
      "#" + WIDGET_ID + " .ms-w-painel { width:264px; background:rgba(12,12,15,0.96); backdrop-filter:blur(10px); -webkit-backdrop-filter:blur(10px); border:1px solid rgba(139,92,246,0.35); border-radius:16px; box-shadow:0 12px 40px rgba(0,0,0,0.55), 0 0 30px rgba(139,92,246,0.15); overflow:hidden; }",
      "#" + WIDGET_ID + " .ms-w-topo { display:flex; align-items:center; gap:8px; padding:10px 12px; cursor:grab; background:rgba(139,92,246,0.08); border-bottom:1px solid rgba(139,92,246,0.18); }",
      "#" + WIDGET_ID + " .ms-w-topo:active { cursor:grabbing; }",
      "#" + WIDGET_ID + " .ms-w-topo .ms-w-titulo { font-size:12px; font-weight:700; color:#e5e5e5; }",
      "#" + WIDGET_ID + " .ms-w-topo .ms-w-titulo span { color:#8b5cf6; }",
      "#" + WIDGET_ID + " .ms-w-topo .ms-w-min { margin-left:auto; width:22px; height:22px; display:flex; align-items:center; justify-content:center; border:none; border-radius:6px; background:rgba(255,255,255,0.06); color:#9ca3af; cursor:pointer; font-size:12px; }",
      "#" + WIDGET_ID + " .ms-w-topo .ms-w-min svg { width:14px; height:14px; }",
      "#" + WIDGET_ID + " .ms-w-topo .ms-w-min:hover { background:rgba(255,255,255,0.14); color:#fff; }",
      "#" + WIDGET_ID + " .ms-w-corpo { padding:12px; display:flex; flex-direction:column; gap:12px; }",
      "#" + WIDGET_ID + " .ms-w-linha { display:flex; flex-direction:column; gap:4px; }",
      "#" + WIDGET_ID + " .ms-w-linha .ms-w-rotulo { display:flex; justify-content:space-between; color:#9ca3af; font-size:11px; }",
      "#" + WIDGET_ID + " .ms-w-linha .ms-w-rotulo b { color:#a78bfa; font-size:12px; }",
      "#" + WIDGET_ID + " .ms-w-linha input[type='range'] { width:100%; accent-color:#8b5cf6; }",
      "#" + WIDGET_ID + " .ms-w-chips { display:flex; flex-wrap:wrap; gap:5px; }",
      "#" + WIDGET_ID + " .ms-w-chip { padding:4px 9px; border-radius:999px; border:1px solid rgba(139,92,246,0.3); background:rgba(139,92,246,0.08); color:#c4b5fd; font-size:10px; cursor:pointer; transition:all 0.12s; }",
      "#" + WIDGET_ID + " .ms-w-chip:hover { background:#7c3aed; color:#fff; border-color:#7c3aed; }",
      "#" + WIDGET_ID + " .ms-w-botoes { display:flex; gap:6px; }",
      "#" + WIDGET_ID + " .ms-w-botoes button { flex:0 0 auto; padding:8px 10px; border:none; border-radius:9px; font-size:12px; font-weight:600; cursor:pointer; transition:all 0.15s; display:inline-flex; align-items:center; justify-content:center; gap:6px; }",
      "#" + WIDGET_ID + " .ms-w-botoes svg { width:14px; height:14px; flex-shrink:0; }",
      "#" + WIDGET_ID + " .ms-w-escanear { background:#7c3aed; color:#fff; }",
      "#" + WIDGET_ID + " .ms-w-escanear:hover { box-shadow:0 0 18px rgba(139,92,246,0.45); }",
      "#" + WIDGET_ID + " .ms-w-escanear:disabled { opacity:0.5; cursor:default; box-shadow:none; }",
      "#" + WIDGET_ID + " .ms-w-parar { background:rgba(255,32,32,0.15); color:#ff6b6b; border:1px solid rgba(255,32,32,0.3); }",
      "#" + WIDGET_ID + " .ms-w-parar:hover { background:#ff2020; color:#fff; }",
      "#" + WIDGET_ID + " .ms-w-status { font-size:10px; color:#9ca3af; text-align:center; min-height:14px; }",
      "#" + WIDGET_ID + " .ms-w-status b { color:#34d399; }",
      "#" + WIDGET_ID + " .ms-w-resultados { display:flex; flex-direction:column; gap:5px; max-height:170px; overflow-y:auto; border-top:1px solid rgba(139,92,246,0.15); padding-top:8px; }",
      "#" + WIDGET_ID + " .ms-w-resultado-item { width:100%; display:flex; align-items:center; gap:7px; text-align:left; padding:6px 8px; border:1px solid rgba(139,92,246,0.18); border-radius:8px; background:rgba(139,92,246,0.05); color:#d6d3e0; font-size:10px; cursor:pointer; transition:all 0.12s; font-family:system-ui,sans-serif; }",
      "#" + WIDGET_ID + " .ms-w-resultado-item:hover { background:rgba(139,92,246,0.16); border-color:#7c3aed; }",
      "#" + WIDGET_ID + " .ms-w-resultado-item svg { width:12px; height:12px; flex-shrink:0; color:#8b5cf6; }",
      "#" + WIDGET_ID + " .ms-w-resultado-item .ms-w-ri-txt { flex:1; min-width:0; }",
      "#" + WIDGET_ID + " .ms-w-resultado-item b { display:block; color:#e5e5e5; font-size:10px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }",
      "#" + WIDGET_ID + " .ms-w-resultado-item span { display:block; color:#9ca3af; font-size:9px; line-height:1.35; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }",
      "#" + WIDGET_ID + " .ms-grid { display:inline-grid; grid-template-columns:repeat(3,4px); grid-template-rows:repeat(3,4px); gap:1px; }",
      "#" + WIDGET_ID + " .ms-grid div { background:#8b5cf6; border-radius:1px; animation:msWBanter 4s infinite; }",
      "@keyframes msWBanter { 0%,100% { transform:translate(0,0); } 33% { transform:translate(2px,2px); } 66% { transform:translate(-2px,-2px); } }"
    ].join("\n");
    return css;
  }

  /* ─── DOM ─────────────────────────────────────────── */

  let root, painelEl, badgeEl, contadorEl, sliderDias, valorDias, sliderCopias, valorCopias, btnScan, rotuloScan, btnParar, statusEl, resultadosEl;

  function montarWidget() {
    root = document.createElement("div");
    root.id = WIDGET_ID;
    root.appendChild(criarEstilos());

    /* Badge (estado minimizado) */
    badgeEl = document.createElement("div");
    badgeEl.className = "ms-w-badge";
    badgeEl.innerHTML =
      '<div class="ms-grid"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>' +
      '<span class="ms-w-nome">Meta<span>Spy</span></span>' +
      '<span class="ms-w-contador"><b id="ms-w-badge-cont">0</b> ofertas</span>';
    contadorEl = badgeEl.querySelector("#ms-w-badge-cont");
    badgeEl.addEventListener("click", () => setMinimizado(false));
    root.appendChild(badgeEl);

    /* Painel expandido */
    painelEl = document.createElement("div");
    painelEl.className = "ms-w-painel";
    painelEl.style.display = "none";

    const topo = document.createElement("div");
    topo.className = "ms-w-topo";
    topo.innerHTML =
      '<div class="ms-grid"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>' +
      '<span class="ms-w-titulo">Meta<span>Spy</span> Scan</span>';
    const btnMin = document.createElement("button");
    btnMin.className = "ms-w-min";
    btnMin.title = "Minimizar";
    btnMin.appendChild(criarIconeSVG('<path d="m6 9 6 6 6-6"/>'));
    btnMin.addEventListener("click", (e) => { e.stopPropagation(); setMinimizado(true); });
    topo.appendChild(btnMin);
    painelEl.appendChild(topo);

    const corpo = document.createElement("div");
    corpo.className = "ms-w-corpo";

    const linhaDias = document.createElement("div");
    linhaDias.className = "ms-w-linha";
    const rotDias = document.createElement("div");
    rotDias.className = "ms-w-rotulo";
    rotDias.textContent = "Dias mínimos";
    valorDias = document.createElement("b");
    valorDias.textContent = String(estado.diasMin);
    rotDias.appendChild(valorDias);
    sliderDias = document.createElement("input");
    sliderDias.type = "range";
    sliderDias.min = "0";
    sliderDias.max = "3650";
    sliderDias.step = "5";
    sliderDias.value = String(estado.diasMin);
    sliderDias.addEventListener("input", () => {
      valorDias.textContent = sliderDias.value;
      salvarEstado({ diasMin: Number(sliderDias.value) });
    });
    linhaDias.appendChild(rotDias);
    linhaDias.appendChild(sliderDias);
    corpo.appendChild(linhaDias);

    const linhaCopias = document.createElement("div");
    linhaCopias.className = "ms-w-linha";
    const rotCopias = document.createElement("div");
    rotCopias.className = "ms-w-rotulo";
    rotCopias.textContent = "Cópias mínimas";
    valorCopias = document.createElement("b");
    valorCopias.textContent = String(estado.copiasMin);
    rotCopias.appendChild(valorCopias);
    sliderCopias = document.createElement("input");
    sliderCopias.type = "range";
    sliderCopias.min = "1";
    sliderCopias.max = "99";
    sliderCopias.step = "1";
    sliderCopias.value = String(estado.copiasMin);
    sliderCopias.addEventListener("input", () => {
      valorCopias.textContent = sliderCopias.value;
      salvarEstado({ copiasMin: Number(sliderCopias.value) });
    });
    linhaCopias.appendChild(rotCopias);
    linhaCopias.appendChild(sliderCopias);
    corpo.appendChild(linhaCopias);

    /* Chips de palavras-chave (F1) */
    const chipsWrap = document.createElement("div");
    chipsWrap.className = "ms-w-chips";
    carregarChips().then((termos) => {
      termos.slice(0, 5).forEach((termo) => {
        const chip = document.createElement("button");
        chip.className = "ms-w-chip";
        chip.textContent = termo;
        chip.title = "Buscar na Biblioteca por \"" + termo + "\"";
        chip.addEventListener("click", () => buscarTermoNaBiblioteca(termo));
        chipsWrap.appendChild(chip);
      });
    });
    corpo.appendChild(chipsWrap);

    const botoes = document.createElement("div");
    botoes.className = "ms-w-botoes";
    btnScan = document.createElement("button");
    btnScan.className = "ms-w-escanear";
    btnScan.appendChild(criarIconeSVG('<circle cx="12" cy="12" r="10"/><path d="M12 2a10 10 0 0 1 10 10"/><path d="M12 6a6 6 0 0 1 6 6"/>'));
    rotuloScan = document.createElement("span");
    rotuloScan.textContent = "Escanear";
    btnScan.appendChild(rotuloScan);
    btnScan.addEventListener("click", executarEscaneamento);
    btnParar = document.createElement("button");
    btnParar.className = "ms-w-parar";
    btnParar.appendChild(criarIconeSVG('<rect x="6" y="6" width="12" height="12" rx="2"/>'));
    btnParar.appendChild(document.createTextNode("Parar"));
    btnParar.style.display = "none";
    btnParar.addEventListener("click", () => { sinalParada = true; });
    botoes.appendChild(btnScan);
    botoes.appendChild(btnParar);
    corpo.appendChild(botoes);

    const btnDiag = document.createElement("button");
    btnDiag.type = "button";
    btnDiag.className = "ms-w-chip";
    btnDiag.style.padding = "6px 9px";
    btnDiag.style.alignSelf = "flex-start";
    btnDiag.textContent = "Diagnóstico";
    btnDiag.addEventListener("click", executarDiagnostico);
    corpo.appendChild(btnDiag);

    statusEl = document.createElement("div");
    statusEl.className = "ms-w-status";
    statusEl.textContent = "Pronto para escanear.";
    corpo.appendChild(statusEl);

    resultadosEl = document.createElement("div");
    resultadosEl.className = "ms-w-resultados";
    resultadosEl.style.display = "none";
    corpo.appendChild(resultadosEl);

    painelEl.appendChild(corpo);
    root.appendChild(painelEl);

    document.documentElement.appendChild(root);
    aplicarPosicao(estado.posicao, true);
    setMinimizado(estado.minimizado, true);

    configurarArraste(topo);
  }

  function setMinimizado(min, silencioso) {
    estado.minimizado = !!min;
    badgeEl.style.display = min ? "flex" : "none";
    painelEl.style.display = min ? "none" : "block";
    if (!silencioso) salvarEstado({ minimizado: estado.minimizado });
  }

  function aplicarPosicao(pos, semSalvar) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const elAtivo = estado.minimizado ? badgeEl : painelEl;
    const w = elAtivo.getBoundingClientRect().width || 264;
    const h = elAtivo.getBoundingClientRect().height || 80;
    const x = Math.max(8, Math.min(vw - w - 8, pos.x));
    const y = Math.max(8, Math.min(vh - h - 8, pos.y));
    root.style.left = x + "px";
    root.style.top = y + "px";
    if (!semSalvar) salvarEstado({ posicao: { x, y } });
  }

  function configurarArraste(handle) {
    handle.addEventListener("mousedown", (evInicio) => {
      if (evInicio.target.closest(".ms-w-min")) return;
      evInicio.preventDefault();
      const iniX = evInicio.clientX;
      const iniY = evInicio.clientY;
      const origX = root.offsetLeft;
      const origY = root.offsetTop;

      function mover(ev) {
        aplicarPosicao({ x: origX + (ev.clientX - iniX), y: origY + (ev.clientY - iniY) }, true);
      }
      function soltar() {
        document.removeEventListener("mousemove", mover);
        document.removeEventListener("mouseup", soltar);
        const vw = window.innerWidth;
        const atual = root.getBoundingClientRect();
        const snapX = atual.left + atual.width / 2 < vw / 2 ? 8 : vw - atual.width - 8;
        aplicarPosicao({ x: snapX, y: root.offsetTop });
      }
      document.addEventListener("mousemove", mover);
      document.addEventListener("mouseup", soltar);
    });
  }

  /* ─── ACAO: escanear (usa scan compartilhado MetaSpyScan) ── */

  let _ultimaProgressoEnviadoMs = 0;

  function emitirProgressoScan(cardsDestacados, cardsEncontrados) {
    const agora = Date.now();
    if (agora - _ultimaProgressoEnviadoMs < 800) return;
    _ultimaProgressoEnviadoMs = agora;
    chrome.runtime.sendMessage({
      tipo: "progressoScanWidget",
      totalEscalados: cardsDestacados,
      totalProcessados: cardsEncontrados
    }).catch(() => {});
  }

  /* F2b: publica os resultados do scan no background para que o painel
     lateral (popup) exiba exatamente os mesmos anuncios. */
  function publicarResultadosScan(duracaoMs = 0) {
    const scan = getScan();
    if (!scan) return;
    let anuncios = [];
    try {
      anuncios = scan.coletarAnunciosDestacados ? scan.coletarAnunciosDestacados() : [];
    } catch (e) { /* ignore */ }
    chrome.runtime.sendMessage({
      acao: "publicarResultadosScan",
      anuncios: Array.isArray(anuncios) ? anuncios : [],
      duracaoS: Number((duracaoMs / 1000).toFixed(1)),
      mensagem: anuncios.length
        ? `Scan do widget concluído: ${anuncios.length} oferta(s) destacada(s).`
        : "Scan do widget concluído: nenhuma oferta atendeu aos filtros."
    }).catch(() => {});
  }

  /* Diagnóstico rápido: mostra quantos cards/anúncios a página expõe ao
     MetaSpyScan e o texto do primeiro card, direto no status do widget. */
  async function executarDiagnostico() {
    const scan = getScan();
    if (!scan) {
      statusEl.textContent = "MetaSpyScan nao carregado. Recarregue a pagina.";
      return;
    }
    statusEl.textContent = "Diagnosticando...";
    try {
      let cards = [];
      try {
        cards = (scan.coletarCardsVisiveis ? scan.coletarCardsVisiveis() : []) || [];
      } catch (e) {
        cards = [];
        console.error("[MetaSpy] erro coletarCardsVisiveis:", e);
      }
      let anuncios = [];
      try {
        anuncios = (scan.coletarAnunciosVisiveis ? scan.coletarAnunciosVisiveis("") : []) || [];
      } catch (e) {
        anuncios = [];
        console.error("[MetaSpy] erro coletarAnunciosVisiveis:", e);
      }
      const primeiro = anuncios[0] && anuncios[0].texto
        ? anuncios[0].texto.slice(0, 90)
        : cards[0]
          ? String(cards[0].innerText || "").replace(/\s+/g, " ").slice(0, 90)
          : "nenhum texto";
      const aneis = document.querySelectorAll("#metaspy-overlay .metaspy-overlay-ring").length;
      const neon = document.querySelectorAll(".metaspy-neon").length;
      statusEl.textContent = "Cards: " + cards.length + " | Anun: " + anuncios.length +
        " | neon: " + neon + " | aneis: " + aneis + " | 1o: " + primeiro;
    } catch (e) {
      statusEl.textContent = "Erro diagnostico: " + e.message;
    }
  }

  function executarEscaneamento(rolagem = true) {
    const scan = getScan();
    if (!scan || !scan.destacarCards) {
      statusEl.innerHTML = "MetaSpy nao carregado nesta aba. Recarregue a pagina.";
      return;
    }
    if (escaneando) return;
    escaneando = true;
    sinalParada = false;
    btnScan.disabled = true;
    rotuloScan.textContent = "Escaneando...";
    btnParar.style.display = "";
    statusEl.innerHTML = "Escaneando cards...";
    resultadosEl.innerHTML = "";
    resultadosEl.style.display = "none";
    emitirProgressoScan(0, 0);

    const inicio = Date.now();
    scan.destacarCards({
      diasMin: Number(sliderDias.value) || 30,
      copiasMin: Number(sliderCopias.value) || 5,
      fixarNoTopo: false,
      rolagem,
      onProgress: ({ cardsEncontrados, cardsDestacados }) => {
        if (!escaneando) return;
        contadorEl.textContent = String(cardsDestacados);
        statusEl.innerHTML = cardsEncontrados + " cards — <b>" + cardsDestacados + "</b> ofertas destacadas";
        emitirProgressoScan(cardsDestacados, cardsEncontrados);
      },
      sinalParada: () => {
        const scanAtual = getScan();
        return sinalParada || !!(scanAtual && scanAtual.estado && scanAtual.estado.parar);
      }
    }).then((res) => {
      escaneando = false;
      autoEscaneadoParaUrl = document.URL;
      ultimaContagemScan = Number((res && res.cardsEncontrados) || 0);
      btnScan.disabled = false;
      rotuloScan.textContent = "Escanear";
      btnParar.style.display = "none";
      contadorEl.textContent = String(res.cardsDestacados);
      renderizarResultados();
      publicarResultadosScan(res.duracaoMs);
      const seg = ((Date.now() - inicio) / 1000).toFixed(1);
      const fixados = Number(res.fixados || 0);
      statusEl.innerHTML = "Pronto — <b>" + res.cardsDestacados + "</b> ofertas (" + seg + "s)" +
        (fixados > 0 ? " · <b>" + fixados + "</b> no topo" : "");
    }).catch(() => {
      escaneando = false;
      autoEscaneadoParaUrl = document.URL;
      btnScan.disabled = false;
      rotuloScan.textContent = "Escanear";
      btnParar.style.display = "none";
      renderizarResultados();
      publicarResultadosScan(0);
      statusEl.textContent = "Erro ao escanear.";
    });
  }

  /* ─── RESULTADOS DO SCAN NO PAINEL ── */

  function coletarResultados() {
    const scan = getScan();
    if (!scan) return [];
    const cards = Array.from(document.querySelectorAll(".metaspy-neon"));
    if (cards.length === 0) return [];
    const porId = new Map();
    try {
      scan.coletarAnunciosVisiveis("").forEach((a) => porId.set(a.idAnuncio, a));
    } catch (e) { /* ignore */ }
    return cards.map((card) => {
      let id = "";
      try {
        id = scan.extrairIdDoElemento ? scan.extrairIdDoElemento(card) || "" : "";
      } catch (e) { /* ignore */ }
      const anuncio = (id && porId.get(id)) || null;
      const linha = [];
      if (anuncio && anuncio.diasAtivo) linha.push(String(anuncio.diasAtivo) + " dias");
      if (anuncio && anuncio.texto) linha.push(anuncio.texto.slice(0, 60));
      return {
        anunciante: anuncio ? anuncio.anunciante || "Anunciante" : "Anunciante",
        detalhe: linha.join(" — "),
        url: anuncio && anuncio.urlBiblioteca ? anuncio.urlBiblioteca : id ? "https://www.facebook.com/ads/library/?id=" + id : location.href
      };
    });
  }

  function renderizarResultados() {
    const resultados = coletarResultados();
    resultadosEl.innerHTML = "";
    if (resultados.length === 0) {
      resultadosEl.style.display = "none";
      return;
    }
    resultadosEl.style.display = "";
    resultados.forEach((r) => {
      const item = document.createElement("button");
      item.type = "button";
      item.className = "ms-w-resultado-item";
      item.title = "Abrir no Meta Ads Library";
      item.appendChild(criarIconeSVG('<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14 21 3"/>'));
      const txt = document.createElement("div");
      txt.className = "ms-w-ri-txt";
      const b = document.createElement("b");
      b.textContent = r.anunciante;
      const s = document.createElement("span");
      s.textContent = r.detalhe;
      txt.appendChild(b);
      txt.appendChild(s);
      item.appendChild(txt);
      item.addEventListener("click", () => {
        window.open(r.url, "_blank", "noopener");
      });
      resultadosEl.appendChild(item);
    });
  }

  /* ─── CHIPS DE PALAVRAS-CHAVE (F1) ── */

  async function carregarChips() {
    const usados = new Map();
    try {
      const dados = await chrome.storage.local.get([CHAVE_BIBLIOTECA]);
      const lib = (dados && dados[CHAVE_BIBLIOTECA]) || { personalizadas: [] };
      (lib.personalizadas || []).forEach((p) => {
        if (p.favorito) usados.set(p.termo, p.vezesUsado || 0);
      });
    } catch (e) { /* ignore */ }
    try {
      const url = chrome.runtime.getURL("keywords.json");
      const res = await fetch(url);
      const dados = await res.json();
      (dados.categorias || []).forEach((cat) => {
        (cat.subcategorias || []).forEach((sub) => {
          (sub.palavrasChave || []).forEach((p) => {
            if (!usados.has(p.termo)) usados.set(p.termo, 0);
          });
        });
      });
    } catch (e) { /* ignore */ }
    return Array.from(usados.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([termo]) => termo);
  }

  function buscarTermoNaBiblioteca(termo) {
    const pais = new URLSearchParams(location.search).get("country") || "ALL";
    const url = new URL("https://www.facebook.com/ads/library/");
    url.searchParams.set("active_status", "all");
    url.searchParams.set("ad_type", "all");
    url.searchParams.set("country", pais);
    url.searchParams.set("q", termo);
    location.href = url.href;
  }

  /* ─── SYNC COM O PAINEL (two-way via storage) ── */

  chrome.storage.onChanged.addListener((mudancas, area) => {
    if (area !== "local" || !mudancas[CHAVE]) return;
    const novo = mudancas[CHAVE].newValue;
    if (!novo) return;
    if (sliderDias && novo.diasMin !== undefined && Number(sliderDias.value) !== Number(novo.diasMin)) {
      sliderDias.value = String(novo.diasMin);
      valorDias.textContent = String(novo.diasMin);
    }
    if (sliderCopias && novo.copiasMin !== undefined && Number(sliderCopias.value) !== Number(novo.copiasMin)) {
      sliderCopias.value = String(novo.copiasMin);
      valorCopias.textContent = String(novo.copiasMin);
    }
  });

  /* ─── AUTO-SCAN ────────────────────────────────────── */

  function agendarAutoScan() {
    if (autoScanTimer || escaneando || sinalParada) return;
    if (!document.URL.includes("/ads/library")) return;
    const scan = getScan();
    if (!scan || !scan.coletarCardsVisiveis) return;
    autoScanTimer = setTimeout(() => {
      autoScanTimer = null;
      if (escaneando || sinalParada) return;
      if (!document.URL.includes("/ads/library")) return;
      let n = 0;
      try { n = scan.coletarCardsVisiveis().length; } catch (e) { n = 0; }
      if (n === 0) return;
      if (document.querySelectorAll(".metaspy-neon").length > 0) return;
      /* URL nova → escaneia; mesma URL → só se surgiram mais cards. */
      if (document.URL === autoEscaneadoParaUrl && n <= ultimaContagemScan) return;
      executarEscaneamento(false);
    }, 1500);
  }

  let observerAutoScan = null;
  function iniciarAutoScan() {
    if (observerAutoScan) return;
    observerAutoScan = new MutationObserver(agendarAutoScan);
    observerAutoScan.observe(document.documentElement, { childList: true, subtree: true });
  }

  /* ─── BOOT ─────────────────────────────────────────── */

  carregarEstado().then(() => {
    montarWidget();
    aplicarPosicao(estado.posicao, true);
    iniciarAutoScan();
    agendarAutoScan();
  });
})();
