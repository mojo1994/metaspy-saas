(function () {
  "use strict";

  // ================================================================
  //  MetaSpy Orchestrator v1.0.0
  //  Corrige detecção de status ativo/inativo SEM modificar
  //  código existente (monkey-patch).
  //
  //  Bug original (content-script.js:82):
  //    cardPareceAtivo() retornava TRUE quando o status textual
  //    não era encontrado no DOM → todo anúncio virava "Ativo".
  //
  //  Correção:
  //    Estratégias múltiplas de detecção com fallback INACTIVE.
  // ================================================================

  var CONFIG = {
    DEBUG: true,
  };

  // ================================================================
  //  LOG
  // ================================================================

  function log() {
    if (CONFIG.DEBUG) {
      var args = Array.prototype.slice.call(arguments);
      args.unshift("[MetaSpyOrch]");
      console.log.apply(console, args);
    }
  }

  // ================================================================
  //  PARSER DE DATA BRASILEIRA
  // ================================================================

  function parseDataBrasil(str) {
    try {
      var MESES = {
        janeiro: 0, fevereiro: 1, "março": 2, abril: 3,
        maio: 4, junho: 5, julho: 6, agosto: 7,
        setembro: 8, outubro: 9, novembro: 10, dezembro: 11,
        jan: 0, fev: 1, mar: 2, abr: 3, mai: 4, jun: 5,
        jul: 6, ago: 7, set: 8, out: 9, nov: 10, dez: 11,
      };
      var limpo = str.replace(/\bde\b/gi, "").trim();
      var partes = limpo.split(/\s+/);
      var dia = parseInt(partes[0], 10);
      var mes = MESES[(partes[1] || "").toLowerCase()];
      var ano = parseInt(partes[2], 10);
      if (!isNaN(dia) && mes !== void 0 && !isNaN(ano)) {
        return new Date(ano, mes, dia);
      }
    } catch (_) { /* ignore */ }
    return null;
  }

  // ================================================================
  //  ESTRATÉGIAS DE DETECÇÃO DE STATUS
  // ================================================================

  var ESTRATEGIAS = {
    VER_DETALHES:   { peso: 0.95, rotulo: 'Botão "Ver detalhes" presente' },
    NAO_VEICULADA:  { peso: 0.95, rotulo: 'Texto "não está mais sendo veiculada"' },
    DATA_FIM:       { peso: 0.90, rotulo: "Data de término no passado" },
    STATUS_TEXTO:   { peso: 0.85, rotulo: "Status textual explícito" },
    KEYWORD_ATIVO:  { peso: 0.75, rotulo: "Palavra-chave de veiculação" },
    FALLBACK:       { peso: 0.95, rotulo: "Fallback: assumir inativo" },
  };

  function detectarStatusCard(card) {
    var texto = String(card && card.innerText || "").trim();
    if (!texto) {
      return { ativo: false, estrategia: "FALLBACK" };
    }

    /* ── Estratégia A: Botão "Ver detalhes" → ATIVO ── */
    if (
      (card && (card.querySelector('a[href*="detail"]') || card.querySelector('a[href*="detalhes"]'))) ||
      /\bver detalhes?\b/i.test(texto)
    ) {
      return { ativo: true, estrategia: "VER_DETALHES" };
    }

    /* ── Estratégia B: "Não está mais sendo veiculada" → INATIVO ── */
    if (
      /n[aã]o\s+est[aá]\s+mais\s+(sendo\s+)?veiculad[ao]/i.test(texto) ||
      /this\s+(ad|creative|publication)\s+is\s+no\s+longer/i.test(texto)
    ) {
      return { ativo: false, estrategia: "NAO_VEICULADA" };
    }

    /* ── Estratégia C: Data de término no passado ── */
    var dataFimMatch = texto.match(
      /Data\s+de\s+t[eé]rmino\s*:?\s*(\d{1,2}\s+(?:de\s+)?[a-zçãáéíóú]+\s*(?:de\s+)?\d{4})/i
    );
    if (dataFimMatch) {
      var parsed = parseDataBrasil(dataFimMatch[1]);
      if (parsed && parsed.getTime() < Date.now()) {
        return { ativo: false, estrategia: "DATA_FIM" };
      }
    }

    /* ── Estratégia D: "Status: Ativo/Inativo..." textual ── */
    var statusMatch = texto.match(
      /Status\s*:?\s*(Ativo|Inativo|Removido|Conclu[ií]do|Pausado)/i
    );
    if (statusMatch) {
      return {
        ativo: /Ativo/i.test(statusMatch[1]),
        estrategia: "STATUS_TEXTO",
      };
    }

    /* ── Estratégia E: Palavras-chave de veiculação ativa ── */
    if (/\b(?:em\s+veicula[cç][aã]o|running|active|ativo)\b/i.test(texto)) {
      return { ativo: true, estrategia: "KEYWORD_ATIVO" };
    }

    /* ── Estratégia F: Usar função original (se retornar false) ── */
    if (typeof _cardPareceAtivoOriginal === "function") {
      try {
        if (!_cardPareceAtivoOriginal(card)) {
          return { ativo: false, estrategia: "FALLBACK" };
        }
      } catch (_) { /* ignore */ }
    }

    /* ── Estratégia G: FALLBACK → INATIVO (CORREÇÃO DO BUG) ── */
    return { ativo: false, estrategia: "FALLBACK" };
  }

  // ================================================================
  //  MONKEY PATCH: cardPareceAtivo
  // ================================================================

  var _cardPareceAtivoOriginal = null;

  if (typeof cardPareceAtivo !== "function") {
    console.error("[MetaSpyOrch] ERRO: cardPareceAtivo nao encontrada.");
  } else {
    _cardPareceAtivoOriginal = cardPareceAtivo;

    cardPareceAtivo = function (card) {
      var result = detectarStatusCard(card);
      log(
        "cardPareceAtivo →",
        result.ativo ? "ATIVO" : "INATIVO",
        "(" + result.estrategia + ")",
        result.ativo ? "" : "✗ CORRIGIDO"
      );
      return result.ativo;
    };

    log("✓ monkey-patch cardPareceAtivo aplicado");
  }

  // ================================================================
  //  MONKEY PATCH: coletarAnunciosVisiveis (enriquecimento)
  // ================================================================

  if (typeof coletarAnunciosVisiveis !== "function") {
    console.error("[MetaSpyOrch] ERRO: coletarAnunciosVisiveis nao encontrada.");
  } else {
    var _coletarOriginal = coletarAnunciosVisiveis;

    coletarAnunciosVisiveis = function (termo) {
      var anuncios = _coletarOriginal(termo);
      var cards =
        typeof coletarCardsVisiveis === "function"
          ? coletarCardsVisiveis()
          : [];

      var corrigidos = 0;

      for (var i = 0; i < anuncios.length; i++) {
        var anuncio = anuncios[i];
        var card = cards[i] || null;
        var statusResult = card
          ? detectarStatusCard(card)
          : null;

        if (!statusResult) {
          var temDataFim =
            anuncio.dataFimISO &&
            new Date(anuncio.dataFimISO).getTime() < Date.now();
          statusResult = {
            ativo: anuncio.adActiveStatus === "ACTIVE" && !temDataFim,
            estrategia: "INFERIDO",
          };
        }

        var foiCorrigido = anuncio.ativo !== statusResult.ativo;

        if (foiCorrigido) {
          anuncio.ativo = statusResult.ativo;
          anuncio.adActiveStatus = statusResult.ativo ? "ACTIVE" : "INACTIVE";
          anuncio.statusTexto = statusResult.ativo ? "Ativo" : "Inativo";
          if (!statusResult.ativo) {
            anuncio.consistenciaTemporal = 40;
            anuncio.evergreen = false;
          }
          corrigidos++;
        }

        anuncio._orchestrator = {
          statusCorrigido: foiCorrigido,
          statusAnterior: foiCorrigido
            ? statusResult.ativo
              ? "INACTIVE"
              : "ACTIVE"
            : void 0,
          metodoDeteccao: statusResult.estrategia,
          confianca:
            ESTRATEGIAS[statusResult.estrategia] &&
            ESTRATEGIAS[statusResult.estrategia].peso
              ? ESTRATEGIAS[statusResult.estrategia].peso
              : 0.5,
          versao: "1.0.0",
          timestamp: new Date().toISOString(),
        };
      }

      log(
        "coletarAnunciosVisiveis →",
        anuncios.length,
        "anuncios, corrigidos:",
        corrigidos
      );
      return anuncios;
    };

    log("✓ monkey-patch coletarAnunciosVisiveis aplicado");
  }

  // ================================================================
  //  NOTA SOBRE VALIDAÇÃO VIA API
  // ================================================================
  //  Para cross-validation com Graph API, o orchestrator pode no
  //  futuro enviar os IDs dos anúncios ao background.js via:
  //    chrome.runtime.sendMessage({
  //      tipo: "orchestratorValidacaoApi",
  //      ids: [ ... ]
  //    })
  //  O background.js então consulta a Graph API e retorna o status
  //  real, permitindo correção adicional.
  // ================================================================

  log("✓ Orchestrator v1.0.0 ativo — fallback alterado para INACTIVE");
})();
