"use strict";

importScripts("utils.js");

const {
  esperar,
  normalizarTexto,
  normalizarAnuncioApi,
  ehAnuncioAtivoRigoroso,
  ehRealmenteAtivo,
  enriquecerAnuncioComScore,
  normalizarPais,
  correspondeNicho,
  calcularCompetitividadeNicho,
  gerarCsv,
  detectarMultiPagina,
  mapearCopiasPorAnuncio,
  contarCopiasAnuncio,
  filtrarPorCopiasMin
} = self.MetaSpyUtils;

const ADS_ENDPOINT = "https://graph.facebook.com/v25.0/ads_archive";
const CACHE_DB = "metaspy_db";
const DB_VERSAO = 1;
const STORE_FAVORITOS = "favoritos";
const STORE_CACHE = "cache";
const STORAGE_RESULTADOS_ATUAIS = "resultadosAtuais";
const STORAGE_TOTAL_ESCALADOS = "totalEscaladosAtual";
const POPUP_SPY_HIT = "popup.html";
const DIAS_MIN_FOCO_PADRAO = 100;
const CACHE_EXPIRACAO_MS = 5 * 60 * 1000;

const TERMOS_SEGMENTO = {
  nutra: "suplemento OR capsula OR nutraceutico OR nutra OR vitamina OR minerais",
  info: "curso OR ebook OR mentoria OR apostila OR treinamento OR guia"
};

const LIMITE_RESULTADOS_VARREDURA = 200;
const LIMITE_POR_PAGINA_VARREDURA = 100;
const PAUSA_ENTRE_PAGINAS_MS = 650;
const INTERVALO_ATUALIZACAO_VARREDURA_MS = 1200;
const PAUSA_RATE_LIMIT_MS = 15000;
const TIMEOUT_REQUISICAO_API_MS = 30000;

/* P3: hot cache em memoria (curta duracao) a frente do IndexedDB. */
const CACHE_MEMORIA_TTL_MS = 60 * 1000;

/* P2: backoff exponencial com jitter, escopado por chamada. */
const BACKOFF_INICIAL_MS = 1000;
const BACKOFF_MAX_MS = 20000;

/* P5: page size maior para a API e paginacao via paging.next. */
const LIMITE_POR_PAGINA_API = 200;

/* P6: throttle de escrita em storage para o status de varredura. */
const INTERVALO_STATUS_VARREDURA_MS = 800;

/* F2c: limites de tempo do modo aprofundado da Biblioteca. */
const TEMPO_PADRAO_VARREDURA_PROFUNDA_MIN = 10;
const TEMPO_MAXIMO_VARREDURA_PROFUNDA_MIN = 25;
const BUFFER_FINAL_MS = 10000;

/* F4: fila de downloads em lote (pool pequeno, sem saveAs). */
const DOWNLOAD_LOTE_POOL = 2;
const DOWNLOAD_LOTE_SUBPASTA = "metaspy";
const DOMINIOS_VIDEO_PERMITIDOS = [
  "facebook.com",
  "www.facebook.com",
  "video.facebook.com",
  "fbcdn.net",
  "video.fbcdn.net",
  "cdn.fbsbx.com",
  "lookaside.fbsbx.com",
  "cdninstagram.com",
  "video.instagram.com"
];

const CAMPOS_API_PRINCIPAL = [
  "id",
  "ad_creation_time",
  "ad_creative_bodies",
  "ad_creative_link_captions",
  "ad_creative_link_descriptions",
  "ad_creative_link_titles",
  "ad_delivery_start_time",
  "ad_delivery_stop_time",
  "ad_snapshot_url",
  "ad_active_status",
  "ad_creative_thumbnail_url",
  "page_id",
  "page_name",
  "publisher_platforms",
  "ad_creative_link_url",
  "estimated_audience_size",
  "impressions",
  "spend"
].join(",");

const CAMPOS_API_FALLBACK = [
  "id",
  "ad_creation_time",
  "ad_creative_bodies",
  "ad_delivery_start_time",
  "ad_delivery_stop_time",
  "ad_snapshot_url",
  "ad_active_status",
  "ad_creative_thumbnail_url",
  "page_id",
  "page_name",
  "publisher_platforms"
].join(",");

const estadoBusca = {
  ativa: false,
  modo: "",
  parar: false,
  totalEscalados: 0,
  totalProcessados: 0,
  resultados: [],
  termoNicho: "",
  copiasMinFiltro: 0,
  inicioMs: 0,
  marcadores: []
};

let ultimoSalvamentoResultadosMs = 0;
let ultimoStatusProgressoMs = 0;

/* P3: hot cache em memoria (curta duracao) a frente do IndexedDB. */
const cacheMemoria = new Map();

/* P2: lembra o ultimo cenario API bem-sucedido por sessao (por token). */
let cenarioSessao = { token: "", indice: -1 };

/* F4: fila de downloads em lote (visivel no painel, Tools). */
const filaDownloads = {
  itens: [],
  emAndamento: 0
};

function logInfo(msg) {
  console.log(`[MetaSpy] ${msg}`);
}

/* P7: timing por fase usando performance.now(). */
function marcarFase(nome) {
  const agora = performance.now();
  const desdeInicio = estadoBusca.inicioMs ? Math.round(agora - estadoBusca.inicioMs) : 0;
  const marcador = {
    nome,
    em: new Date().toISOString(),
    desdeInicioMs: desdeInicio,
    tempoEntreFasesMs: estadoBusca.marcadores.length
      ? Math.round(agora - (estadoBusca.marcadores[estadoBusca.marcadores.length - 1].performanceMark || agora))
      : 0,
    performanceMark: agora
  };
  estadoBusca.marcadores.push(marcador);
  if (estadoBusca.marcadores.length > 50) estadoBusca.marcadores.splice(0, estadoBusca.marcadores.length - 50);
  return marcador;
}

function abrirDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(CACHE_DB, DB_VERSAO);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_FAVORITOS)) {
        db.createObjectStore(STORE_FAVORITOS, { keyPath: "idAnuncio" });
      }
      if (!db.objectStoreNames.contains(STORE_CACHE)) {
        db.createObjectStore(STORE_CACHE, { keyPath: "chave" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function dbPut(storeName, value) {
  const db = await abrirDB();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    tx.objectStore(storeName).put(value);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

async function dbGetAll(storeName) {
  const db = await abrirDB();
  const result = await new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const req = tx.objectStore(storeName).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return result;
}

async function dbGet(storeName, key) {
  const db = await abrirDB();
  const result = await new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const req = tx.objectStore(storeName).get(key);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return result;
}

async function dbDelete(storeName, key) {
  const db = await abrirDB();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    const req = tx.objectStore(storeName).delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
  db.close();
}

async function obterCacheApi(url) {
  try {
    const entradaMemoria = cacheMemoria.get(url);
    if (entradaMemoria && Date.now() - entradaMemoria.criadoEm < CACHE_MEMORIA_TTL_MS) {
      logInfo(`Cache memoria hit para: ${url.slice(0, 80)}`);
      return entradaMemoria.valor;
    }
    const entry = await dbGet(STORE_CACHE, url);
    if (entry && entry.criadoEm && Date.now() - entry.criadoEm < CACHE_EXPIRACAO_MS) {
      cacheMemoria.set(url, { valor: entry.valor, criadoEm: entry.criadoEm });
      logInfo(`Cache hit para: ${url.slice(0, 80)}`);
      return entry.valor;
    }
  } catch (e) { /* ignore */ }
  return null;
}

async function salvarCacheApi(url, data) {
  cacheMemoria.set(url, { valor: data, criadoEm: Date.now() });
  try {
    await dbPut(STORE_CACHE, { chave: url, valor: data, criadoEm: Date.now() });
  } catch (e) { /* ignore */ }
}

async function obterTokenApi() {
  const dados = await chrome.storage.local.get(["apiToken"]);
  const token = String(dados.apiToken || "").trim();
  return token || null;
}

async function obterConfiguracoesBusca() {
  const dados = await chrome.storage.local.get([
    "apiToken",
    "paisFiltro",
    "statusFiltro",
    "diasMinFiltro",
    "copiasMinFiltro",
    "modoBibliotecaAberta",
    "sincronizarBibliotecaBusca",
    "modoPais",
    "mostrarInativos",
    "segmentoAtivo",
    "palavrasNegativas"
  ]);
  const statusFiltro = String(dados.statusFiltro || "ACTIVE").toUpperCase();
  return {
    pais: normalizarPais(dados.paisFiltro || "BR"),
    statusFiltro,
    diasMinFiltro: Math.max(0, Number(dados.diasMinFiltro ?? DIAS_MIN_FOCO_PADRAO)),
    copiasMinFiltro: Math.max(0, Number(dados.copiasMinFiltro || 0)),
    modoBibliotecaAberta: dados.sincronizarBibliotecaBusca === true,
    mostrarInativos: dados.mostrarInativos === true || statusFiltro !== "ACTIVE",
    segmentoAtivo: String(dados.segmentoAtivo || "").trim(),
    palavrasNegativas: String(dados.palavrasNegativas || "").trim()
  };
}

function montarUrlApiPorParametros(parametros = {}) {
  const params = new URLSearchParams();
  Object.entries(parametros).forEach(([chave, valor]) => {
    if (valor !== undefined && valor !== null) {
      params.set(chave, String(valor));
    }
  });
  return `${ADS_ENDPOINT}?${params.toString()}`;
}

function montarCenariosApi({ token, termo = "", limite = 25, pais = "BR", statusFiltro = "ACTIVE" }) {
  const termoSeguro = termo && String(termo).trim() ? String(termo).trim() : "";
  const base = {
    access_token: token,
    ad_active_status: statusFiltro || "ACTIVE",
    limit: String(limite),
    locale: "pt_BR"
  };
  if (termoSeguro) {
    base.search_terms = termoSeguro;
  }

  const semPais = pais === "ALL";
  const sufixoNome = semPais ? " (todos os países)" : "";

  return [
    {
      nome: "ALL + ad_reached_countries JSON + campos principais" + sufixoNome,
      url: montarUrlApiPorParametros({
        ...base,
        ad_type: "ALL",
        ad_reached_countries: semPais ? undefined : JSON.stringify([pais]),
        fields: CAMPOS_API_PRINCIPAL
      })
    },
    {
      nome: "ALL + ad_reached_countries colchetes + campos principais" + sufixoNome,
      url: montarUrlApiPorParametros({
        ...base,
        ad_type: "ALL",
        ad_reached_countries: semPais ? undefined : `['${pais}']`,
        fields: CAMPOS_API_PRINCIPAL
      })
    },
    {
      nome: "ALL + ad_reached_countries JSON + campos fallback" + sufixoNome,
      url: montarUrlApiPorParametros({
        ...base,
        ad_type: "ALL",
        ad_reached_countries: semPais ? undefined : JSON.stringify([pais]),
        fields: CAMPOS_API_FALLBACK
      })
    },
    {
      nome: "ALL + ad_reached_countries colchetes + campos fallback" + sufixoNome,
      url: montarUrlApiPorParametros({
        ...base,
        ad_type: "ALL",
        ad_reached_countries: semPais ? undefined : `['${pais}']`,
        fields: CAMPOS_API_FALLBACK
      })
    },
    {
      nome: "POLITICAL_AND_ISSUE_ADS + ad_reached_countries JSON + campos principais" + sufixoNome,
      url: montarUrlApiPorParametros({
        ...base,
        ad_type: "POLITICAL_AND_ISSUE_ADS",
        ad_reached_countries: semPais ? undefined : JSON.stringify([pais]),
        fields: CAMPOS_API_PRINCIPAL
      })
    },
    {
      nome: "POLITICAL_AND_ISSUE_ADS + ad_reached_countries colchetes + campos fallback" + sufixoNome,
      url: montarUrlApiPorParametros({
        ...base,
        ad_type: "POLITICAL_AND_ISSUE_ADS",
        ad_reached_countries: semPais ? undefined : `['${pais}']`,
        fields: CAMPOS_API_FALLBACK
      })
    },
    {
      nome: "POLITICAL_AND_ISSUE_ADS + ad_reached_countries simples + campos fallback" + sufixoNome,
      url: montarUrlApiPorParametros({
        ...base,
        ad_type: "POLITICAL_AND_ISSUE_ADS",
        ad_reached_countries: semPais ? undefined : pais,
        fields: CAMPOS_API_FALLBACK
      })
    }
  ];
}

function erroEhParametroInvalido(erro) {
  const msg = String(erro?.message || "").toLowerCase();
  const code = Number(erro?.code || 0);
  return code === 100 || msg.includes("invalid parameter") || msg.includes("param") || msg.includes("ad_reached_countries");
}

/* P2: backoff exponencial com jitter, escopado por chamada (nao soma entre cenarios). */
function aguardarBackoff(tentativa) {
  const exponencial = Math.min(BACKOFF_MAX_MS, BACKOFF_INICIAL_MS * Math.pow(2, tentativa));
  const jitter = Math.round(Math.random() * 0.3 * exponencial);
  const total = exponencial + jitter;
  logInfo(`Backoff exponencial: ${Math.round(total)}ms (tentativa ${tentativa}).`);
  return esperar(total);
}

async function requisicaoApiComRetry(url, tentativa = 0) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), TIMEOUT_REQUISICAO_API_MS);
  let resposta;
  try {
    resposta = await fetch(url, { method: "GET", signal: controller.signal });
  } catch (erro) {
    if (erro?.name === "AbortError") {
      throw new Error("Tempo limite da API atingido. Verifique token/conexao e tente novamente.");
    }
    throw erro;
  } finally {
    clearTimeout(timeout);
  }
  if (resposta.status === 429) {
    if (tentativa >= 2) throw new Error("Rate limit da API atingido (HTTP 429).");
    logInfo("Rate limit HTTP 429 detectado. Aguardando antes de tentar novamente...");
    await aguardarBackoff(tentativa);
    return requisicaoApiComRetry(url, tentativa + 1);
  }

  const json = await resposta.json();
  if (!resposta.ok || json.error) {
    const codigo = Number(json?.error?.code || 0);
    if ((codigo === 4 || codigo === 800) && tentativa < 2) {
      logInfo(`Throttling API detectado (código ${codigo}). Aguardando antes de tentar novamente...`);
      await aguardarBackoff(tentativa);
      return requisicaoApiComRetry(url, tentativa + 1);
    }
    const err = new Error(json?.error?.message || `Erro na API (${resposta.status}).`);
    err.code = Number(json?.error?.code || 0);
    err.subcode = Number(json?.error?.error_subcode || 0);
    err.raw = json?.error || null;
    throw err;
  }
  return json;
}

async function requisicaoApiRobusta({ token, termo = "", limite = 25, pais = "BR", statusFiltro = "ACTIVE" }) {
  const cenarios = montarCenariosApi({ token, termo, limite, pais, statusFiltro });

  /* P2: tenta primeiro o ultimo cenario bem-sucedido desta sessao para o mesmo token. */
  let ordem = cenarios.map((_, i) => i);
  if (cenarioSessao.token === token && cenarioSessao.indice >= 0 && cenarioSessao.indice < cenarios.length) {
    ordem = [cenarioSessao.indice].concat(ordem.filter((i) => i !== cenarioSessao.indice));
  }

  let ultimoErro = null;
  for (const indice of ordem) {
    const cenario = cenarios[indice];
    try {
      const cacheado = await obterCacheApi(cenario.url);
      if (cacheado) return { json: cacheado, urlInicial: cenario.url, cenario: cenario.nome + " (cache)" };
      logInfo(`Tentando cenário da API: ${cenario.nome}`);
      const json = await requisicaoApiComRetry(cenario.url);
      salvarCacheApi(cenario.url, json).catch(() => {});
      cenarioSessao = { token, indice };
      return { json, urlInicial: cenario.url, cenario: cenario.nome };
    } catch (erro) {
      ultimoErro = erro;
      if (erroEhParametroInvalido(erro)) {
        logInfo(`Cenário inválido: ${cenario.nome} -> ${erro.message}`);
        continue;
      }
      throw erro;
    }
  }
  throw ultimoErro || new Error("Nenhum cenário de consulta API funcionou.");
}

/* P5: paginacao por paging.next com page size maior, acumulando ate o limite
   de varredura; cada pagina passa pelo hot cache / IndexedDB cache. */
async function buscarAdsApiPaginada({ token, termo = "", limite = LIMITE_POR_PAGINA_API, pais = "BR", statusFiltro = "ACTIVE", maxTotal = LIMITE_RESULTADOS_VARREDURA, porPagina = null }) {
  const primeira = await requisicaoApiRobusta({ token, termo, limite, pais, statusFiltro });
  const todos = Array.isArray(primeira.json.data) ? [...primeira.json.data] : [];
  let urlProxima = primeira.json.paging?.next || null;
  let pagina = 1;

  while (urlProxima && todos.length < maxTotal && pagina < 10) {
    try {
      const cacheado = await obterCacheApi(urlProxima);
      const json = cacheado || await requisicaoApiComRetry(urlProxima);
      if (!cacheado) salvarCacheApi(urlProxima, json).catch(() => {});
      if (Array.isArray(json.data)) {
        todos.push(...json.data);
        if (porPagina && typeof porPagina === "function") porPagina(json.data, pagina);
      }
      urlProxima = json.paging?.next || null;
      pagina += 1;
    } catch (erro) {
      if (erroEhParametroInvalido(erro)) break;
      throw erro;
    }
  }

  return {
    data: todos.slice(0, maxTotal),
    urlInicial: primeira.urlInicial,
    cenario: primeira.cenario,
    paginasConsumidas: pagina,
    temMais: Boolean(urlProxima)
  };
}

async function limparOverlayEmAbas() {
  const abas = await obterAbasBiblioteca();
  await Promise.all(
    abas.map(
      (aba) =>
        new Promise((resolve) => {
          chrome.tabs.sendMessage(aba.id, { acao: "pararBusca" }, () => resolve());
        })
    )
  );
}

async function enviarPararVarreduraParaAbas() {
  const abas = await obterAbasBiblioteca();
  await Promise.all(
    abas.map(
      (aba) =>
        new Promise((resolve) => {
          chrome.tabs.sendMessage(aba.id, { acao: "pararVarredura" }, () => resolve());
        })
    )
  );
}

function resetarEstadoBusca() {
  estadoBusca.ativa = false;
  estadoBusca.parar = false;
  estadoBusca.totalEscalados = 0;
  estadoBusca.totalProcessados = 0;
  estadoBusca.resultados = [];
  estadoBusca.modo = "";
  estadoBusca.termoNicho = "";
  estadoBusca.copiasMinFiltro = 0;
  estadoBusca.inicioMs = 0;
  estadoBusca.marcadores = [];
  _contadorLoteVarredura = 0;
}

async function salvarResultadosAtuaisStorage(forcar = false) {
  const agora = Date.now();
  if (!forcar && estadoBusca.ativa && ultimoSalvamentoResultadosMs && agora - ultimoSalvamentoResultadosMs < INTERVALO_ATUALIZACAO_VARREDURA_MS) {
    return;
  }
  ultimoSalvamentoResultadosMs = agora;
  await chrome.storage.local.set({
    [STORAGE_RESULTADOS_ATUAIS]: estadoBusca.resultados || [],
    [STORAGE_TOTAL_ESCALADOS]: Number(estadoBusca.totalEscalados || 0)
  });
}

async function atualizarStatusProgresso(payload = {}) {
  /* P6: UI sempre atualizada; escrita em storage throttled. */
  const agora = Date.now();
  if (!ultimoStatusProgressoMs || agora - ultimoStatusProgressoMs >= INTERVALO_STATUS_VARREDURA_MS) {
    ultimoStatusProgressoMs = agora;
    await chrome.storage.local.set({
      escaladosVarredura: Number(payload.totalEscalados || estadoBusca.totalEscalados || 0),
      statusVarredura: payload.status || (estadoBusca.ativa ? "em_andamento" : "parado")
    });
  }
  chrome.runtime.sendMessage({ tipo: "progressoVarredura", ...payload }).catch(() => {});
}

function anuncioPassaStatus(anuncio = {}, statusFiltro = "ACTIVE") {
  const status = String(statusFiltro || "ACTIVE").toUpperCase();
  if (status === "ALL") return true;
  if (status === "INACTIVE") return !ehRealmenteAtivo(anuncio);
  return ehRealmenteAtivo(anuncio);
}

function filtrarPorPalavrasNegativas(anuncio, palavras = "") {
  if (!palavras) return true;
  const lista = palavras.split(/\s+/).filter(Boolean).map((p) => normalizarTexto(p.replace(/^-/, "")));
  if (!lista.length) return true;
  const texto = normalizarTexto(`${anuncio.textoCompleto || ""} ${anuncio.anunciante || ""} ${anuncio.urlDestino || ""}`);
  return !lista.some((p) => texto.includes(p));
}

function filtrarPorSegmento(anuncio, segmento = "") {
  if (!segmento) return true;
  if (segmento === "nutra") return String(anuncio.entregavel || "") === "Nutra";
  if (segmento === "info") return ["Curso", "PDF", "Mentoria", "Tutorial", "Consultoria"].includes(String(anuncio.entregavel || ""));
  return true;
}

function processarLoteAds(adsApi = [], termoNicho = "", statusFiltro = "ACTIVE", diasMinFiltro = 0, opcoes = {}) {
  const filtrarNicho = opcoes.filtrarNicho !== false;
  const aplicarDiasMin = opcoes.aplicarDiasMin !== false;
  const palavrasNegativas = String(opcoes.palavrasNegativas || "").trim();
  const segmento = String(opcoes.segmento || "").trim();
  const normalizados = adsApi
    .map((ad) => normalizarAnuncioApi(ad))
    .filter(Boolean)
    .filter((anuncio) => anuncioPassaStatus(anuncio, statusFiltro))
    .filter((anuncio) => (termoNicho && filtrarNicho ? correspondeNicho(anuncio, termoNicho) : true))
    .filter((anuncio) => filtrarPorPalavrasNegativas(anuncio, palavrasNegativas))
    .filter((anuncio) => filtrarPorSegmento(anuncio, segmento))
    .map((anuncio) => enriquecerAnuncioComScore(anuncio))
    .filter((anuncio) => (!aplicarDiasMin ? true : Number(anuncio.diasAtivo || 0) >= Number(diasMinFiltro || 0)));

  // Detecta multiplas paginas com mesmo criativo
  const multi = detectarMultiPagina(normalizados);
  if (multi.length > 0) {
    const idsMulti = new Set();
    multi.forEach(function (grupo) {
      grupo.anuncios.forEach(function (a) { idsMulti.add(a.idAnuncio); });
    });
    normalizados.forEach(function (a) {
      if (idsMulti.has(a.idAnuncio)) a.multiPagina = true;
    });
  }

  return normalizados;
}

/* Sem termo, o MetaSpy nao inventa palavra nenhuma: a busca fica sem
   search_terms / sem q= e varre o feed como ele esta. */
function termoBuscaSeguro(termo = "") {
  return String(termo || "").trim();
}

/* URL da Biblioteca com q= apenas quando existe termo de busca. */
function montarUrlBiblioteca(pais = "BR", termo = "") {
  const base = `https://www.facebook.com/ads/library/?active_status=all&ad_type=all&country=${encodeURIComponent(pais)}`;
  const limpo = termoBuscaSeguro(termo);
  return limpo ? `${base}&q=${encodeURIComponent(limpo)}` : base;
}

/* Termo de busca ja presente na URL da Biblioteca (null se nao houver). */
function termoNaUrlDaBiblioteca(url = "") {
  const m = /[?&]q=([^&]*)/.exec(String(url || ""));
  if (!m) return null;
  try { return decodeURIComponent(m[1]).trim(); } catch (e) { return m[1].trim(); }
}

function urlEhBiblioteca(url = "") {
  return /^https?:\/\/([a-z0-9-]+\.)?facebook\.com\/ads\/library/i.test(String(url || ""));
}

async function obterAbasBiblioteca() {
  const abas = await chrome.tabs.query({ url: [
    "*://*.facebook.com/ads/library*",
    "*://facebook.com/ads/library*"
  ]});
  if (abas.length > 0) {
    console.log("[MetaSpy BG] obterAbasBiblioteca: encontradas por pattern:", abas.length);
    return abas;
  }
  const todas = await chrome.tabs.query({});
  const filtradas = todas.filter((t) => t?.url && urlEhBiblioteca(t.url));
  console.log("[MetaSpy BG] obterAbasBiblioteca: encontradas por regex:", filtradas.length, "total:", todas.length);
  return filtradas;
}

async function obterAbaBibliotecaObrigatoria() {
  const [ativa] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (ativa?.id && urlEhBiblioteca(ativa.url)) return ativa;
  const abas = await obterAbasBiblioteca();
  if (abas[0]?.id) return abas[0];
  throw new Error(
    "A aba da Biblioteca de Anuncios nao esta aberta. Abra https://www.facebook.com/ads/library e clique no botao de novo — a varredura usa a aba que ja existe e nunca recarrega a pagina."
  );
}

function enviarMensagemAba(tabId, mensagem) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, mensagem, (resposta) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message || "Content script nao respondeu."));
        return;
      }
      resolve(resposta);
    });
  });
}

async function garantirContentScriptNaAba(tabId) {
  for (let tentativa = 0; tentativa < 2; tentativa += 1) {
    try {
      const diagnostico = await enviarMensagemAba(tabId, { acao: "diagnosticoMetaSpy" });
      if (diagnostico?.ok) return;
    } catch (erro) {
      // A aba pode ter sido aberta antes da extensao ser recarregada.
    }

    // F6: nunca recarrega a aba. Aguarda o documento ficar pronto e so
    // injeta o content script se ele ainda nao estiver respondendo.
    try {
      const aba = await chrome.tabs.get(tabId);
      if (aba?.status === "loading") {
        await esperar(800);
        continue;
      }
    } catch (erro) {
      throw new Error("A aba da Biblioteca nao esta mais disponivel.");
    }

    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["utils.js", "content-script.js"]
      });
      await esperar(300);
    } catch (erro) {
      if (tentativa === 1) {
        throw new Error(
          "Nao foi possivel conectar na aba da Biblioteca. Abra a Biblioteca de Anuncios e tente de novo."
        );
      }
    }
  }
}

async function enviarMensagemBiblioteca(tabId, mensagem) {
  await garantirContentScriptNaAba(tabId);
  const resposta = await enviarMensagemAba(tabId, mensagem);
  if (!resposta?.ok) {
    throw new Error(resposta?.erro || "Falha ao comunicar com a aba da Biblioteca.");
  }
  return resposta;
}

function aplicarFiltrosLocais(anuncios = [], termo = "", config = {}, opcoes = {}) {
  const termoFinal = String(termo || "").trim();
  const diasMin = Number(config.diasMinFiltro || 0);
  const copiasMin = Number(config.copiasMinFiltro || 0);
  const palavrasNegativas = String(config.palavrasNegativas || "").trim();
  const segmento = String(config.segmentoAtivo || "").trim();
  /* As copias sao contadas sobre o lote inteiro (criativo repetido em varios
     cards), antes dos demais filtros, para bater com o badge do popup. */
  const mapaCopias = copiasMin > 1 ? mapearCopiasPorAnuncio(anuncios) : new Map();
  return anuncios
    .filter(Boolean)
    .filter((anuncio) => anuncioPassaStatus(anuncio, config.statusFiltro || "ACTIVE"))
    .filter((anuncio) => {
      if (!termoFinal || !opcoes.filtrarTermo) return true;
      return correspondeNicho(anuncio, termoFinal);
    })
    .filter((anuncio) => filtrarPorPalavrasNegativas(anuncio, palavrasNegativas))
    .filter((anuncio) => filtrarPorSegmento(anuncio, segmento))
    .filter((anuncio) => {
      if (copiasMin <= 1) return true;
      return contarCopiasAnuncio(anuncio, mapaCopias) >= copiasMin;
    })
    .filter((anuncio) => {
      if (diasMin <= 0) return true;
      return Number(anuncio.diasAtivo || 0) >= diasMin;
    })
    .map((anuncio) => enriquecerAnuncioComScore(anuncio))
    .sort((a, b) => prioridadeOferta(b) - prioridadeOferta(a));
}

/* Deixa o filtro de copias minimas visivel no status da busca. */
function sufixoCopiasMin(config = {}) {
  const minimo = Number(config.copiasMinFiltro || 0);
  return minimo > 1 ? ` (somente ofertas com ${minimo}+ copias)` : "";
}

function prioridadeOferta(anuncio = {}) {
  const texto = String(`${anuncio.tituloOferta || ""} ${anuncio.textoCompleto || ""} ${anuncio.entregavel || ""} ${anuncio.destino || ""}`).toLowerCase();
  let pontos = 0;
  if (/curso|pdf|ebook|e-book|aula|treinamento|mentoria|guia|apostila|p[aá]gina de vendas|checkout/.test(texto)) pontos += 100;
  if (/nutra|suplemento|c[aá]psula|capsula|comprimido/.test(texto)) pontos -= 20;
  pontos += Math.min(120, Number(anuncio.diasAtivo || 0));
  pontos += Math.min(80, Number(anuncio.variacoesAtivasEstimadas || anuncio.variacoesAtivas || 0) * 4);
  return pontos;
}

async function salvarEPublicarResultados(lote = [], config = {}, mensagem = "Busca concluida.") {
  const ofertas = lote.filter((a) => Number(a.scoreEscala || 0) >= 60);
  estadoBusca.resultados = lote;
  estadoBusca.totalProcessados = lote.length;
  estadoBusca.totalEscalados = ofertas.length;
  await salvarResultadosAtuaisStorage(true);
  await atualizarStatusProgresso({
    status: "concluido",
    totalEscalados: ofertas.length,
    totalProcessados: lote.length,
    mensagem
  });
  return ofertas;
}

function erroSemAnuncios(resposta = {}) {
  const diag = resposta.diagnostico || {};
  const cards = Number(diag.cardsDetectados || 0);
  const texto = Number(diag.bodyTextLength || 0);
  const url = String(diag.url || "");
  const temBusca = /[?&]q=/.test(url);
  let dica = "";
  if (cards === 0 && texto < 1000) {
    dica = " A pagina parece vazia (pouco texto). Talvez falte login no Facebook ou a Biblioteca ainda esteja carregando — tente de novo em alguns segundos.";
  } else if (!temBusca) {
    dica = " A aba esta no feed geral (sem termo na URL). Digite o termo direto na busca da Biblioteca e role a pagina para carregar anuncios antes de varrer.";
  } else {
    dica = " Role a Biblioteca ate aparecerem anuncios e clique no botao de novo.";
  }
  return `Nenhum anuncio foi coletado na Biblioteca aberta. Diagnostico: ${cards} card(s) detectado(s), ${texto} caracteres na pagina.${dica}`;
}

/* Aviso especifico quando o unico filtro ativo (copias minimas) zerou o lote. */
function erroSemCopiasMinimo(resposta = {}, config = {}) {
  const coletados = Array.isArray(resposta.anuncios) ? resposta.anuncios.length : 0;
  const copiasMin = Number(config.copiasMinFiltro || 0);
  if (copiasMin <= 1 || coletados <= 0) return "";
  return `Nenhum dos ${coletados} anuncios coletados tem ${copiasMin} copias ou mais. Reduza "Quantidade minima de copias" ou use 0 para buscar sem esse filtro.`;
}

let _contadorLoteVarredura = 0;
async function integrarLoteVarredura(anuncios = [], pagina = 0) {
  if (!estadoBusca.ativa || !Array.isArray(anuncios)) return;
  _contadorLoteVarredura += 1;
  if (_contadorLoteVarredura === 1) marcarFase("primeiroLoteRecebido");

  const idsConhecidos = new Set((estadoBusca.resultados || []).map((a) => a.idAnuncio));
  const novos = filtrarPorCopiasMin(
    (anuncios || []).filter((a) => a && !idsConhecidos.has(a.idAnuncio)),
    estadoBusca.copiasMinFiltro
  );
  if (!novos.length) return;

  novos.forEach((a) => estadoBusca.resultados.push(a));
  estadoBusca.totalProcessados = estadoBusca.resultados.length;
  estadoBusca.totalEscalados = estadoBusca.resultados.filter((a) => Number(a.scoreEscala || 0) >= 60).length;

  /* P6: notifica a UI a cada lote (percepcao de velocidade) mas bota a
     escrita em storage na tora via salvarResultadosAtuaisStorage. */
  await salvarResultadosAtuaisStorage();
  await atualizarStatusProgresso({
    status: "em_andamento",
    totalEscalados: estadoBusca.totalEscalados,
    totalProcessados: estadoBusca.totalProcessados,
    mensagem: estadoBusca.modo === "completa_profunda"
      ? `Aprofundando lote ${pagina}: ${estadoBusca.totalEscalados} oferta(s).`
      : `Varredura lote ${pagina}: ${estadoBusca.totalEscalados} oferta(s).`
  });
}

async function executarBuscaRapida(termo = "") {
  const config = await obterConfiguracoesBusca();
  const aba = await obterAbaBibliotecaObrigatoria();
  let termoFinal = String(termo || "").trim();
  const segmento = String(config.segmentoAtivo || "").trim();
  if (!termoFinal && segmento && TERMOS_SEGMENTO[segmento]) {
    termoFinal = TERMOS_SEGMENTO[segmento].split(" OR ")[0].trim();
  }
  if (!termoFinal) {
    termoFinal = "";
  }
  const inicioMs = performance.now();
  estadoBusca.marcadores = [];
  marcarFase("buscaRapidaInicio");

  /* F6: varredura NAO navega. A aba da Biblioteca ja esta aberta e o termo
     e aplicado localmente em aplicarFiltrosLocais — nada de recarregar. */
  await garantirContentScriptNaAba(aba.id);
  marcarFase("buscaRapidaAbaPronta");

  const resposta = await enviarMensagemBiblioteca(aba.id, { acao: "coletarAnunciosVisiveis", termo: termoFinal });
  if (!Array.isArray(resposta.anuncios) || resposta.anuncios.length === 0) throw new Error(erroSemAnuncios(resposta));
  const lote = aplicarFiltrosLocais(resposta.anuncios || [], termoFinal, config, { filtrarTermo: false });
  const totalOfertas = lote.length;
  if (totalOfertas === 0) {
    const semCopias = erroSemCopiasMinimo(resposta, config);
    if (semCopias) throw new Error(semCopias);
  }
  marcarFase("buscaRapidaConcluida");
  const duracaoS = Number(((performance.now() - inicioMs) / 1000).toFixed(1));
  const ofertas = await salvarEPublicarResultados(
    lote,
    config,
    `Busca rapida na Biblioteca: ${totalOfertas} oferta(s) encontrada(s) em ${duracaoS}s${sufixoCopiasMin(config)}.`
  );
  await chrome.storage.local.set({ ultimaVarreduraS: duracaoS });

  return {
    anuncios: lote,
    totalEscalados: ofertas.length,
    duracaoS
  };
}
async function executarBuscaNicho(termo = "") {
  const config = await obterConfiguracoesBusca();
  const segmento = String(config.segmentoAtivo || "").trim();
  const termoFinal = String(termo || "").trim() || (segmento && TERMOS_SEGMENTO[segmento] ? TERMOS_SEGMENTO[segmento].split(" OR ")[0].trim() : "");
  const inicioMs = performance.now();
  estadoBusca.marcadores = [];
  marcarFase("buscaNichoInicio");
  /* F6: usa a aba da Biblioteca ja aberta (sem abrir/recarregar) e filtra o
     termo localmente, que e exatamente o que o usuario pediu. */
  const tabId = (await obterAbaBibliotecaObrigatoria()).id;
  await garantirContentScriptNaAba(tabId);
  const aba = { id: tabId };
  const resposta = await enviarMensagemBiblioteca(aba.id, { acao: "coletarAnunciosVisiveis", termo: termoFinal });
  if (!Array.isArray(resposta.anuncios) || resposta.anuncios.length === 0) throw new Error(erroSemAnuncios(resposta));
  const lote = aplicarFiltrosLocais(resposta.anuncios || [], termoFinal, config, { filtrarTermo: true });
  const competitividade = calcularCompetitividadeNicho(lote);
  const totalOfertas = lote.length;
  if (totalOfertas === 0) {
    const semCopias = erroSemCopiasMinimo(resposta, config);
    if (semCopias) throw new Error(semCopias);
  }
  marcarFase("buscaNichoConcluida");
  const duracaoS = Number(((performance.now() - inicioMs) / 1000).toFixed(1));
  const ofertas = await salvarEPublicarResultados(
    lote,
    config,
    `Busca por nicho na Biblioteca: ${totalOfertas} oferta(s) encontrada(s) em ${duracaoS}s${sufixoCopiasMin(config)}.`
  );
  await chrome.storage.local.set({ ultimaVarreduraS: duracaoS });

  return {
    anuncios: lote,
    totalEscalados: ofertas.length,
    competitividade,
    duracaoS
  };
}
/* F6: a varredura nunca navega. Este texto apenas informa qual termo a aba
   ja aberta esta exibindo, para o usuario alinhar a busca manualmente. */
function descricaoContextoBiblioteca(urlAba = "") {
  const termoDaPagina = termoNaUrlDaBiblioteca(urlAba);
  return termoDaPagina
    ? `Biblioteca aberta em "${termoDaPagina}".`
    : "Biblioteca aberta no feed geral (sem termo na URL).";
}

async function abrirOuAtualizarAbaBiblioteca(termo = "", ativa = true) {
  const config = await obterConfiguracoesBusca();
  const url = montarUrlBiblioteca(config.pais, termo);
  const abas = await obterAbasBiblioteca();
  if (abas.length) {
    await chrome.tabs.update(abas[0].id, { url, active: ativa });
    return abas[0].id;
  }
  const aba = await chrome.tabs.create({ url, active: ativa });
  return aba.id;
}

async function executarVarreduraCompleta(termo = "", tempoMaximoMin = 0) {
  const config = await obterConfiguracoesBusca();
  const aba = await obterAbaBibliotecaObrigatoria();
  let termoFinal = String(termo || "").trim();
  const segmento = String(config.segmentoAtivo || "").trim();
  if (!termoFinal && segmento && TERMOS_SEGMENTO[segmento]) {
    termoFinal = TERMOS_SEGMENTO[segmento].split(" OR ")[0].trim();
  }
  if (!termoFinal) {
    termoFinal = "";
  }
  resetarEstadoBusca();
  estadoBusca.ativa = true;
  const minAprofundar = Number(tempoMaximoMin || 0);
  const modoProfundo = minAprofundar > 0;
  estadoBusca.modo = modoProfundo ? "completa_profunda" : "completa";
  const minEfetivo = Math.min(Math.max(minAprofundar, 1), TEMPO_MAXIMO_VARREDURA_PROFUNDA_MIN);
  const prazoMs = modoProfundo ? minEfetivo * 60000 - BUFFER_FINAL_MS : 0;
  if (modoProfundo) estadoBusca.prazoMs = prazoMs;
  estadoBusca.termoNicho = termoFinal;
  estadoBusca.copiasMinFiltro = Number(config.copiasMinFiltro || 0);
  estadoBusca.inicioMs = performance.now();
  estadoBusca.marcadores = [];
  marcarFase("inicioVarredura");

  await chrome.storage.local.set({ escaladosVarredura: 0, statusVarredura: "em_andamento" });
  await atualizarStatusProgresso({
    status: "em_andamento",
    totalEscalados: 0,
    totalProcessados: 0,
    mensagem: modoProfundo
      ? `Aprofundamento (até ${minEfetivo} min): preparando...`
      : "Varredura completa: preparando busca..."
  });

  /* F6: varredura NAO navega — apenas garante o content script na aba aberta. */
  await garantirContentScriptNaAba(aba.id);
  const contexto = descricaoContextoBiblioteca(aba.url || "");

  await atualizarStatusProgresso({
    status: "em_andamento",
    totalEscalados: 0,
    totalProcessados: 0,
    mensagem: modoProfundo
      ? `Aprofundamento: varrendo a Biblioteca aberta — ${contexto}`
      : `Varredura completa: varrendo a Biblioteca aberta — ${contexto}`
  });

  marcarFase("iniciandoLeituraDOM");
  const payloadAcao = { acao: "varrerBibliotecaCompleta", termo: termoFinal };
  if (prazoMs > 0) payloadAcao.tempoMaximoMs = prazoMs;
  const resposta = await enviarMensagemBiblioteca(aba.id, payloadAcao);
  marcarFase("leituraDOMConcluida");
  if (!Array.isArray(resposta.anuncios) || resposta.anuncios.length === 0) throw new Error(erroSemAnuncios(resposta));

  const listaAtual = aplicarFiltrosLocais(resposta.anuncios || [], termoFinal, config, { filtrarTermo: false });
  if (listaAtual.length === 0) {
    const semCopias = erroSemCopiasMinimo(resposta, config);
    if (semCopias) throw new Error(semCopias);
  }
  const escalados = listaAtual.filter((a) => {
    if (Number(a.scoreEscala || 0) >= 60) return true;
    if (Number(a.diasAtivo || 0) >= 100) return true;
    if (Number(a.variacoesAtivas || a.variacoesAtivasEstimadas || 0) >= 5) return true;
    return false;
  });
  estadoBusca.totalProcessados = listaAtual.length;
  estadoBusca.totalEscalados = escalados.length;
  estadoBusca.resultados = listaAtual;
  marcarFase("processamentoConcluido");

  const ultimaVarreduraS = Number(((performance.now() - estadoBusca.inicioMs) / 1000).toFixed(1));
  await chrome.storage.local.set({ escaladosVarredura: estadoBusca.totalEscalados, ultimaVarreduraS });
  await salvarResultadosAtuaisStorage(true);

  const statusFinal = estadoBusca.parar ? "parado" : "concluido";
  await atualizarStatusProgresso({
    status: statusFinal,
    totalEscalados: estadoBusca.totalEscalados,
    totalProcessados: estadoBusca.totalProcessados,
    ultimaVarreduraS,
    mensagem:
      statusFinal === "parado"
        ? "Varredura interrompida pelo usuario."
        : modoProfundo
          ? `Aprofundamento concluído: ${estadoBusca.totalEscalados} oferta(s) em ${ultimaVarreduraS}s${sufixoCopiasMin(config)}.`
          : `Varredura completa finalizada com ${estadoBusca.totalEscalados} oferta(s) em ${ultimaVarreduraS}s${sufixoCopiasMin(config)}.`
  });

  estadoBusca.ativa = false;
  return {
    anuncios: estadoBusca.resultados,
    totalEscalados: estadoBusca.totalEscalados,
    interrompida: estadoBusca.parar,
    ultimaVarreduraS,
    modo: modoProfundo ? "profunda" : "completa"
  };
}
async function exportarCsv(anuncios = []) {
  const csv = gerarCsv(anuncios);
  const url = `data:text/csv;charset=utf-8,${encodeURIComponent(csv)}`;
  const data = new Date().toISOString().slice(0, 10);
  await chrome.downloads.download({
    url,
    filename: `metaspy_${data}.csv`,
    saveAs: true
  });
}

/* ─── F4: fila de downloads em lote ─────────────────────── */

function urlDeVideoPermitida(url) {
  try {
    const u = new URL(url);
    return DOMINIOS_VIDEO_PERMITIDOS.some((d) => u.hostname === d || u.hostname.endsWith("." + d));
  } catch (e) {
    return false;
  }
}

function adicionarItensDownload(videos = []) {
  const ativos = new Set(
    filaDownloads.itens
      .filter((i) => i.status === "na_fila" || i.status === "baixando")
      .map((i) => i.url)
  );
  const data = new Date().toISOString().slice(0, 10);
  let adicionados = 0;
  (Array.isArray(videos) ? videos : []).forEach((v) => {
    const url = String(v.url || v.videoUrl || "").trim();
    if (!url || ativos.has(url) || !urlDeVideoPermitida(url)) return;
    ativos.add(url);
    const idAnuncio = String(v.idAnuncio || v.adId || "anuncio").replace(/[^\w.-]+/g, "_") || "anuncio";
    filaDownloads.itens.push({
      url,
      idAnuncio,
      filename: `${DOWNLOAD_LOTE_SUBPASTA}/${data}/${idAnuncio}.mp4`,
      status: "na_fila",
      adicionadoEm: new Date().toISOString(),
      downloadId: null,
      erro: ""
    });
    adicionados += 1;
  });
  return adicionados;
}

function emitirProgressoDownload() {
  const total = filaDownloads.itens.length;
  const concluidos = filaDownloads.itens.filter((i) => i.status === "concluido").length;
  const erros = filaDownloads.itens.filter((i) => i.status === "erro").length;
  chrome.runtime.sendMessage({
    tipo: "progressoDownloadLote",
    itens: filaDownloads.itens,
    total,
    concluidos,
    erros,
    ativos: filaDownloads.emAndamento
  }).catch(() => {});
  chrome.storage.local.set({
    metaspy_downloads_history: filaDownloads.itens.slice(-100)
  }).catch(() => {});
}

async function processarFilaDownloads() {
  if (filaDownloads.processando) return;
  filaDownloads.processando = true;
  try {
    while (filaDownloads.emAndamento < DOWNLOAD_LOTE_POOL) {
      const item = filaDownloads.itens.find((i) => i.status === "na_fila");
      if (!item) break;
      item.status = "baixando";
      filaDownloads.emAndamento += 1;
      try {
        const downloadId = await chrome.downloads.download({
          url: item.url,
          filename: item.filename,
          saveAs: false,
          conflictAction: "uniquify"
        });
        item.downloadId = downloadId;
        emitirProgressoDownload();
      } catch (erro) {
        item.status = "erro";
        item.erro = erro.message || "Falha ao iniciar download";
        filaDownloads.emAndamento = Math.max(0, filaDownloads.emAndamento - 1);
        emitirProgressoDownload();
      }
    }
  } finally {
    filaDownloads.processando = false;
  }
}

function atualizarItemPorDownloadId(downloadId, mutacao) {
  const item = filaDownloads.itens.find((i) => i.downloadId === downloadId);
  if (!item || item.status !== "baixando") return;
  mutacao(item);
  emitirProgressoDownload();
  filaDownloads.emAndamento = Math.max(0, filaDownloads.emAndamento - 1);
  processarFilaDownloads();
}

chrome.downloads.onChanged.addListener((delta) => {
  if (!delta.id) return;
  if (delta.state?.current === "complete") {
    atualizarItemPorDownloadId(delta.id, (item) => {
      item.status = "concluido";
      item.concluidoEm = new Date().toISOString();
    });
  } else if (delta.state?.current === "interrupted") {
    atualizarItemPorDownloadId(delta.id, (item) => {
      item.status = "erro";
      item.erro = delta.error?.current || "Download interrompido";
    });
  }
});

/* ─── F1: biblioteca de palavras-chave ──────────────────── */

let bibliotecaEmbutidaCache = null;

async function carregarBibliotecaEmbutida() {
  if (bibliotecaEmbutidaCache) return bibliotecaEmbutidaCache;
  try {
    const res = await fetch(chrome.runtime.getURL("keywords.json"));
    if (res.ok) {
      bibliotecaEmbutidaCache = await res.json();
      return bibliotecaEmbutidaCache;
    }
  } catch (e) { /* ignore */ }
  bibliotecaEmbutidaCache = {
    versao: 1,
    categorias: [
      {
        categoria: "Info",
        subcategorias: [
          { nome: "Cursos", palavrasChave: [{ termo: "curso", sinonimos: ["treinamento", "aula"] }] }
        ]
      }
    ]
  };
  return bibliotecaEmbutidaCache;
}

async function obterBibliotecaCompleta() {
  const dados = await chrome.storage.local.get(["bibliotecaPalavrasChave"]);
  const lib = dados.bibliotecaPalavrasChave || {};
  return {
    embutidas: await carregarBibliotecaEmbutida(),
    personalizadas: Array.isArray(lib.personalizadas) ? lib.personalizadas : [],
    favoritasEmbutidas: lib.favoritasEmbutidas || {},
    ocultasEmbutidas: lib.ocultasEmbutidas || {},
    ultimoUsoEmbutidas: lib.ultimoUsoEmbutidas || {}
  };
}

async function salvarBiblioteca(lib) {
  await chrome.storage.local.set({
    bibliotecaPalavrasChave: {
      personalizadas: lib.personalizadas || [],
      favoritasEmbutidas: lib.favoritasEmbutidas || {},
      ocultasEmbutidas: lib.ocultasEmbutidas || {},
      ultimoUsoEmbutidas: lib.ultimoUsoEmbutidas || {}
    }
  });
}

function normalizarTermoPalavra(termo) {
  return String(termo || "").trim();
}

async function adicionarPalavraPersonalizada({ termo, categoria = "Geral", sinonimos = [] }) {
  const termoLimpo = normalizarTermoPalavra(termo);
  if (!termoLimpo) throw new Error("Termo invalido.");
  const lib = await obterBibliotecaCompleta();
  if (lib.personalizadas.some((p) => p.termo === termoLimpo)) throw new Error("Esta palavra-chave ja existe.");
  lib.personalizadas.push({
    id: "u_" + Date.now(),
    termo: termoLimpo,
    categoria: String(categoria || "Geral").trim(),
    sinonimos: Array.isArray(sinonimos) ? sinonimos.filter(Boolean) : [],
    origemUsuario: true,
    favorito: false,
    vezesUsado: 0,
    ultimoUsoISO: "",
    criadoEm: new Date().toISOString()
  });
  await salvarBiblioteca(lib);
  return lib.personalizadas;
}

async function editarPalavraPersonalizada({ id, termo, categoria, sinonimos }) {
  const lib = await obterBibliotecaCompleta();
  const alvo = lib.personalizadas.find((p) => p.id === id);
  if (!alvo) throw new Error("Palavra-chave nao encontrada.");
  if (termo !== undefined) {
    const t = normalizarTermoPalavra(termo);
    if (!t) throw new Error("Termo invalido.");
    alvo.termo = t;
  }
  if (categoria !== undefined) alvo.categoria = String(categoria).trim();
  if (sinonimos !== undefined) alvo.sinonimos = Array.isArray(sinonimos) ? sinonimos.filter(Boolean) : [];
  await salvarBiblioteca(lib);
  return lib.personalizadas;
}

async function removerPalavraPersonalizada(id) {
  const lib = await obterBibliotecaCompleta();
  lib.personalizadas = lib.personalizadas.filter((p) => p.id !== id);
  await salvarBiblioteca(lib);
  return lib.personalizadas;
}

async function registrarUsoPalavra(termo) {
  const t = normalizarTermoPalavra(termo);
  if (!t) return;
  const lib = await obterBibliotecaCompleta();
  const personalizada = lib.personalizadas.find((p) => p.termo === t);
  if (personalizada) {
    personalizada.vezesUsado = Number(personalizada.vezesUsado || 0) + 1;
    personalizada.ultimoUsoISO = new Date().toISOString();
  } else {
    lib.ultimoUsoEmbutidas = lib.ultimoUsoEmbutidas || {};
    lib.ultimoUsoEmbutidas[t] = new Date().toISOString();
  }
  await salvarBiblioteca(lib);
}

async function alternarFavoritoPalavra({ termo, favorito, origemUsuario }) {
  const lib = await obterBibliotecaCompleta();
  if (origemUsuario) {
    const alvo = lib.personalizadas.find((p) => p.termo === termo);
    if (alvo) alvo.favorito = favorito === true;
  } else {
    lib.favoritasEmbutidas = lib.favoritasEmbutidas || {};
    if (favorito === true) lib.favoritasEmbutidas[termo] = true;
    else delete lib.favoritasEmbutidas[termo];
  }
  await salvarBiblioteca(lib);
  return lib;
}

/* ─── F5: presets de filtros + preferencias ─────────────── */

const STORAGE_PRESETS = "presetsFiltros";

async function obterPresets() {
  const dados = await chrome.storage.local.get([STORAGE_PRESETS]);
  const p = dados[STORAGE_PRESETS] || {};
  return {
    lista: Array.isArray(p.lista) ? p.lista : [],
    defaultId: p.defaultId || null
  };
}

async function salvarPresets(p) {
  await chrome.storage.local.set({
    [STORAGE_PRESETS]: { lista: p.lista || [], defaultId: p.defaultId || null }
  });
}

async function criarOuAtualizarPreset({ nome, filtros, tornarDefault }) {
  const nomeLimpo = String(nome || "").trim();
  if (!nomeLimpo) throw new Error("Informe um nome para o preset.");
  const presets = await obterPresets();
  let existente = presets.lista.find((pr) => pr.nome === nomeLimpo);
  if (existente) {
    existente.filtros = filtros || {};
    existente.atualizadoEm = new Date().toISOString();
  } else {
    existente = {
      id: "p_" + Date.now(),
      nome: nomeLimpo,
      filtros: filtros || {},
      criadoEm: new Date().toISOString()
    };
    presets.lista.push(existente);
  }
  if (tornarDefault === true || presets.lista.length === 1) presets.defaultId = existente.id;
  await salvarPresets(presets);
  return presets;
}

async function aplicarPreset(id) {
  const presets = await obterPresets();
  const preset = presets.lista.find((pr) => pr.id === id);
  if (!preset) throw new Error("Preset nao encontrado.");
  return preset;
}

async function removerPreset(id) {
  const presets = await obterPresets();
  presets.lista = presets.lista.filter((pr) => pr.id !== id);
  if (presets.defaultId === id) presets.defaultId = presets.lista[0]?.id || null;
  await salvarPresets(presets);
  return presets;
}

async function obterPreferencias() {
  const dados = await chrome.storage.local.get(["preferencias"]);
  return dados.preferencias || {
    tema: "escuro",
    atalhosAtivos: true,
    paisPadrao: "BR",
    limiteResultadosPorPagina: 100,
    abrirNovaAba: false
  };
}

function userAgentAleatorio() {
  const agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
  ];
  return agents[Math.floor(Math.random() * agents.length)];
}

async function fetchComTimeout(url, timeoutMs = 30000, opcoesExtras = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const headers = {
    "User-Agent": userAgentAleatorio(),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    "Accept-Encoding": "gzip, deflate, br",
    "DNT": "1",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Cache-Control": "max-age=0",
    ...(opcoesExtras.headers || {})
  };
  if (opcoesExtras.referrer) {
    headers["Referer"] = opcoesExtras.referrer;
  }
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      credentials: "omit",
      referrerPolicy: "no-referrer-when-downgrade",
      headers,
      redirect: "follow",
      ...opcoesExtras.fetchOpts
    });
    return res;
  } finally {
    clearTimeout(timer);
  }
}



async function definirTokenPadrao() {
  const stored = await chrome.storage.local.get(["apiToken"]);
  if (!stored.apiToken) {
    await chrome.storage.local.set({ apiToken: "EAAmpbRxZC9P0BRwOgIQ5FW6HAp9MEdhZBy81fepW2oelNPo5IQM5vX4JCcmSd9LbtEHuZAXygMseGZCyP5GlaESNWZA3jhpSEFSn3HyydmBGEmuKZCL49mBcinJbQutZBZCnpYo7b268OgzVywv4aaRdZB5jC2y9UZBdjQOZAAJh4pztrKbtNNR9Np2kRIwXx01dh2HazdOpb4q" });
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({
    escaladosVarredura: 0,
    statusVarredura: "parado",
    paisFiltro: "BR",
    statusFiltro: "ACTIVE",
    diasMinFiltro: DIAS_MIN_FOCO_PADRAO,
    copiasMinFiltro: 0,
    mostrarInativos: false,
    modoBibliotecaAberta: false,
    sincronizarBibliotecaBusca: false
  });
  const jaExistentes = await chrome.storage.local.get(["presetsFiltros", "preferencias", "ultimaVarreduraS", "bibliotecaPalavrasChave"]);
  const novasChaves = {};
  if (!jaExistentes.presetsFiltros) novasChaves.presetsFiltros = { lista: [], defaultId: null };
  if (!jaExistentes.preferencias) novasChaves.preferencias = {
    tema: "escuro",
    atalhosAtivos: true,
    paisPadrao: "BR",
    limiteResultadosPorPagina: 100,
    abrirNovaAba: false
  };
  if (jaExistentes.ultimaVarreduraS === undefined) novasChaves.ultimaVarreduraS = 0;
  if (!jaExistentes.bibliotecaPalavrasChave) novasChaves.bibliotecaPalavrasChave = {
    personalizadas: [],
    favoritasEmbutidas: {},
    ocultasEmbutidas: {},
    ultimoUsoEmbutidas: {}
  };
  if (Object.keys(novasChaves).length) await chrome.storage.local.set(novasChaves);
  await definirTokenPadrao();
});

definirTokenPadrao();

chrome.webNavigation.onCompleted.addListener(
  async (detalhes) => {
    if (detalhes.frameId !== 0) return;
    chrome.action.setBadgeText({ text: "ON", tabId: detalhes.tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#8b5cf6", tabId: detalhes.tabId });
    try {
      await garantirContentScriptNaAba(detalhes.tabId);
      console.log("[MetaSpy BG] Content script injetado/verificado na aba", detalhes.tabId);
    } catch (e) {
      console.debug("[MetaSpy BG] Falha ao injetar content script:", e);
    }
  },
  { url: [{ hostSuffix: "facebook.com", pathPrefix: "/ads/library" }] }
);

chrome.runtime.onMessage.addListener((mensagem, sender, sendResponse) => {
  (async () => {
    try {
      console.log("[MetaSpy BG] Mensagem recebida:", JSON.stringify(mensagem).slice(0, 300), "sender:", sender?.id?.slice(0, 20));

      if (mensagem?.tipo === "loteVarreduraBiblioteca") {
        await integrarLoteVarredura(mensagem.anuncios || [], mensagem.pagina || 0);
        sendResponse({ ok: true });
        return;
      }

      /* P6/P7: heartbeat periodico da varredura no content (contador ao vivo). */
      if (mensagem?.tipo === "heartbeatVarredura") {
        const agora = Date.now();
        if (!ultimoStatusProgressoMs || agora - ultimoStatusProgressoMs >= INTERVALO_STATUS_VARREDURA_MS) {
          ultimoStatusProgressoMs = agora;
          const payloadStorage = {
            escaladosVarredura: Number(mensagem.total || 0),
            statusVarredura: "em_andamento"
          };
          /* F2c: no modo aprofundado, expoe o tempo restante estimado. */
          if (estadoBusca.modo === "completa_profunda" && estadoBusca.prazoMs) {
            const restanteMin = Math.max(0, Math.ceil((estadoBusca.prazoMs - (Date.now() - estadoBusca.inicioMs)) / 60000));
            payloadStorage.restanteVarreduraMin = restanteMin;
          }
          await chrome.storage.local.set(payloadStorage);
        }
        sendResponse({ ok: true });
        return;
      }

      /* F2: o widget do MetaSpy publica o andamento do scan em tempo real,
         compartilhando os mesmos indicadores com o painel lateral. */
      if (mensagem?.tipo === "progressoScanWidget") {
        const totalEscalados = Number(mensagem.totalEscalados || 0);
        const totalProcessados = Number(mensagem.totalProcessados || 0);
        const agora = Date.now();
        if (!ultimoStatusProgressoMs || agora - ultimoStatusProgressoMs >= INTERVALO_STATUS_VARREDURA_MS) {
          ultimoStatusProgressoMs = agora;
          await chrome.storage.local.set({
            escaladosVarredura: totalEscalados,
            statusVarredura: "em_andamento"
          });
        }
        chrome.runtime.sendMessage({
          tipo: "progressoVarredura",
          status: "em_andamento",
          totalEscalados,
          totalProcessados,
          mensagem: `Scan do widget: ${totalEscalados} oferta(s) destacada(s).`
        }).catch(() => {});
        sendResponse({ ok: true });
        return;
      }

      /* P7: o content informa a duracao real da leitura DOM da varredura. */
      if (mensagem?.tipo === "varreduraFinalizada") {
        const duracaoMs = Number(mensagem.duracaoMs || 0);
        if (duracaoMs > 0) {
          await chrome.storage.local.set({
            ultimaVarreduraS: Number((duracaoMs / 1000).toFixed(1)),
            ultimaVarreduraEm: new Date().toISOString()
          });
        }
        marcarFase("contentVarreduraFinalizada");
        sendResponse({ ok: true });
        return;
      }

      if (mensagem?.acao === "togglePainelMetaSpy") {
        sendResponse({ ok: true });
        return;
      }

      const acao = mensagem?.acao;
      if (!acao) {
        sendResponse({ ok: false, erro: "Ação não informada." });
        return;
      }

      switch (acao) {
        case "iniciarBuscaRapida": {
          await limparOverlayEmAbas();
          const resultado = await executarBuscaRapida(mensagem.termo || "");
          sendResponse({ ok: true, ...resultado });
          break;
        }

        case "iniciarVarreduraCompleta": {
          if (estadoBusca.ativa) {
            sendResponse({ ok: false, erro: "Já existe uma varredura em andamento." });
            break;
          }
          await limparOverlayEmAbas();
          estadoBusca.parar = false;
          try {
            await obterAbaBibliotecaObrigatoria();
          } catch (e) {
            sendResponse({ ok: false, erro: e.message });
            break;
          }
          executarVarreduraCompleta(mensagem.termo || "", mensagem.tempoMaximoMin || 0).catch(async (erro) => {
            await atualizarStatusProgresso({
              status: "erro",
              mensagem: `Erro na varredura: ${erro.message}`,
              totalEscalados: estadoBusca.totalEscalados,
              totalProcessados: estadoBusca.totalProcessados
            });
            estadoBusca.ativa = false;
          });
          sendResponse({ ok: true, iniciado: true });
          break;
        }

        case "buscarPorNicho": {
          const termo = String(mensagem.termo || "").trim();
          if (!termo) {
            sendResponse({ ok: false, erro: "Informe um termo de nicho." });
            break;
          }
          await limparOverlayEmAbas();
          const resultado = await executarBuscaNicho(termo);
          sendResponse({ ok: true, ...resultado });
          break;
        }

        case "pararBusca": {
          estadoBusca.parar = true;
          estadoBusca.ativa = false;
          await limparOverlayEmAbas();
          await enviarPararVarreduraParaAbas();
          await atualizarStatusProgresso({
            status: "parado",
            mensagem: "Busca interrompida pelo usuário.",
            totalEscalados: estadoBusca.totalEscalados,
            totalProcessados: estadoBusca.totalProcessados
          });
          sendResponse({ ok: true });
          break;
        }

        case "obterStatusBusca": {
          const storage = await chrome.storage.local.get(["escaladosVarredura", "statusVarredura", "ultimaVarreduraS"]);
          sendResponse({
            ok: true,
            ativa: estadoBusca.ativa,
            totalEscalados: Number(storage.escaladosVarredura || estadoBusca.totalEscalados || 0),
            totalProcessados: estadoBusca.totalProcessados,
            statusVarredura: storage.statusVarredura || "parado",
            ultimaVarreduraS: Number(storage.ultimaVarreduraS || 0),
            marcadores: estadoBusca.marcadores
          });
          break;
        }

        case "garantirBibliotecaAberta": {
          const id = await abrirOuAtualizarAbaBiblioteca(mensagem.termo || "", false);
          sendResponse({ ok: true, tabId: id });
          break;
        }

        case "diagnosticarBiblioteca": {
          const aba = await obterAbaBibliotecaObrigatoria();
          const diagnostico = await enviarMensagemBiblioteca(aba.id, { acao: "diagnosticoMetaSpy" });
          sendResponse({ ok: true, ...diagnostico });
          break;
        }

        case "obterResultadosAtuais": {
          const storage = await chrome.storage.local.get([STORAGE_RESULTADOS_ATUAIS, STORAGE_TOTAL_ESCALADOS]);
          const anuncios = estadoBusca.resultados?.length
            ? estadoBusca.resultados
            : Array.isArray(storage[STORAGE_RESULTADOS_ATUAIS])
              ? storage[STORAGE_RESULTADOS_ATUAIS]
              : [];
          sendResponse({
            ok: true,
            anuncios,
            totalEscalados: estadoBusca.totalEscalados || Number(storage[STORAGE_TOTAL_ESCALADOS] || 0)
          });
          break;
        }

        /* F2b: o widget publica no background os mesmos anuncios destacados,
           e o painel lateral passa a exibir exatamente esses resultados. */
        case "publicarResultadosScan": {
          const anuncios = Array.isArray(mensagem.anuncios) ? mensagem.anuncios : [];
          const enriquecidos = anuncios
            .filter(Boolean)
            .map((a) => enriquecerAnuncioComScore(a));
          estadoBusca.ativa = false;
          estadoBusca.parar = false;
          estadoBusca.modo = "widget";
          estadoBusca.resultados = enriquecidos;
          estadoBusca.totalProcessados = enriquecidos.length;
          estadoBusca.totalEscalados = enriquecidos.filter((a) => Number(a.scoreEscala || 0) >= 60).length;
          const ultimaVarreduraS = Number(mensagem.duracaoS || 0);
          const extrasStorage = {};
          if (ultimaVarreduraS > 0) extrasStorage.ultimaVarreduraS = ultimaVarreduraS;
          await chrome.storage.local.set({
            ...extrasStorage,
            escaladosVarredura: estadoBusca.totalEscalados,
            statusVarredura: "concluido"
          });
          await salvarResultadosAtuaisStorage(true);
          await atualizarStatusProgresso({
            status: "concluido",
            totalEscalados: estadoBusca.totalEscalados,
            totalProcessados: estadoBusca.totalProcessados,
            ultimaVarreduraS,
            mensagem: mensagem.mensagem || `Scan concluído: ${estadoBusca.totalEscalados} oferta(s).`
          });
          sendResponse({ ok: true, totalEscalados: estadoBusca.totalEscalados, totalProcessados: estadoBusca.totalProcessados });
          break;
        }

        case "salvarFavorito": {
          if (!mensagem.anuncio?.idAnuncio) {
            sendResponse({ ok: false, erro: "Anúncio inválido para favorito." });
            break;
          }
          await dbPut(STORE_FAVORITOS, {
            ...mensagem.anuncio,
            favoritadoEm: new Date().toISOString()
          });
          sendResponse({ ok: true });
          break;
        }

        case "obterFavoritos": {
          const favoritos = await dbGetAll(STORE_FAVORITOS);
          sendResponse({ ok: true, favoritos });
          break;
        }

        case "removerFavorito": {
          if (!mensagem.idAnuncio) {
            sendResponse({ ok: false, erro: "ID inválido para remoção." });
            break;
          }
          await dbDelete(STORE_FAVORITOS, String(mensagem.idAnuncio));
          sendResponse({ ok: true });
          break;
        }

        case "exportarCsv": {
          const anuncios = Array.isArray(mensagem.anuncios) ? mensagem.anuncios : [];
          await exportarCsv(anuncios);
          sendResponse({ ok: true });
          break;
        }

        case "obterTokenApi": {
          const token = await obterTokenApi();
          sendResponse({ ok: true, token });
          break;
        }

        case "salvarTokenApi": {
          const token = String(mensagem.token || "").trim();
          if (!token) {
            sendResponse({ ok: false, erro: "Token inválido." });
            break;
          }
          await chrome.storage.local.set({ apiToken: token });
          cenarioSessao = { token: "", indice: -1 };
          sendResponse({ ok: true });
          break;
        }

        case "testarApi": {
          const token = await obterTokenApi();
          if (!token) {
            sendResponse({ ok: false, erro: "Token da API nao configurado. Adicione um token nas configuracoes." });
            break;
          }
          const config = await obterConfiguracoesBusca();
          const { json, cenario } = await requisicaoApiRobusta({
            token,
            termo: "",
            limite: 1,
            pais: config.pais,
            statusFiltro: config.statusFiltro
          });
          sendResponse({ ok: true, total: Array.isArray(json.data) ? json.data.length : 0, cenario });
          break;
        }
        case "salvarConfiguracoesBusca": {
          const statusFiltro = String(mensagem.statusFiltro || "ACTIVE").toUpperCase();
          await chrome.storage.local.set({
            paisFiltro: normalizarPais(mensagem.paisFiltro || "BR"),
            statusFiltro,
            diasMinFiltro: Math.max(0, Number(mensagem.diasMinFiltro ?? DIAS_MIN_FOCO_PADRAO)),
            copiasMinFiltro: Math.max(0, Math.floor(Number(mensagem.copiasMinFiltro || 0))),
            mostrarInativos: statusFiltro !== "ACTIVE",
            modoBibliotecaAberta: mensagem.modoBibliotecaAberta === true,
            sincronizarBibliotecaBusca: mensagem.modoBibliotecaAberta === true,
            segmentoAtivo: String(mensagem.segmentoAtivo || "").trim(),
            palavrasNegativas: String(mensagem.palavrasNegativas || "").trim()
          });
          sendResponse({ ok: true });
          break;
        }

        case "obterConfiguracoesBusca": {
          const config = await obterConfiguracoesBusca();
          sendResponse({ ok: true, ...config });
          break;
        }

        case "salvarCache": {
          await dbPut(STORE_CACHE, {
            chave: mensagem.chave,
            valor: mensagem.valor,
            criadoEm: Date.now()
          });
          sendResponse({ ok: true });
          break;
        }

        case "downloadVideo": {
          const videoUrl = String(mensagem.url || "").trim();
          if (!videoUrl) {
            sendResponse({ ok: false, erro: "URL do vídeo não informada." });
            break;
          }
          if (!urlDeVideoPermitida(videoUrl)) {
            sendResponse({ ok: false, erro: "URL de video invalida. Permitido apenas dominios do Facebook." });
            break;
          }
          const filename = String(mensagem.filename || `metaspy_video_${Date.now()}.mp4`).trim();
          try {
            await chrome.downloads.download({ url: videoUrl, filename, saveAs: true });
            sendResponse({ ok: true, filename });
          } catch (erro) {
            sendResponse({ ok: false, erro: erro.message || "Falha ao iniciar download." });
          }
          break;
        }

        case "iniciarDownloadLote": {
          const videos = Array.isArray(mensagem.videos) ? mensagem.videos : [];
          if (!videos.length) {
            sendResponse({ ok: false, erro: "Nenhum video informado para download." });
            break;
          }
          const adicionados = adicionarItensDownload(videos);
          emitirProgressoDownload();
          processarFilaDownloads();
          sendResponse({ ok: true, adicionados, total: filaDownloads.itens.length });
          break;
        }

        case "obterFilaDownloads": {
          sendResponse({ ok: true, itens: filaDownloads.itens, emAndamento: filaDownloads.emAndamento });
          break;
        }

        case "limparFilaDownloads": {
          const feitos = new Set(["concluido", "erro"]);
          filaDownloads.itens = filaDownloads.itens.filter((i) => !feitos.has(i.status));
          emitirProgressoDownload();
          sendResponse({ ok: true });
          break;
        }

        case "obterCache": {
          const cache = await dbGet(STORE_CACHE, mensagem.chave);
          sendResponse({ ok: true, valor: cache?.valor || null });
          break;
        }

        case "salvarSegmento": {
          await chrome.storage.local.set({ segmentoAtivo: String(mensagem.segmento || "").trim() });
          sendResponse({ ok: true });
          break;
        }

        case "salvarPalavrasNegativas": {
          await chrome.storage.local.set({ palavrasNegativas: String(mensagem.palavras || "").trim() });
          sendResponse({ ok: true });
          break;
        }

        case "limparResultados": {
          estadoBusca.resultados = [];
          estadoBusca.totalEscalados = 0;
          estadoBusca.totalProcessados = 0;
          await chrome.storage.local.set({
            [STORAGE_RESULTADOS_ATUAIS]: [],
            [STORAGE_TOTAL_ESCALADOS]: 0,
            escaladosVarredura: 0,
            statusVarredura: "parado"
          });
          sendResponse({ ok: true });
          break;
        }

        case "obterBibliotecaPalavras": {
          const lib = await obterBibliotecaCompleta();
          sendResponse({ ok: true, ...lib });
          break;
        }

        case "adicionarPalavraChave": {
          const personalizadas = await adicionarPalavraPersonalizada(mensagem);
          sendResponse({ ok: true, personalizadas });
          break;
        }

        case "editarPalavraChave": {
          const personalizadas = await editarPalavraPersonalizada(mensagem);
          sendResponse({ ok: true, personalizadas });
          break;
        }

        case "removerPalavraChave": {
          const personalizadas = await removerPalavraPersonalizada(String(mensagem.id || ""));
          sendResponse({ ok: true, personalizadas });
          break;
        }

        case "registrarUsoPalavra": {
          await registrarUsoPalavra(mensagem.termo);
          sendResponse({ ok: true });
          break;
        }

        case "alternarFavoritoPalavra": {
          const lib = await alternarFavoritoPalavra(mensagem);
          sendResponse({ ok: true, ...lib });
          break;
        }

        case "obterPresetsFiltros": {
          const presets = await obterPresets();
          sendResponse({ ok: true, ...presets });
          break;
        }

        case "salvarPresetFiltro": {
          const presets = await criarOuAtualizarPreset(mensagem);
          sendResponse({ ok: true, ...presets });
          break;
        }

        case "aplicarPresetFiltro": {
          const preset = await aplicarPreset(String(mensagem.id || ""));
          sendResponse({ ok: true, preset });
          break;
        }

        case "removerPresetFiltro": {
          const presets = await removerPreset(String(mensagem.id || ""));
          sendResponse({ ok: true, ...presets });
          break;
        }

        case "obterPreferencias": {
          const preferencias = await obterPreferencias();
          sendResponse({ ok: true, preferencias });
          break;
        }

        case "salvarPreferencias": {
          const preferencias = await obterPreferencias();
          await chrome.storage.local.set({
            preferencias: { ...preferencias, ...(mensagem.preferencias || {}) }
          });
          sendResponse({ ok: true, preferencias: { ...preferencias, ...(mensagem.preferencias || {}) } });
          break;
        }

        default:
          sendResponse({ ok: false, erro: `Ação não suportada: ${acao}` });
      }
    } catch (erro) {
      console.error("MetaSpy: erro no background:", erro);
      const detalhes = erro?.raw ? ` | detalhe API: ${JSON.stringify(erro.raw)}` : "";
      sendResponse({ ok: false, erro: (erro.message || "Erro inesperado no background.") + detalhes });
    }
  })();
  return true;
});
