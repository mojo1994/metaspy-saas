﻿"use strict";

(function iniciarPopupMetaSpy() {
  if (!window.MetaSpyUtils) return;

  if (window.top === window.self) {
    document.body.style.width = "340px";
    document.body.style.minHeight = "360px";
    
    async function initDashboard() {
      var result = await chrome.storage.local.get(["userEmail"]);
      var loginView = document.getElementById("loginView");
      var dashView = document.getElementById("dashboardView");
      var configView = document.getElementById("configView");
      var appView = document.getElementById("appPrincipal");
      if (!result.userEmail) {
        if (loginView) loginView.classList.remove("oculto");
        if (dashView) dashView.classList.add("oculto");
        if (configView) configView.classList.add("oculto");
        if (appView) appView.classList.add("oculto");
        return;
      }
      if (loginView) loginView.classList.add("oculto");
      if (configView) configView.classList.add("oculto");
      if (appView) appView.classList.add("oculto");
      if (dashView) dashView.classList.remove("oculto");
      var configEmail = document.getElementById("configEmail");
      if (configEmail) configEmail.textContent = result.userEmail;
    }
    
    initDashboard();
    
    var loginForm = document.getElementById("loginForm");
    if (loginForm) {
      loginForm.addEventListener("submit", async function(e) {
        e.preventDefault();
        var emailInput = document.getElementById("loginEmail");
        var email = emailInput ? emailInput.value.trim().toLowerCase() : "";
        if (!email) return;
        var SUPABASE_URL = "https://qzqyzhscckizucrzywck.supabase.co";
        var SUPABASE_KEY = "sb_publishable_3J2ww_4u-H7gPLXUz4hfsg_pe9mYGbO";
        try {
          var response = await fetch(
            `${SUPABASE_URL}/rest/v1/licencas?email=eq.${encodeURIComponent(email)}&select=status`,
            {
              method: "GET",
              headers: {
                "apikey": SUPABASE_KEY,
                "Authorization": `Bearer ${SUPABASE_KEY}`,
                "Content-Type": "application/json"
              }
            }
          );
          var dados = await response.json();
          if (dados && dados.length > 0 && dados[0].status === "ativo") {
            await chrome.storage.local.set({ userEmail: email });
            document.getElementById("loginView").classList.add("oculto");
            document.getElementById("dashboardView").classList.remove("oculto");
            var configEmail = document.getElementById("configEmail");
            if (configEmail) configEmail.textContent = email;
          } else {
            var erroEl = document.getElementById("loginErro");
            if (erroEl) {
              erroEl.textContent = "E-mail não encontrado ou assinatura inativa.";
              erroEl.classList.remove("oculto");
            }
          }
        } catch (err) {
          var erroEl = document.getElementById("loginErro");
          if (erroEl) {
            erroEl.textContent = "Erro de conexão. Tente novamente.";
            erroEl.classList.remove("oculto");
          }
        }
      });
    }

    var btnConfig = document.getElementById("btnConfig");
    if (btnConfig) {
      btnConfig.addEventListener("click", function() {
        document.getElementById("dashboardView").classList.add("oculto");
        document.getElementById("configView").classList.remove("oculto");
      });
    }
    var btnVoltarConfig = document.getElementById("btnVoltarConfig");
    if (btnVoltarConfig) {
      btnVoltarConfig.addEventListener("click", function() {
        document.getElementById("configView").classList.add("oculto");
        document.getElementById("dashboardView").classList.remove("oculto");
      });
    }
    var btnTrocarUsuario = document.getElementById("btnTrocarUsuario");
    if (btnTrocarUsuario) {
      btnTrocarUsuario.addEventListener("click", async function() {
        await chrome.storage.local.remove("userEmail");
        await chrome.storage.local.remove("metaspy_session");
        document.getElementById("configView").classList.add("oculto");
        document.getElementById("dashboardView").classList.add("oculto");
        document.getElementById("loginView").classList.remove("oculto");
      });
    }
    
    var btn = document.getElementById("btnMinerarOfertas");
    if (btn) {
      btn.addEventListener("click", async function () {
        var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tabs[0]?.id) { window.close(); return; }
        try {
          await chrome.tabs.sendMessage(tabs[0].id, { acao: "togglePainelMetaSpy" });
        } catch (e) {
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tabs[0].id },
              files: ["utils.js", "content-script.js"]
            });
            await new Promise(function (r) { setTimeout(r, 400); });
            await chrome.tabs.sendMessage(tabs[0].id, { acao: "togglePainelMetaSpy" });
          } catch (e2) {
            console.debug("[MetaSpy Popup] Falha ao injetar content script:", e2);
          }
        }
        window.close();
      });
    }
    return;
  }

  const { debounce, formatarDataBr, normalizarTexto, sanitizarHtml, filtrarTextoUtil, ehRealmenteAtivo, esperar } = window.MetaSpyUtils;

  const SUPABASE_URL = "https://qzqyzhscckizucrzywck.supabase.co";
  const SUPABASE_KEY = "sb_publishable_3J2ww_4u-H7gPLXUz4hfsg_pe9mYGbO";

  async function verificarAssinatura(emailDigitado) {
    const emailFormatado = emailDigitado.trim().toLowerCase();
    try {
      const response = await fetch(
        `${SUPABASE_URL}/rest/v1/licencas?email=eq.${encodeURIComponent(emailFormatado)}&select=status`,
        {
          method: "GET",
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`,
            "Content-Type": "application/json"
          }
        }
      );
      const dados = await response.json();
      if (dados && dados.length > 0 && dados[0].status === "ativo") {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error("[MetaSpy] Erro ao validar licença:", error);
      return false;
    }
  }

  function exibirPainelPrincipal() {
    var loginView = document.getElementById("loginView");
    var dashView = document.getElementById("dashboardView");
    var configView = document.getElementById("configView");
    var appView = document.getElementById("appPrincipal");
    if (loginView) loginView.classList.add("oculto");
    if (configView) configView.classList.add("oculto");
    if (window.top !== window.self) {
      if (dashView) dashView.classList.add("oculto");
      if (appView) appView.classList.remove("oculto");
    } else {
      if (dashView) dashView.classList.remove("oculto");
      if (appView) appView.classList.add("oculto");
    }
  }

  function exibirTelaLogin(mensagem) {
    var loginView = document.getElementById("loginView");
    var dashView = document.getElementById("dashboardView");
    var configView = document.getElementById("configView");
    var appView = document.getElementById("appPrincipal");
    var erroEl = document.getElementById("loginErro");
    if (loginView) loginView.classList.remove("oculto");
    if (dashView) dashView.classList.add("oculto");
    if (configView) configView.classList.add("oculto");
    if (appView) appView.classList.add("oculto");
    if (mensagem && erroEl) {
      erroEl.textContent = mensagem;
      erroEl.classList.remove("oculto");
    }
  }

  async function inicializarLogin() {
    var loginView = document.getElementById("loginView");
    if (!loginView) {
      return;
    }
    var result = await chrome.storage.local.get(["userEmail", "metaspy_session"]);
    if (result.userEmail) {
      var ativo = await verificarAssinatura(result.userEmail);
      if (ativo) {
        exibirPainelPrincipal();
        return;
      } else {
        exibirTelaLogin("Assinatura inativa ou cancelada.");
        return;
      }
    }
    exibirTelaLogin();
  }

  var loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", async function(e) {
      e.preventDefault();
      var emailInput = document.getElementById("loginEmail");
      var email = emailInput ? emailInput.value.trim().toLowerCase() : "";
      if (!email) return;
      var erroEl = document.getElementById("loginErro");
      if (erroEl) erroEl.classList.add("oculto");
      var ativo = await verificarAssinatura(email);
      if (ativo) {
        await chrome.storage.local.set({ userEmail: email });
        await chrome.storage.local.set({
          metaspy_session: { nome: "MetaSpy", loggedInAt: Date.now() }
        });
        exibirPainelPrincipal();
      } else {
        exibirTelaLogin("E-mail não encontrado ou assinatura inativa.");
      }
    });
  }

  async function logout() {
    await chrome.storage.local.remove("metaspy_session");
    await chrome.storage.local.remove("userEmail");
    exibirTelaLogin();
  }

  const estado = {
    anuncios: [],
    filtrados: [],
    pagina: 0,
    tamanhoLote: 20,
    carregando: false,
    emVarredura: false,
    anuncioSelecionado: null,
    anteriorResultados: null,
    mostrandoFavoritos: false,
    mapaCopias: new Map()
  };

  const el = {
    statusBadge: document.getElementById("statusBadge"),
    btnBuscaRapida: document.getElementById("btnBuscaRapida"),
    btnVarredura: document.getElementById("btnVarredura"),
    tempoVarreduraProfundoMin: document.getElementById("tempoVarreduraProfundoMin"),
    btnNicho: document.getElementById("btnNicho"),
    btnParar: document.getElementById("btnParar"),
    secaoNicho: document.getElementById("secaoNicho"),
    inputNicho: document.getElementById("inputNicho"),
    btnAplicarNicho: document.getElementById("btnAplicarNicho"),
    filtroOrdenacao: document.getElementById("filtroOrdenacao"),
    filtroPlataforma: document.getElementById("filtroPlataforma"),
    filtroPais: document.getElementById("filtroPais"),
    filtroStatusApi: document.getElementById("filtroStatusApi"),
    filtroMidia: document.getElementById("filtroMidia"),
    filtroCopiasMin: document.getElementById("filtroCopiasMin"),
    filtroDiasMin: document.getElementById("filtroDiasMin"),
    filtroDestino: document.getElementById("filtroDestino"),
    filtroEntregavel: document.getElementById("filtroEntregavel"),
    filtroTodos: document.getElementById("filtroTodos"),
    filtroNutra: document.getElementById("filtroNutra"),
    filtroInfo: document.getElementById("filtroInfo"),
    inputNegativas: document.getElementById("inputNegativas"),
    btnRestaurarFiltroAvancado: document.getElementById("btnRestaurarFiltroAvancado"),
    barraProgressoWrap: document.getElementById("barraProgressoWrap"),
    barraProgresso: document.getElementById("barraProgresso"),
    progressoLabel: document.getElementById("progressoLabel"),
    skeletonWrap: document.getElementById("skeletonWrap"),
    alerta: document.getElementById("alerta"),
    btnVoltar: document.getElementById("btnVoltar"),
    contadorResultados: document.getElementById("contadorResultados"),
    contadorEscalados: document.getElementById("contadorEscalados"),
    listaResultados: document.getElementById("listaResultados"),
    btnCarregarMais: document.getElementById("btnCarregarMais"),
    btnExportar: document.getElementById("btnExportar"),
    modalDetalhes: document.getElementById("modalDetalhes"),
    fecharModal: document.getElementById("fecharModal"),
    modalTitulo: document.getElementById("modalTitulo"),
    modalMidia: document.getElementById("modalMidia"),
    modalTexto: document.getElementById("modalTexto"),
    modalInfos: document.getElementById("modalInfos"),
    btnAbrirMeta: document.getElementById("btnAbrirMeta"),
    btnPaginaVendas: document.getElementById("btnPaginaVendas"),
    btnAbrirWhatsApp: document.getElementById("btnAbrirWhatsApp"),
    btnSalvarFavorito: document.getElementById("btnSalvarFavorito"),
    btnLimpar: document.getElementById("btnLimpar"),
    modalAnalise: document.getElementById("modalAnalise"),
    fecharAnalise: document.getElementById("fecharAnalise"),
    analiseConteudo: document.getElementById("analiseConteudo"),
    analiseTitulo: document.getElementById("analiseTitulo"),
    tokenApi: document.getElementById("tokenApi")
  };

  /* â”€â”€â”€ Estado e elementos das Ferramentas â”€â”€ */

  const CHAVE_HISTORICO_DOWNLOADS = "metaspy_downloads_history";

  function carregarHistoricoDownloads() {
    try {
      const raw = localStorage.getItem(CHAVE_HISTORICO_DOWNLOADS);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  }

  function salvarHistoricoDownloads(lista) {
    try {
      localStorage.setItem(CHAVE_HISTORICO_DOWNLOADS, JSON.stringify(lista.slice(0, 50)));
    } catch {}
  }

  function adicionarAoHistorico(entry) {
    const lista = carregarHistoricoDownloads();
    lista.unshift({
      ...entry,
      data: new Date().toISOString()
    });
    salvarHistoricoDownloads(lista);
    renderizarHistoricoDownloads();
  }

  function renderizarHistoricoDownloads() {
    const lista = carregarHistoricoDownloads();
    const container = document.getElementById("listaHistoricoDownloads");
    if (!container) return;

    if (!lista.length) {
      container.innerHTML = '<div style="color:var(--texto-sec);font-size:11px;padding:4px 0;">Nenhum download registrado.</div>';
      return;
    }

    container.innerHTML = "";
    lista.slice(0, 15).forEach((item, idx) => {
      const div = document.createElement("div");
      div.className = "item-historico";
      const label = item.adId || item.url?.slice(0, 50) || "Vídeo";
      const data = item.data ? new Date(item.data).toLocaleString("pt-BR") : "";
      var infoDiv = document.createElement("div");
      infoDiv.className = "item-historico-info";
      infoDiv.title = item.url || "";
      infoDiv.appendChild(document.createTextNode(sanitizarHtml(label)));
      var small = document.createElement("small");
      small.textContent = data;
      infoDiv.appendChild(small);

      var acoesDiv = document.createElement("div");
      acoesDiv.className = "item-historico-acoes";
      var btnDown = document.createElement("button");
      btnDown.className = "btn-redownload";
      btnDown.dataset.url = item.url || "";
      btnDown.dataset.filename = item.filename || "";
      btnDown.textContent = "⬇";
      var btnCopy = document.createElement("button");
      btnCopy.className = "btn-copiar-link";
      btnCopy.dataset.url = item.url || "";
      btnCopy.textContent = "📋";
      acoesDiv.appendChild(btnDown);
      acoesDiv.appendChild(btnCopy);

      div.appendChild(infoDiv);
      div.appendChild(acoesDiv);
      container.appendChild(div);
    });

    container.querySelectorAll(".btn-redownload").forEach((btn) => {
      btn.addEventListener("click", () => {
        const url = btn.dataset.url;
        const filename = btn.dataset.filename;
        if (url) baixarVideoUrl(url, filename);
      });
    });

    container.querySelectorAll(".btn-copiar-link").forEach((btn) => {
      btn.addEventListener("click", () => {
        navigator.clipboard.writeText(btn.dataset.url).catch(() => {});
      });
    });
  }

  const elFerramentas = {
    btnPublicarNetlify: document.getElementById("btnPublicarNetlify"),
    btnCapturarVideos: document.getElementById("btnCapturarVideos")
  };

  /* --- Funcoes das Ferramentas --- */

  function handlePublicarNetlify() {
    chrome.tabs.create({ url: "https://app.netlify.com" });
  }
  async function send(msg) {
    console.log("[MetaSpy Popup] Enviando mensagem:", JSON.stringify(msg).slice(0, 200));
    try {
      const resposta = await chrome.runtime.sendMessage(msg);
      console.log("[MetaSpy Popup] Resposta:", JSON.stringify(resposta).slice(0, 300));
      return resposta;
    } catch (erro) {
      console.error("[MetaSpy Popup] Erro no sendMessage:", erro);
      return { ok: false, erro: erro.message };
    }
  }

  function setAlerta(msg = "", exibir = false) {
    if (!msg || !exibir) {
      el.alerta.classList.add("oculto");
      el.alerta.textContent = "";
      return;
    }
    el.alerta.textContent = msg;
    el.alerta.classList.remove("oculto");
  }

  function setLoading(ativo, mensagem = "Processando...") {
    estado.carregando = ativo;
    el.skeletonWrap.classList.toggle("oculto", !ativo);
    el.barraProgressoWrap.classList.toggle("oculto", !ativo);
    el.btnParar.classList.toggle("oculto", !ativo);
    el.progressoLabel.textContent = mensagem;
    if (!ativo) {
      el.barraProgresso.style.width = "100%";
      setTimeout(() => el.barraProgressoWrap.classList.add("oculto"), 300);
    } else {
      el.barraProgresso.style.width = "14%";
    }
  }

  function atualizarProgresso(percentual, mensagem = "") {
    const valor = Math.max(0, Math.min(100, Number(percentual || 0)));
    el.barraProgresso.style.width = `${valor}%`;
    if (mensagem) el.progressoLabel.textContent = mensagem;
  }

  function badgeScore(anuncio) {
    const score = Number(anuncio.scoreEscala || 0);
    const dias = Number(anuncio.diasAtivo || 0);
    if (score >= 80) return { texto: "ALTA ESCALA", classe: "alta" };
    if (score >= 60 || dias >= 150) return { texto: "ESCALADA", classe: "escalando" };
    return { texto: "TESTANDO", classe: "testando" };
  }

  function detectarEstruturas(texto = "") {
    const t = normalizarTexto(texto);
    const estruturas = [];
    if (/quiz|responda|descubra|teste|pergunta|questionario|resultado|qual (e|é) (o|seu)|vamos descobrir|calcule|simule/.test(t)) estruturas.push("Quiz");
    if (/instagram|reels|perfil do instagram|seguidores|direct|story/.test(t)) estruturas.push("Instagram");
    if (/whatsapp|zap|grupo (do )?whatsapp|link do whatsapp|fale conosco|chame no whats/.test(t)) estruturas.push("WhatsApp");
    if (/youtube|canal do youtube|se inscreva|subscribe|assista o video|acesse o video/.test(t)) estruturas.push("YouTube");
    if (/webinar|ao vivo|live|seminario|masterclass|aula gratuita|workshop gratuito|transmissao/.test(t)) estruturas.push("Webinar");
    if (/pdf|ebook|e.?book|apostila|guia gratuito|material gratuito|download gratuito|baixe agora/.test(t)) estruturas.push("Lead Magnet");
    if (/consultoria|mentoria|coaching|agenda (uma )?chamada|ligacao|privado|personalizado|sessao|acompanhamento/.test(t)) estruturas.push("X1 / Mentoria");
    if (/bridge|tsl|tripwire|pagina de vendas|checkout|compra (agora|unica)|oferta unica|pagina unica/.test(t)) estruturas.push("TSL / Bridge");
    if (/pagina de captura|captura|lead|inscreva-se|cadastre-se|receber (gratis|gratuito)/.test(t)) estruturas.push("Pagina de Captura");
    if (/checkout|comprar|pagamento|carrinho|finalizar compra|pedido/.test(t)) estruturas.push("Checkout Direto");
    if (!estruturas.length) estruturas.push("Indefinido");
    return estruturas;
  }

  function inferirEntregavelPorTermo(termo = "") {
    const texto = normalizarTexto(termo);
    if (/pdf|ebook|e-book|apostila|guia/.test(texto)) return "PDF";
    if (/curso|aula|treinamento|formacao|turma/.test(texto)) return "Curso";
    if (/app|aplicativo|software|sistema/.test(texto)) return "App";
    if (/instagram|reels|perfil|seguidores|direct/.test(texto)) return "Instagram";
    return "todos";
  }

  function statusAnuncio(anuncio = {}) {
    if (anuncio.ativo === false) return "Inativo";
    const status = String(anuncio.adActiveStatus || "").toUpperCase();
    if (status === "INACTIVE") return "Inativo";
    if (status !== "ACTIVE") return "Inativo";
    if (anuncio.dataFimISO && new Date(anuncio.dataFimISO).getTime() < Date.now()) return "Inativo";
    return "Ativo";
  }

  function textoEhMetadadoOferta(texto = "") {
    const t = String(texto || "");
    if (t.length > 200) return false;
    return /^(come[cç]ou\s+a\s+ser\s+publicado|identifica[cç][aã]o\s+da\s+biblioteca|library\s+id|ad\s+id|plataformas?\s*:|ver\s+detalhes|abrir\s+menu|pendente|veiculad[ao]|veicula[cç][aã]o|meta\s*[©\u00a9]\s*\d{4}|portugu[êe]s\s*\(brasil\)|[e]?ste\s+an[uú]ncio\s+tem|esse\s+an[uú]ncio)/i.test(t.trim());
  }

  function tituloCard(anuncio = {}) {
    const candidatos = [anuncio.anunciante, anuncio.pageName, anuncio.tituloOferta].filter(Boolean);
    for (const item of candidatos) {
      if (item && !/^Anunciante\s+n[ãa]o\s+identificado$/i.test(item) && item !== "Oferta sem titulo" && !textoEhMetadadoOferta(item) && filtrarTextoUtil(item)) {
        return item;
      }
    }
    return "Oferta";
  }

  function descricaoCard(anuncio = {}) {
    const candidatos = [anuncio.texto, anuncio.textoCompleto].filter(Boolean);
    const texto = candidatos.find((item) => !textoEhMetadadoOferta(item) && filtrarTextoUtil(item)) || candidatos[0] || "";
    return filtrarTextoUtil(texto) || texto.slice(0, 200);
  }

  function temVideo(anuncio) {
    return (anuncio.midias || []).some(function(m){ return m.tipo === "video"; });
  }

  function primeiraMidia(anuncio) {
    return anuncio.midias?.[0] || null;
  }

  function criarCard(anuncio) {
    const card = document.createElement("article");
    const badge = badgeScore(anuncio);
    card.className = "card-anuncio" + (temVideo(anuncio) ? " card-com-video" : "");
    card.setAttribute("role", "listitem");

    const midia0 = primeiraMidia(anuncio);
    const thumb = midia0
      ? (midia0.tipo === "video"
        ? `<div class="thumb thumb-video" style="background:#000;display:flex;align-items:center;justify-content:center;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="%23a855f7" viewBox="0 0 256 256"><path d="M160,128a8,8,0,0,1-4,7L108,162a8,8,0,0,1-12-7V101a8,8,0,0,1,12-7l48,27A8,8,0,0,1,160,128Z" fill="%23a855f7"/><path d="M128,24A104,104,0,1,0,232,128,104,104,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88,88,0,0,1,128,216Z" fill="%23a855f7"/></svg></div>`
        : `<img class="thumb" loading="lazy" src="${midia0.url}" alt="Midia do anuncio">`)
      : `<div class="thumb"></div>`;
    const score = Math.max(0, Math.min(100, Number(anuncio.scoreEscala || 0)));

    const nomeAnunciante = tituloCard(anuncio);
    const descricao = descricaoCard(anuncio).slice(0, 140);
    const copias = obterCopiasAnuncio(anuncio);

    card.innerHTML = thumb;
    var conteudo = document.createElement("div");
    conteudo.className = "card-conteudo";

    var h3 = document.createElement("h3");
    h3.title = nomeAnunciante;
    h3.textContent = nomeAnunciante;
    conteudo.appendChild(h3);

    var p = document.createElement("p");
    p.className = "card-texto";
    p.textContent = descricao || "Sem descrição capturada.";
    conteudo.appendChild(p);

    var badges = document.createElement("div");
    badges.className = "linha-badges";

    var b1 = document.createElement("span");
    b1.className = "badge " + badge.classe;
    b1.textContent = badge.texto;
    badges.appendChild(b1);

    var b2 = document.createElement("span");
    b2.className = "badge " + (statusAnuncio(anuncio) === "Ativo" ? "ativo" : "inativo");
    b2.textContent = statusAnuncio(anuncio);
    badges.appendChild(b2);

    var b3 = document.createElement("span");
    b3.className = "badge info";
    b3.textContent = anuncio.entregavel || "Indefinido";
    badges.appendChild(b3);

    var bCopias = document.createElement("span");
    bCopias.className = "badge info";
    bCopias.textContent = "Cópias: " + copias;
    badges.appendChild(bCopias);

    var linkZapCard = linkWhatsAppDoAnuncio(anuncio);
    if (linkZapCard) {
      var bZap = document.createElement("span");
      bZap.className = "badge zap";
      bZap.textContent = "WhatsApp";
      bZap.title = linkZapCard;
      badges.appendChild(bZap);
    } else if (anuncio.urlDestino && /^https?:\/\//i.test(anuncio.urlDestino)) {
      var bPagina = document.createElement("span");
      bPagina.className = "badge info";
      bPagina.textContent = "Pg. Vendas";
      badges.appendChild(bPagina);
    }

    conteudo.appendChild(badges);

    var linhaCard = document.createElement("div");
    linhaCard.className = "linha-card";

    var scoreWrap = document.createElement("div");
    scoreWrap.className = "score-wrap";
    scoreWrap.style.setProperty("--score", (score * 3.6) + "deg");
    scoreWrap.textContent = String(score);
    linhaCard.appendChild(scoreWrap);

    var acoes = document.createElement("div");
    acoes.className = "card-acoes";

    var midiaVideo = (anuncio.midias || []).find(function(m){ return m.tipo === "video"; });
    if (midiaVideo) {
      var btnDL = document.createElement("button");
      btnDL.className = "btn acento btn-dl-video";
      btnDL.textContent = "Baixar";
      btnDL.title = "Download do video do criativo";
      btnDL.addEventListener("click", function(e){
        e.stopPropagation();
        baixarVideoDeMidia(midiaVideo.url, anuncio.idAnuncio);
      });
      acoes.appendChild(btnDL);
    }

    var btn = document.createElement("button");
    btn.className = "btn secundario btn-detalhes";
    btn.textContent = "Detalhes";
    acoes.appendChild(btn);
    linhaCard.appendChild(acoes);

    conteudo.appendChild(linhaCard);
    card.appendChild(conteudo);

    card.querySelector(".btn-detalhes").addEventListener("click", () => abrirModal(anuncio));
    return card;
  }

  function renderizarLista(reset = false) {
    const lista = el.listaResultados;
    const itens = estado.filtrados || [];
    const total = itens.length;

    if (reset || !lista.__metaspyVirtual) {
      lista.__metaspyVirtual = true;
      lista.classList.add("virtual");
      lista.innerHTML = "";
      if (!lista.__metaspyOnScroll) {
        lista.__metaspyOnScroll = true;
        lista.addEventListener("scroll", () => renderizarLista(false));
      }
    }

    if (total === 0) {
      lista.style.height = "";
      lista.innerHTML = '<div class="estado-vazio">Nenhum resultado para exibir. Rode uma busca para começar.</div>';
      el.btnCarregarMais.classList.add("oculto");
      return;
    }

    /* P4: virtualizacao — renderiza apenas as linhas proximas ao viewport. */
    const ALTURA_CARD = 156;
    lista.style.height = (total * ALTURA_CARD) + "px";
    const scrollTop = lista.scrollTop || 0;
    const visaoAltura = lista.clientHeight || 460;
    const inicio = Math.max(0, Math.floor(scrollTop / ALTURA_CARD) - 3);
    const fim = Math.min(total, Math.ceil((scrollTop + visaoAltura) / ALTURA_CARD) + 3);

    while (lista.firstChild) lista.firstChild.remove();
    const frag = document.createDocumentFragment();
    for (let i = inicio; i < fim; i++) {
      const card = criarCard(itens[i]);
      card.style.position = "absolute";
      card.style.top = (i * ALTURA_CARD) + "px";
      card.style.height = ALTURA_CARD + "px";
      frag.appendChild(card);
    }
    lista.appendChild(frag);
    el.btnCarregarMais.classList.add("oculto");
  }

  function atualizarIndicadores() {
    el.contadorResultados.textContent = `${estado.filtrados.length} resultado(s)`;
    el.contadorEscalados.textContent = `Ofertas: ${estado.filtrados.length}`;
  }

  function getSegmentoAtivo() {
    if (!el.filtroNutra || !el.filtroInfo) return "";
    if (el.filtroNutra.classList.contains("ativo")) return "nutra";
    if (el.filtroInfo.classList.contains("ativo")) return "info";
    return "";
  }

  function calcularMapaCopias() {
    return window.MetaSpyUtils.mapearCopiasPorAnuncio(Array.isArray(estado.anuncios) ? estado.anuncios : []);
  }

  function obterCopiasAnuncio(anuncio = {}) {
    return window.MetaSpyUtils.contarCopiasAnuncio(anuncio, estado.mapaCopias);
  }

  function aplicarFiltros() {
    estado.mapaCopias = calcularMapaCopias();
    const ordenacao = el.filtroOrdenacao.value;
    const plataforma = el.filtroPlataforma.value;
    const midia = el.filtroMidia.value;
    const copiasMin = Number(el.filtroCopiasMin.value || 0);
    const diasMin = Number(el.filtroDiasMin.value || 0);
    const statusApi = el.filtroStatusApi.value;
    const destino = el.filtroDestino.value;
    const entregavel = el.filtroEntregavel.value;
    const segmento = getSegmentoAtivo();
    const palavrasNegativas = el.inputNegativas ? String(el.inputNegativas.value || "").trim() : "";

    let lista = [...estado.anuncios];
    if (plataforma !== "ambos") {
      lista = lista.filter((a) => (a.plataformas || []).map((p) => normalizarTexto(p)).includes(plataforma));
    }
    if (midia !== "todos") {
      lista = lista.filter((a) => (a.midias || []).map((m) => normalizarTexto(m.tipo || "")).includes(midia));
    }
    if (copiasMin > 0) {
      lista = lista.filter((a) => obterCopiasAnuncio(a) >= copiasMin);
    }
    if (diasMin > 0) {
      lista = lista.filter((a) => {
        const diasAtivo = Number(a.diasAtivo || 0);
        if (diasAtivo === 0) return true;
        return diasAtivo >= diasMin;
      });
    }
    if (statusApi === "ACTIVE") {
      lista = lista.filter((a) => ehRealmenteAtivo(a));
    } else if (statusApi === "INACTIVE") {
      lista = lista.filter((a) => !ehRealmenteAtivo(a));
    }
    if (destino !== "todos") {
      lista = lista.filter((a) => normalizarTexto(a.destino || "") === normalizarTexto(destino));
    }
    if (entregavel !== "todos") {
      lista = lista.filter((a) => normalizarTexto(a.entregavel || "") === normalizarTexto(entregavel));
    }
    if (segmento === "nutra") {
      lista = lista.filter((a) => normalizarTexto(a.entregavel || "") === "nutra");
    } else if (segmento === "info") {
      lista = lista.filter((a) => ["curso", "pdf", "mentoria", "tutorial", "consultoria"].includes(normalizarTexto(a.entregavel || "")));
    }
    if (palavrasNegativas) {
      var palavras = palavrasNegativas.split(/\s+/).filter(Boolean).map(function (p) { return normalizarTexto(p); });
      if (palavras.length) {
        lista = lista.filter(function (a) {
          var texto = normalizarTexto((a.textoCompleto || "") + " " + (a.anunciante || "") + " " + (a.urlDestino || ""));
          return !palavras.some(function (p) { return texto.indexOf(p) >= 0; });
        });
      }
    }

    if (ordenacao === "maior_escala") {
      lista.sort((a, b) => Number(b.scoreEscala || 0) - Number(a.scoreEscala || 0));
    } else if (ordenacao === "maior_tempo") {
      lista.sort((a, b) => Number(b.diasAtivo || 0) - Number(a.diasAtivo || 0));
    } else {
      lista.sort((a, b) => new Date(b.dataInicioISO || 0) - new Date(a.dataInicioISO || 0));
    }

    atualizarResumoFiltros();

    estado.filtrados = lista;
    atualizarIndicadores();
    renderizarLista(true);
  }

  const aplicarFiltrosDebounced = debounce(aplicarFiltros, 500);

  async function carregarToken() {
    const resposta = await send({ acao: "obterTokenApi" });
    if (resposta?.ok && el.tokenApi) el.tokenApi.value = resposta.token || "";
  }

  async function carregarConfiguracoesBusca() {
    const resposta = await send({ acao: "obterConfiguracoesBusca" });
    if (!resposta?.ok) return;
    el.filtroPais.value = resposta.pais || "BR";
    el.filtroStatusApi.value = resposta.statusFiltro || "ACTIVE";
    el.filtroDiasMin.value = "0";
    if (el.filtroCopiasMin) el.filtroCopiasMin.value = String(Math.max(0, Number(resposta.copiasMinFiltro || 0)));
    function setSegmentoAtivo(val) {
      [el.filtroTodos, el.filtroNutra, el.filtroInfo].forEach(function (b) {
        if (b) b.classList.toggle("ativo", b.dataset.segment === (val || ""));
      });
    }
    setSegmentoAtivo(resposta.segmentoAtivo || "");
    if (el.inputNegativas) el.inputNegativas.value = resposta.palavrasNegativas || "";
  }

  async function salvarConfiguracoesBusca() {
    const resposta = await send({
      acao: "salvarConfiguracoesBusca",
      paisFiltro: el.filtroPais.value,
      statusFiltro: el.filtroStatusApi.value,
      diasMinFiltro: Number(el.filtroDiasMin.value || 0),
      copiasMinFiltro: Number(el.filtroCopiasMin.value || 0),
      modoBibliotecaAberta: true,
      sincronizarBibliotecaBusca: true,
      segmentoAtivo: getSegmentoAtivo(),
      palavrasNegativas: el.inputNegativas ? el.inputNegativas.value : ""
    });
    if (!resposta?.ok) throw new Error(resposta?.erro || "Falha ao salvar filtros da busca.");
  }

  async function salvarToken() {
    if (!el.tokenApi) return;
    const token = String(el.tokenApi.value || "").trim();
    if (!token) {
      setAlerta("Informe um token valido.", true);
      return;
    }
    const resposta = await send({ acao: "salvarTokenApi", token });
    if (resposta?.ok) setAlerta("Token salvo com sucesso.", true);
    else setAlerta(resposta?.erro || "Falha ao salvar token.", true);
  }

  async function testarApi() {
    try {
      await salvarToken();
      setLoading(true, "Testando API da Biblioteca...");
      const resposta = await send({ acao: "testarApi" });
      if (!resposta?.ok) throw new Error(resposta?.erro || "API nao respondeu.");
      setAlerta(`API respondeu: ${resposta.total || 0} anuncio(s) no teste.`, true);
    } catch (erro) {
      setAlerta(`API falhou: ${erro.message}`, true);
    } finally {
      setLoading(false);
    }
  }

  async function diagnosticarBiblioteca() {
    try {
      setLoading(true, "Diagnosticando Biblioteca...");
      const resposta = await send({ acao: "diagnosticarBiblioteca" });
      if (!resposta?.ok) throw new Error(resposta?.erro || "Diagnostico falhou.");
      setAlerta(
        `Biblioteca OK: ${resposta.cardsDetectados || 0} card(s), ${resposta.anunciosDetectados || 0} anuncio(s), texto ${resposta.bodyTextLength || 0}.`,
        true
      );
    } catch (erro) {
      setAlerta(`Diagnostico falhou: ${erro.message}`, true);
    } finally {
      setLoading(false);
    }
  }

  function restaurarFiltroAvancado() {
    el.filtroOrdenacao.value = "maior_tempo";
    el.filtroPlataforma.value = "ambos";
    el.filtroStatusApi.value = "ACTIVE";
    el.filtroMidia.value = "todos";
    el.filtroCopiasMin.value = "0";
    el.filtroDiasMin.value = "0";
    el.filtroDestino.value = "todos";
    el.filtroEntregavel.value = "todos";
    function setSegmentoAtivo(val) {
      [el.filtroTodos, el.filtroNutra, el.filtroInfo].forEach(function (b) {
        if (b) b.classList.toggle("ativo", b.dataset.segment === (val || ""));
      });
    }
    setSegmentoAtivo("");
    if (el.inputNegativas) el.inputNegativas.value = "";
    salvarConfiguracoesBusca()
      .then(() => {
        aplicarFiltros();
        setAlerta("Filtro avancado restaurado: anuncios ativos com 100+ dias rodando.", true);
      })
      .catch((erro) => setAlerta(erro.message, true));
  }

  async function iniciarBuscaRapida() {
    setLoading(true, "Executando busca rapida...");
    try {
      await salvarConfiguracoesBusca();
      const termo = String(el.inputNicho.value || "").trim();
      const resposta = await send({ acao: "iniciarBuscaRapida", termo });
      if (!resposta?.ok) throw new Error(resposta?.erro || "Falha na busca rapida.");
      estado.anuncios = resposta.anuncios || [];
      aplicarFiltros();
      atualizarProgresso(100, `Busca rapida concluida: ${estado.anuncios.length} anuncios.`);
      setAlerta(`Ofertas encontradas: ${estado.anuncios.length}`, true);
    } catch (erro) {
      setAlerta(`Erro: ${erro.message}`, true);
    } finally {
      setLoading(false);
    }
  }

  async function iniciarVarreduraCompleta() {
    setLoading(true, "Varredura completa em andamento...");
    estado.emVarredura = true;
    try {
      await salvarConfiguracoesBusca();
      const termo = String(el.inputNicho.value || "").trim();
      const tempoMaximoMin = el.tempoVarreduraProfundoMin ? Number(el.tempoVarreduraProfundoMin.value) || 0 : 0;
      const resposta = await send({ acao: "iniciarVarreduraCompleta", termo, tempoMaximoMin });
      if (!resposta?.ok) throw new Error(resposta?.erro || "Falha ao iniciar varredura.");
      setAlerta("Varredura iniciada. Acompanhe a contagem em tempo real.", true);
    } catch (erro) {
      estado.emVarredura = false;
      setLoading(false);
      setAlerta(`Erro: ${erro.message}`, true);
    }
  }

  async function buscarPorNicho() {
    const termo = String(el.inputNicho.value || "").trim();
    if (!termo) {
      setAlerta("Informe um termo para busca por nicho.", true);
      return;
    }
    setLoading(true, `Buscando nicho "${termo}"...`);
    try {
      await salvarConfiguracoesBusca();
      const resposta = await send({ acao: "buscarPorNicho", termo });
      if (!resposta?.ok) throw new Error(resposta?.erro || "Falha na busca por nicho.");
      estado.anuncios = resposta.anuncios || [];
      aplicarFiltros();
      atualizarProgresso(100, `Nicho concluido: ${estado.anuncios.length} oferta(s) encontrada(s).`);
      setAlerta(
        `Ofertas encontradas: ${estado.anuncios.length} | Competitividade do nicho: ${resposta.competitividade || 0}/100`,
        true
      );
    } catch (erro) {
      setAlerta(`Erro: ${erro.message}`, true);
    } finally {
      setLoading(false);
    }
  }

  async function pararBusca() {
    try {
      await send({ acao: "pararBusca" });
      estado.emVarredura = false;
      setLoading(false);
      setAlerta("Busca interrompida e overlays removidos.", true);
    } catch (erro) {
      setAlerta(`Erro ao parar busca: ${erro.message}`, true);
    }
  }

  async function carregarStatusVarredura() {
    try {
      const status = await send({ acao: "obterStatusBusca" });
      if (!status?.ok) return;
      el.contadorEscalados.textContent = `Ofertas: ${status.totalEscalados || 0}`;
      if (status.ativa || status.statusVarredura === "em_andamento") {
        estado.emVarredura = true;
        setLoading(true, `Varredura em andamento: ${status.totalEscalados || 0} ofertas`);
      }
    } catch (erro) {
      console.debug("MetaSpy: falha ao carregar status da varredura:", erro);
    }
  }

  async function carregarResultadosAtuais() {
    try {
      const resposta = await send({ acao: "obterResultadosAtuais" });
      if (resposta?.ok && Array.isArray(resposta.anuncios)) {
        estado.anuncios = resposta.anuncios;
        aplicarFiltros();
      }
    } catch (erro) {
      console.debug("MetaSpy: falha ao carregar resultados atuais:", erro);
    }
  }

  async function garantirBibliotecaAberta() {
    try {
      await send({ acao: "garantirBibliotecaAberta", termo: String(el.inputNicho.value || "").trim() });
    } catch (erro) {
      console.debug("MetaSpy: falha ao garantir Biblioteca aberta:", erro);
    }
  }

  function linkWhatsAppDoAnuncio(anuncio) {
    if (!anuncio) return "";
    var url = String(anuncio.urlDestino || "");
    if (!/^https?:\/\//i.test(url)) return "";
    var normalizado = normalizarTexto(url);
    if (normalizado.indexOf("whatsapp:") === 0) return url;
    if (/(?:^|[@./])(?:api\.|web\.|chat\.|next\.|business\.)?whatsapp\.com/.test(normalizado) ||
        /(?:^|[@./])wa\.me(?:$|[/?#])/.test(normalizado)) return url;
    return "";
  }

  function abrirWhatsApp() {
    const anuncio = estado.anuncioSelecionado;
    const url = linkWhatsAppDoAnuncio(anuncio);
    if (!url) return;
    chrome.tabs.create({ url }).catch(function (erro) {
      console.error("[MetaSpy] Falha ao abrir WhatsApp:", erro);
    });
  }

  async function abrirModal(anuncio) {
    estado.anuncioSelecionado = anuncio;
    el.modalTitulo.textContent = tituloCard(anuncio);
    el.modalTexto.textContent = descricaoCard(anuncio) || "Sem texto disponivel.";

    var primeiraMidia = anuncio.midias?.[0];
    if (primeiraMidia) {
      if (primeiraMidia.tipo === "video") {
        el.modalMidia.innerHTML =
          '<div class="modal-video-wrap">' +
          '<video class="modal-video" controls src="' + sanitizarHtml(primeiraMidia.url) + '"></video>' +
          '<button id="btnDownloadVideoModal" class="btn acento btn-dl-modal"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 256 256" style="vertical-align:middle;margin-right:4px;"><path d="M224,152v56a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V152a8,8,0,0,1,16,0v48H208V152a8,8,0,0,1,16,0Zm-101.66,5.66a8,8,0,0,0,11.32,0l40-40a8,8,0,0,0-11.32-11.32L136,132.69V40a8,8,0,0,0-16,0v92.69L93.66,106.34a8,8,0,0,0-11.32,11.32Z"/></svg>Baixar Video</button>' +
          '</div>';
        var btnDLModal = document.getElementById("btnDownloadVideoModal");
        if (btnDLModal) {
          btnDLModal.addEventListener("click", function(){
            baixarVideoDeMidia(primeiraMidia.url, anuncio.idAnuncio);
          });
        }
      } else {
        el.modalMidia.innerHTML = '<div class="modal-img-wrap"><img src="' + sanitizarHtml(primeiraMidia.url) + '" alt="Midia do anuncio"></div>';
      }
    } else {
      el.modalMidia.innerHTML = "";
    }
    const textoAnalise = `${anuncio.textoCompleto || anuncio.texto || ""} ${anuncio.entregavel || ""} ${anuncio.destino || ""}`;
    const estruturas = detectarEstruturas(textoAnalise);
    function adicionarLinhaInfo(container, rotulo, valor, htmlValor) {
      var txt = document.createTextNode(rotulo + ": " + valor);
      container.appendChild(txt);
      if (htmlValor) container.appendChild(htmlValor);
      container.appendChild(document.createElement("br"));
    }

    el.modalInfos.innerHTML = "";
    adicionarLinhaInfo(el.modalInfos, "ID", sanitizarHtml(anuncio.idAnuncio || "-"));
    adicionarLinhaInfo(el.modalInfos, "Início", sanitizarHtml(formatarDataBr(anuncio.dataInicioISO)));
    adicionarLinhaInfo(el.modalInfos, "Tempo ativo", (anuncio.diasAtivo || 0) + " dia(s)");
    adicionarLinhaInfo(el.modalInfos, "Cópias detectadas", String(obterCopiasAnuncio(anuncio)));
    adicionarLinhaInfo(el.modalInfos, "Plataformas", sanitizarHtml((anuncio.plataformas || []).join(", ") || "-"));
    adicionarLinhaInfo(el.modalInfos, "Status", sanitizarHtml(statusAnuncio(anuncio)));
    adicionarLinhaInfo(el.modalInfos, "Entregável", sanitizarHtml(anuncio.entregavel || "Indefinido"));
    adicionarLinhaInfo(el.modalInfos, "Destino", sanitizarHtml(anuncio.destino || "-"));
    var linkOferta = String(anuncio.urlDestino || "");
    var temLinkOferta = /^https?:\/\//i.test(linkOferta);
    var linkZap = linkWhatsAppDoAnuncio(anuncio);
    adicionarLinhaInfo(el.modalInfos, "Página de vendas", temLinkOferta ? "Disponível" : "Não detectada");
    if (linkZap) adicionarLinhaInfo(el.modalInfos, "WhatsApp", sanitizarHtml(linkZap));
    else if (temLinkOferta) adicionarLinhaInfo(el.modalInfos, "Link da oferta", sanitizarHtml(linkOferta));
    adicionarLinhaInfo(el.modalInfos, "Score de escala", String(anuncio.scoreEscala || 0));

    var estruturaSpan = document.createElement("span");
    estruturaSpan.className = "badge escalando";
    estruturaSpan.style.marginLeft = "4px";
    estruturaSpan.textContent = estruturas.join(", ");
    var txtEstrutura = document.createTextNode("Estrutura detectada: ");
    var brEstrutura = document.createElement("br");
    el.modalInfos.appendChild(txtEstrutura);
    el.modalInfos.appendChild(estruturaSpan);
    el.modalInfos.appendChild(document.createElement("br"));
    if (linkZap) {
      el.btnAbrirWhatsApp.classList.remove("oculto");
    } else {
      el.btnAbrirWhatsApp.classList.add("oculto");
    }
    if (temLinkOferta) {
      el.btnPaginaVendas.classList.remove("oculto");
    } else {
      el.btnPaginaVendas.classList.add("oculto");
    }
    el.modalDetalhes.showModal();
  }

  function fecharModal() {
    el.btnPaginaVendas.classList.add("oculto");
    if (el.btnAbrirWhatsApp) el.btnAbrirWhatsApp.classList.add("oculto");
    el.modalDetalhes.close();
  }

  async function abrirNoMeta() {
    const anuncio = estado.anuncioSelecionado;
    if (!anuncio) return;
    const nome = tituloCard(anuncio);
    if (!nome || nome === "Oferta") return;
    const url = `https://www.facebook.com/ads/library/?active_status=all&ad_type=all&country=ALL&q=${encodeURIComponent(nome)}`;
    await chrome.tabs.create({ url });
  }

  async function abrirPaginaVendas() {
    const anuncio = estado.anuncioSelecionado;
    if (!anuncio?.urlDestino) return;
    await chrome.tabs.create({ url: anuncio.urlDestino });
  }

  async function salvarFavorito() {
    const anuncio = estado.anuncioSelecionado;
    if (!anuncio) return;
    const resposta = await send({ acao: "salvarFavorito", anuncio });
    if (resposta?.ok) { setAlerta("anuncio salvo nos favoritos.", true); mostrarToast("Adicionado aos favoritos.", "sucesso"); }
    else { setAlerta(resposta?.erro || "Erro ao salvar favorito.", true); mostrarToast(resposta?.erro || "Erro ao salvar favorito.", "erro"); }
  }

  async function mostrarFavoritos() {
    if (estado.mostrandoFavoritos) return;
    const resposta = await send({ acao: "obterFavoritos" });
    if (!resposta?.ok) {
      setAlerta(resposta?.erro || "Falha ao carregar favoritos.", true);
      return;
    }
    estado.anteriorResultados = estado.anuncios;
    estado.anuncios = resposta.favoritos || [];
    estado.mostrandoFavoritos = true;
    el.btnVoltar.classList.remove("oculto");
    aplicarFiltros();
    setAlerta("Favoritos carregados.", true);
  }

  function voltarResultados() {
    if (!estado.anteriorResultados) return;
    estado.anuncios = estado.anteriorResultados;
    estado.anteriorResultados = null;
    estado.mostrandoFavoritos = false;
    el.btnVoltar.classList.add("oculto");
    aplicarFiltros();
  }

  function setStatusDownloadVideo(msg, tipo = "") {
    const el = document.getElementById("statusDownloadVideo");
    if (!el) return;
    if (!msg) { el.classList.add("oculto"); el.textContent = ""; return; }
    el.textContent = msg;
    el.className = "ferramenta-status" + (tipo ? " " + tipo : "");
    el.classList.remove("oculto");
  }

  function ehUrlDeVideoDireto(url) {
    if (!url || typeof url !== "string") return false;
    if (/\.mp4(\?|#|$)/i.test(url)) return true;
    try {
      const u = new URL(url);
      return /(fbcdn\.net|fbsbx\.com|video\.facebook\.com|cdninstagram\.com|video\.instagram\.com)$/.test(u.hostname);
    } catch { return false; }
  }

  async function extrairVideoDeAbaAberta(urlAlvo) {
    const padroes = ["*://*.facebook.com/*", "*://facebook.com/*", "*://*.instagram.com/*", "*://instagram.com/*"];
    const abas = await chrome.tabs.query({ url: padroes });
    for (const aba of abas) {
      if (!aba?.id) continue;
      try {
        const resp = await chrome.tabs.sendMessage(aba.id, { acao: "extrairEBaixarVideo", url: urlAlvo });
        if (resp?.ok && resp.videoUrl) return resp.videoUrl;
      } catch {}
    }
    return null;
  }

  async function baixarVideoUrl(url, filenameSugerido = "") {
    if (!url || !url.startsWith("http")) {
      setStatusDownloadVideo("URL invalida. Cole uma URL valida.", "erro");
      return;
    }

    const adId = url.match(/[?&]id=(\d+)/)?.[1] || "";
    const filename = filenameSugerido || `metaspy_criativo_${adId || Date.now()}.mp4`;

    setStatusDownloadVideo("Iniciando download...", "");

    try {
      let videoUrl = url;

      // URL de midia direta (video do CDN): vai direto ao download manager.
      if (!ehUrlDeVideoDireto(url)) {
        // Pagina/URL do Facebook: tenta extrair o video real de uma aba aberta.
        if (/facebook\.com\/ads\/library/i.test(url)) {
          await baixarCriativoDaBiblioteca(url);
          return;
        }
        const extraido = await extrairVideoDeAbaAberta(url);
        if (extraido) {
          videoUrl = extraido;
        } else {
          setStatusDownloadVideo("Nao foi possivel extrair o video. Abra o anuncio no Facebook e tente novamente.", "erro");
          return;
        }
      }

      const resposta = await send({ acao: "downloadVideo", url: videoUrl, filename });
      if (resposta?.ok) {
        setStatusDownloadVideo("Download iniciado! Escolha onde salvar.", "sucesso");
        adicionarAoHistorico({ url: videoUrl, filename, adId: adId || url.slice(0, 60) });
      } else {
        setStatusDownloadVideo("Erro: " + (resposta?.erro || "Falha ao baixar o video."), "erro");
      }
    } catch (erro) {
      setStatusDownloadVideo("Erro: " + erro.message, "erro");
    }
  }

  async function baixarVideoDeMidia(videoUrl, adId) {
    if (!videoUrl) return;
    var filename = "metaspy_criativo_" + (adId || Date.now()) + ".mp4";
    await baixarVideoUrl(videoUrl, filename);
  }

  async function baixarCriativoDoInput() {
    var input = document.getElementById("inputUrlVideo");
    if (!input) return;
    var url = String(input.value || "").trim();
    if (!url) {
      setStatusDownloadVideo("Cole a URL do anuncio ou do video.", "erro");
      return;
    }
    var isBiblioteca = /facebook\.com\/ads\/library/i.test(url);
    if (isBiblioteca) {
      await baixarCriativoDaBiblioteca(url);
    } else {
      await baixarVideoUrl(url);
    }
  }

  async function baixarCriativoDaBiblioteca(bibliotecaUrl) {
    setStatusDownloadVideo("Abrindo pagina do anuncio...", "");
    try {
      var abas = await chrome.tabs.query({ url: ["*://*.facebook.com/ads/library*", "*://facebook.com/ads/library*"] });
      var tab = abas.find(function(t){ return t.url === bibliotecaUrl; });
      if (!tab) {
        tab = await chrome.tabs.create({ url: bibliotecaUrl, active: false });
      } else {
        await chrome.tabs.update(tab.id, { url: bibliotecaUrl });
      }
      await esperar(3000);
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["utils.js", "content-script.js"]
        });
      } catch {}
      setStatusDownloadVideo("Aguardando video carregar...", "");
      var videoUrl = null;
      for (var i = 0; i < 20; i++) {
        try {
          var resp = await chrome.tabs.sendMessage(tab.id, { acao: "aguardarVideoPagina", timeout: 5000 });
          if (resp?.ok && resp.videoUrl) {
            videoUrl = resp.videoUrl;
            break;
          }
        } catch {}
        await esperar(1000);
      }
      if (videoUrl) {
        setStatusDownloadVideo("Video encontrado! Iniciando download...", "");
        var filename = "metaspy_criativo_" + Date.now() + ".mp4";
        var resposta = await send({ acao: "downloadVideo", url: videoUrl, filename });
        if (resposta?.ok) {
          setStatusDownloadVideo("Download iniciado! Escolha onde salvar.", "sucesso");
          adicionarAoHistorico({ url: videoUrl, filename, adId: "biblioteca" });
        } else {
          setStatusDownloadVideo("Erro ao baixar: " + (resposta?.erro || "desconhecido"), "erro");
        }
      } else {
        setStatusDownloadVideo("Nao foi possivel encontrar video na pagina. Abra o anuncio manualmente e clique em \"Baixar video\" no player.", "erro");
      }
    } catch (erro) {
      setStatusDownloadVideo("Erro: " + erro.message, "erro");
    }
  }

  function fecharAnalise() {
    if (el.modalAnalise) el.modalAnalise.close();
  }

  function construirAnalise(container) {
    var base = estado.filtrados.length ? estado.filtrados : estado.anuncios;
    if (!base.length) {
      container.innerHTML = '<p class="estado-vazio">Nenhum resultado para analisar. Rode uma busca primeiro.</p>';
      return false;
    }
    var total = base.length;
    var ativos = base.filter(function (a) { return a.ativo !== false; }).length;
    var altos = base.filter(function (a) { return Number(a.scoreEscala || 0) >= 80; }).length;
    var medios = base.filter(function (a) { var s = Number(a.scoreEscala || 0); return s >= 60 && s < 80; }).length;
    var baixos = base.filter(function (a) { return Number(a.scoreEscala || 0) < 60; }).length;
    var comWhatsApp = base.filter(function (a) { return normalizarTexto(a.destino || "").indexOf("whatsapp") >= 0; }).length;
    var multiPagina = base.filter(function (a) { return a.multiPagina; }).length;
    var nutraCount = base.filter(function (a) { return normalizarTexto(a.entregavel || "") === "nutra"; }).length;
    var infoCount = base.filter(function (a) { return ["curso", "pdf", "mentoria", "tutorial", "consultoria"].indexOf(normalizarTexto(a.entregavel || "")) >= 0; }).length;

    var scoreSum = base.reduce(function (acc, a) { return acc + Number(a.scoreEscala || 0); }, 0);
    var scoreMedia = total ? (scoreSum / total).toFixed(1) : "0";
    var diasSum = base.reduce(function (acc, a) { return acc + Number(a.diasAtivo || 0); }, 0);
    var diasMedia = total ? (diasSum / total).toFixed(0) : "0";

    var top10 = base.slice().sort(function (a, b) { return Number(b.scoreEscala || 0) - Number(a.scoreEscala || 0); }).slice(0, 10);

    function criarStat(rotulo, valor) {
      var div = document.createElement("div");
      div.className = "stat";
      var sr = document.createElement("span");
      sr.className = "rotulo";
      sr.textContent = rotulo;
      var sv = document.createElement("span");
      sv.className = "valor";
      sv.textContent = String(valor);
      div.appendChild(sr);
      div.appendChild(sv);
      return div;
    }

    function criarBloco(titulo) {
      var bloco = document.createElement("div");
      bloco.className = "analise-bloco";
      var h3 = document.createElement("h3");
      h3.textContent = titulo;
      bloco.appendChild(h3);
      return bloco;
    }

    container.innerHTML = "";

    var bloco1 = criarBloco("Estat\u00EDsticas Gerais");
    bloco1.appendChild(criarStat("Total de ofertas", total));
    bloco1.appendChild(criarStat("An\u00FAncios ativos", ativos));
    bloco1.appendChild(criarStat("Score m\u00E9dio", scoreMedia));
    bloco1.appendChild(criarStat("Dias ativo (m\u00E9dia)", diasMedia));
    container.appendChild(bloco1);

    var bloco2 = criarBloco("Distribui\u00E7\u00E3o de Score");
    bloco2.appendChild(criarStat("Alta escala (80+)", altos));
    bloco2.appendChild(criarStat("Escalando (60-79)", medios));
    bloco2.appendChild(criarStat("Testando (<60)", baixos));
    container.appendChild(bloco2);

    var bloco3 = criarBloco("Segmentos");
    bloco3.appendChild(criarStat("Nutra", nutraCount));
    bloco3.appendChild(criarStat("Info", infoCount));
    bloco3.appendChild(criarStat("WhatsApp como destino", comWhatsApp));
    if (multiPagina) bloco3.appendChild(criarStat("Multi-pagina", multiPagina));
    container.appendChild(bloco3);

    if (top10.length) {
      var bloco4 = criarBloco("Top 10 Melhores Scores");
      var lista = document.createElement("div");
      lista.className = "analise-lista-ofertas";
      for (var i = 0; i < top10.length; i++) {
        var a = top10[i];
        var sc = Number(a.scoreEscala || 0);
        var cls = sc >= 80 ? "alta" : sc >= 60 ? "escalando" : "testando";
        var item = document.createElement("div");
        item.className = "analise-oferta-item";
        var nome = document.createElement("span");
        nome.className = "nome";
        nome.title = a.anunciante || "";
        nome.textContent = a.anunciante || "?";
        var scoreEl = document.createElement("span");
        scoreEl.className = "score " + cls;
        scoreEl.textContent = String(sc);
        item.appendChild(nome);
        item.appendChild(scoreEl);
        lista.appendChild(item);
      }
      bloco4.appendChild(lista);
      container.appendChild(bloco4);
    }
    return true;
  }

  function abrirAnaliseAvancada() {
    if (!construirAnalise(el.analiseConteudo)) {
      mostrarToast("Nenhum resultado para analisar.", "erro");
      return;
    }
    el.analiseTitulo.textContent = "Análise Avançada";
    el.modalAnalise.showModal();
  }

  function limparResultados() {
    estado.anuncios = [];
    estado.filtrados = [];
    estado.pagina = 0;
    estado.anteriorResultados = null;
    estado.mostrandoFavoritos = false;
    el.btnVoltar.classList.add("oculto");
    el.listaResultados.innerHTML = "";
    el.btnCarregarMais.classList.add("oculto");
    el.contadorResultados.textContent = "0 resultados";
    el.contadorEscalados.textContent = "Ofertas: 0";
    send({ acao: "limparResultados" }).catch(() => {});
    setAlerta("Resultados limpos.", true);
  }

  async function exportarCsv() {
    const base = estado.filtrados.length ? estado.filtrados : estado.anuncios;
    if (!base.length) {
      setAlerta("nao ha resultados para exportar.", true);
      return;
    }
    const resposta = await send({ acao: "exportarCsv", anuncios: base });
    if (resposta?.ok) { setAlerta("Exportacao CSV iniciada.", true); mostrarToast("Exportacao CSV iniciada.", "sucesso"); }
    else { setAlerta(resposta?.erro || "Falha ao exportar CSV.", true); mostrarToast(resposta?.erro || "Falha ao exportar CSV.", "erro"); }
  }

  async function atualizarStatusConexao() {
    try {
      const abasAtivas = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      const abasBiblioteca = (await chrome.tabs.query({})).filter(t => t?.url && /facebook\.com\/ads\/library/i.test(t.url));
      const aba = abasAtivas[0];
      const naBiblioteca = Boolean(aba?.url && /facebook\.com\/ads\/library/i.test(aba.url)) || abasBiblioteca.length > 0;
      el.statusBadge.textContent = naBiblioteca ? "online" : "offline";
      el.statusBadge.className = naBiblioteca ? "status on" : "status off";

      for (const tab of abasBiblioteca) {
        try {
          await chrome.tabs.sendMessage(tab.id, { acao: "aplicarMoldura" });
        } catch {
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ["utils.js", "content-script.js"]
            });
          } catch {}
        }
      }
    } catch (erro) {
      el.statusBadge.textContent = "offline";
      el.statusBadge.className = "status off";
    }
  }

  function registrarEventos() {
    el.btnBuscaRapida.addEventListener("click", iniciarBuscaRapida);
    el.btnVarredura.addEventListener("click", iniciarVarreduraCompleta);
    el.btnNicho.addEventListener("click", () => {
      el.secaoNicho.classList.toggle("oculto");
      if (!el.secaoNicho.classList.contains("oculto")) el.inputNicho.focus();
    });
    el.btnAplicarNicho.addEventListener("click", buscarPorNicho);
    if (el.tempoVarreduraProfundoMin) {
      el.tempoVarreduraProfundoMin.addEventListener("change", () => {
        const v = Number(el.tempoVarreduraProfundoMin.value) || 10;
        chrome.storage.local.set({ tempoVarreduraProfundoMin: v }).catch(() => {});
      });
    }
    el.btnParar.addEventListener("click", pararBusca);

    [
      el.filtroOrdenacao,
      el.filtroPlataforma,
      el.filtroPais,
      el.filtroStatusApi,
      el.filtroMidia,
      el.filtroCopiasMin,
      el.filtroDiasMin,
      el.filtroDestino,
      el.filtroEntregavel
    ].forEach((campo) => {
      campo.addEventListener("change", aplicarFiltrosDebounced);
    });
    [el.filtroPais, el.filtroStatusApi, el.filtroDiasMin, el.filtroCopiasMin, el.filtroNutra, el.filtroInfo, el.filtroTodos, el.inputNegativas].forEach((campo) => {
      if (campo) campo.addEventListener("change", () => salvarConfiguracoesBusca().catch((erro) => setAlerta(erro.message, true)));
    });

    el.btnRestaurarFiltroAvancado.addEventListener("click", restaurarFiltroAvancado);
    [el.filtroNutra, el.filtroInfo, el.filtroTodos].forEach(function (b) {
      if (b) b.addEventListener("click", function () {
        [el.filtroNutra, el.filtroInfo, el.filtroTodos].forEach(function (x) { if (x) x.classList.remove("ativo"); });
        this.classList.add("ativo");
        salvarConfiguracoesBusca().catch(function (erro) { setAlerta(erro.message, true); });
        aplicarFiltrosDebounced();
      });
    });
    if (el.inputNegativas) el.inputNegativas.addEventListener("input", aplicarFiltrosDebounced);

    elFerramentas.btnPublicarNetlify.addEventListener("click", handlePublicarNetlify);

    if (elFerramentas.btnCapturarVideos) {
      elFerramentas.btnCapturarVideos.addEventListener("click", async function(){
        try {
          setStatusDownloadVideo("Capturando videos da pagina...", "");
          var abasFB = await chrome.tabs.query({ url: ["*://*.facebook.com/*", "*://facebook.com/*"] });
          if (!abasFB.length) {
            setStatusDownloadVideo("Nenhuma aba do Facebook aberta.", "erro");
            return;
          }
          var todosVideos = [];
          for (var aba of abasFB) {
            try {
              var resp = await chrome.tabs.sendMessage(aba.id, { acao: "extrairVideosPagina" });
              if (resp?.ok && resp.videos?.length) {
                todosVideos = todosVideos.concat(resp.videos);
              }
            } catch {}
          }
          if (!todosVideos.length) {
            setStatusDownloadVideo("Nenhum Video encontrado na(s) aba(s) do Facebook.", "erro");
            return;
          }
          var unicos = Array.from(new Set(todosVideos));
          var input = document.getElementById("inputUrlVideo");
          if (input && unicos.length === 1) {
            input.value = unicos[0];
            setStatusDownloadVideo("1 video capturado! Clique em Baixar ou Enter.", "sucesso");
          } else {
            localStorage.setItem("metaspy_videos_capturados", JSON.stringify(unicos));
            setStatusDownloadVideo(unicos.length + " video(s) capturado(s)! O primeiro foi colado no campo acima.", "sucesso");
            if (input) input.value = unicos[0];
          }
        } catch (erro) {
          setStatusDownloadVideo("Erro: " + erro.message, "erro");
        }
      });
    }

    var btnBaixarVideo = document.getElementById("btnBaixarVideo");
    var inputUrlVideo = document.getElementById("inputUrlVideo");
    if (btnBaixarVideo) btnBaixarVideo.addEventListener("click", baixarCriativoDoInput);
    if (inputUrlVideo) {
      inputUrlVideo.addEventListener("keydown", function(ev){
        if (ev.key === "Enter") baixarCriativoDoInput();
      });
    }
    renderizarHistoricoDownloads();

    el.btnCarregarMais.addEventListener("click", () => renderizarLista(false));
    el.btnExportar.addEventListener("click", exportarCsv);
    el.btnVoltar.addEventListener("click", voltarResultados);
    el.btnLimpar.addEventListener("click", limparResultados);

    el.fecharModal.addEventListener("click", fecharModal);
    el.modalDetalhes.addEventListener("click", (ev) => {
      if (ev.target === el.modalDetalhes) fecharModal();
    });
    el.btnAbrirMeta.addEventListener("click", abrirNoMeta);
    el.btnPaginaVendas.addEventListener("click", abrirPaginaVendas);
    if (el.btnAbrirWhatsApp) el.btnAbrirWhatsApp.addEventListener("click", abrirWhatsApp);
    el.btnSalvarFavorito.addEventListener("click", salvarFavorito);
    if (el.fecharAnalise) el.fecharAnalise.addEventListener("click", fecharAnalise);
    if (el.modalAnalise) el.modalAnalise.addEventListener("click", function (ev) {
      if (ev.target === el.modalAnalise) fecharAnalise();
    });
  }

  let _ultimaAtualizacaoResultados = 0;

  chrome.runtime.onMessage.addListener((mensagem) => {
    if (mensagem?.tipo === "progressoVarredura") {
      const totalEscalados = Number(mensagem.totalEscalados || 0);
      const totalProcessados = Number(mensagem.totalProcessados || 0);
      el.contadorEscalados.textContent = `Ofertas: ${totalEscalados}`;
      if (mensagem.status === "em_andamento") {
        setLoading(true, mensagem.mensagem || "Varredura em andamento...");
        const progresso = totalProcessados > 0 ? Math.min(95, Math.round((totalProcessados / 200) * 100)) : 20;
        atualizarProgresso(progresso, mensagem.mensagem || "");
        const agora = Date.now();
        if (agora - _ultimaAtualizacaoResultados > 3000) {
          _ultimaAtualizacaoResultados = agora;
          carregarResultadosAtuais().catch(() => {});
        }
      }
      if (mensagem.status === "concluido" || mensagem.status === "parado" || mensagem.status === "erro") {
        estado.emVarredura = false;
        setLoading(false);
        if (mensagem.mensagem) setAlerta(mensagem.mensagem, true);
        carregarResultadosAtuais().catch(() => {});
        navegarPara("resultados");
      }
      atualizarDashboardStatus();
    }
    if (mensagem?.tipo === "progressoDownloadLote") {
      desenharFilaDownloads(mensagem.itens || []);
    }
  });

  /* ─── U1: rotas do dashboard ────────────────────────── */

  function mostrarToast(mensagem, tipo = "info") {
    const container = document.getElementById("toastContainer");
    if (!container) return;
    const toast = document.createElement("div");
    toast.className = "toast " + tipo;
    toast.textContent = mensagem;
    container.appendChild(toast);
    setTimeout(() => toast.classList.add("saindo"), 2800);
    setTimeout(() => toast.remove(), 3200);
  }

  function navegarPara(rota) {
    const alvo = document.getElementById("rota-" + rota);
    if (!alvo) return;
    document.querySelectorAll(".rota").forEach((r) => r.classList.add("oculto"));
    alvo.classList.remove("oculto");
    document.querySelectorAll(".nav-dash-btn").forEach((b) => b.classList.toggle("ativo", b.dataset.rota === rota));
    if (rota === "resultados") carregarResultadosAtuais().catch(() => {});
    if (rota === "favoritos") carregarFavoritos().catch(() => {});
    if (rota === "biblioteca") renderizarBibliotecaPalavras().catch(() => {});
    if (rota === "analise") {
      const container = document.getElementById("analiseScreenConteudo");
      if (container) construirAnalise(container);
    }
    if (rota === "ferramentas") {
      renderizarFilaDownloads();
      renderizarPresets();
    }
    if (rota === "preferencias") {
      carregarPreferencias().catch(() => {});
      carregarToken().catch(() => {});
    }
  }

  function atualizarResumoFiltros() {
    const texto = document.getElementById("textoResumoFiltros");
    if (!texto) return;
    const partes = [];
    const pais = el.filtroPais.value;
    partes.push(pais === "ALL" ? "Todos os países" : pais);
    partes.push(el.filtroStatusApi.value === "ACTIVE" ? "Ativos" : el.filtroStatusApi.value === "INACTIVE" ? "Inativos" : "Ativos+Inativos");
    if (el.filtroMidia.value !== "todos") partes.push("Mídia: " + el.filtroMidia.value);
    const dias = Number(el.filtroDiasMin.value || 0);
    if (dias > 0) partes.push("Dias ≥ " + dias);
    const copias = Number(el.filtroCopiasMin.value || 0);
    if (copias > 0) partes.push("Cópias ≥ " + copias);
    const seg = getSegmentoAtivo();
    if (seg) partes.push("Segmento: " + seg);
    const neg = el.inputNegativas ? String(el.inputNegativas.value || "").trim() : "";
    if (neg) partes.push("Negativas: " + neg.split(/\s+/).length + " termo(s)");
    texto.textContent = partes.length ? partes.join(" · ") : "Nenhum filtro ativo.";
  }

  async function atualizarDashboardStatus() {
    const status = await send({ acao: "obterStatusBusca" });
    if (!status?.ok) return;
    const dS = document.getElementById("dashUltimaVarreduraS");
    const dT = document.getElementById("dashTotalEscalados");
    const dSt = document.getElementById("dashStatusVarredura");
    if (dS) dS.textContent = status.ultimaVarreduraS ? status.ultimaVarreduraS + "s" : "—";
    if (dT) dT.textContent = String(status.totalEscalados || 0);
    if (dSt) dSt.textContent = status.statusVarredura === "em_andamento" ? "em andamento" : status.statusVarredura === "concluido" ? "concluído" : "parado";
  }

  /* ─── F5: presets de filtros ────────────────────────── */

  async function renderizarPresets() {
    const resposta = await send({ acao: "obterPresetsFiltros" });
    const presets = resposta?.ok ? (resposta.lista || []) : [];
    const defaultId = resposta?.ok ? resposta.defaultId : null;
    popularSelectPreset(presets);
    const lista = document.getElementById("listaPresets");
    if (!lista) return;
    lista.innerHTML = "";
    if (!presets.length) {
      lista.innerHTML = '<div class="estado-vazio">Nenhum preset salvo.</div>';
      return;
    }
    presets.forEach((p) => {
      const item = document.createElement("div");
      item.className = "preset-item";
      const nome = document.createElement("span");
      nome.className = "preset-nome";
      nome.textContent = p.nome + (p.id === defaultId ? " (padrão)" : "");
      const acoes = document.createElement("span");
      acoes.className = "palavra-acoes";
      const bAplicar = document.createElement("button");
      bAplicar.textContent = "Aplicar";
      bAplicar.addEventListener("click", () => aplicarPresetFiltro(p.id));
      const bDef = document.createElement("button");
      bDef.textContent = "Padrão";
      bDef.addEventListener("click", () => salvarPresetDefault(p.id));
      const bRem = document.createElement("button");
      bRem.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
      bRem.title = "Remover preset";
      bRem.addEventListener("click", () => removerPreset(p.id));
      acoes.appendChild(bAplicar);
      acoes.appendChild(bDef);
      acoes.appendChild(bRem);
      item.appendChild(nome);
      item.appendChild(acoes);
      lista.appendChild(item);
    });
  }

  function popularSelectPreset(presets = []) {
    const sel = document.getElementById("selectPresetAplicar");
    if (!sel) return;
    sel.innerHTML = '<option value="">Aplicar preset...</option>' + presets.map((p) => `<option value="${sanitizarHtml(p.id)}">${sanitizarHtml(p.nome)}</option>`).join("");
  }

  function coletarFiltrosAtuais() {
    return {
      ordenacao: el.filtroOrdenacao.value,
      plataforma: el.filtroPlataforma.value,
      pais: el.filtroPais.value,
      status: el.filtroStatusApi.value,
      midia: el.filtroMidia.value,
      copiasMin: String(el.filtroCopiasMin.value || "0"),
      diasMin: String(el.filtroDiasMin.value || "0"),
      destino: el.filtroDestino.value,
      entregavel: el.filtroEntregavel.value,
      segmento: getSegmentoAtivo(),
      palavrasNegativas: el.inputNegativas ? String(el.inputNegativas.value || "") : ""
    };
  }

  function aplicarFiltrosDePreset(f = {}) {
    if (f.ordenacao !== undefined) el.filtroOrdenacao.value = f.ordenacao;
    if (f.plataforma !== undefined) el.filtroPlataforma.value = f.plataforma;
    if (f.pais !== undefined) el.filtroPais.value = f.pais;
    if (f.status !== undefined) el.filtroStatusApi.value = f.status;
    if (f.midia !== undefined) el.filtroMidia.value = f.midia;
    if (f.copiasMin !== undefined) el.filtroCopiasMin.value = f.copiasMin;
    if (f.diasMin !== undefined) el.filtroDiasMin.value = f.diasMin;
    if (f.destino !== undefined) el.filtroDestino.value = f.destino;
    if (f.entregavel !== undefined) el.filtroEntregavel.value = f.entregavel;
    if (f.palavrasNegativas !== undefined && el.inputNegativas) el.inputNegativas.value = f.palavrasNegativas;
    const seg = f.segmento || "";
    [el.filtroTodos, el.filtroNutra, el.filtroInfo].forEach((b) => {
      if (b) b.classList.toggle("ativo", b.dataset.segment === seg);
    });
    salvarConfiguracoesBusca().catch(() => {});
    aplicarFiltros();
  }

  async function aplicarPresetFiltro(id) {
    const resposta = await send({ acao: "aplicarPresetFiltro", id });
    if (!resposta?.ok) { mostrarToast(resposta?.erro || "Falha ao aplicar preset.", "erro"); return; }
    aplicarFiltrosDePreset(resposta.preset.filtros || {});
    const sel = document.getElementById("selectPresetAplicar");
    if (sel) sel.value = "";
    mostrarToast(`Preset "${resposta.preset.nome}" aplicado.`, "sucesso");
    navegarPara("resultados");
  }

  function obterNomePreset() {
    const input = document.getElementById("inputNomePreset");
    if (input && String(input.value || "").trim()) return String(input.value).trim();
    return window.prompt("Nome do preset:", "");
  }

  async function salvarPresetAtual(nome) {
    const nomeLimpo = String(nome || "").trim();
    if (!nomeLimpo) { mostrarToast("Informe um nome para o preset.", "erro"); return; }
    const resposta = await send({ acao: "salvarPresetFiltro", nome: nomeLimpo, filtros: coletarFiltrosAtuais(), tornarDefault: false });
    if (resposta?.ok) {
      mostrarToast("Preset salvo.", "sucesso");
      const input = document.getElementById("inputNomePreset");
      if (input) input.value = "";
      renderizarPresets();
    } else {
      mostrarToast(resposta?.erro || "Falha ao salvar preset.", "erro");
    }
  }

  async function removerPreset(id) {
    const resposta = await send({ acao: "removerPresetFiltro", id });
    if (resposta?.ok) { mostrarToast("Preset removido.", "sucesso"); renderizarPresets(); }
    else mostrarToast(resposta?.erro || "Falha ao remover preset.", "erro");
  }

  async function salvarPresetDefault(id) {
    const resposta = await send({ acao: "obterPresetsFiltros" });
    const preset = (resposta?.lista || []).find((p) => p.id === id);
    if (!preset) return;
    const salvo = await send({ acao: "salvarPresetFiltro", nome: preset.nome, filtros: preset.filtros, tornarDefault: true });
    if (salvo?.ok) { mostrarToast(`"${preset.nome}" agora é o preset padrão.`, "sucesso"); renderizarPresets(); }
    else mostrarToast(salvo?.erro || "Falha ao definir padrão.", "erro");
  }

  function limparFiltros() {
    el.filtroPais.value = "BR";
    el.filtroStatusApi.value = "ACTIVE";
    el.filtroMidia.value = "todos";
    el.filtroPlataforma.value = "ambos";
    el.filtroOrdenacao.value = "mais_recente";
    el.filtroCopiasMin.value = "0";
    el.filtroDiasMin.value = "0";
    el.filtroDestino.value = "todos";
    el.filtroEntregavel.value = "todos";
    if (el.inputNegativas) el.inputNegativas.value = "";
    [el.filtroTodos, el.filtroNutra, el.filtroInfo].forEach((b) => {
      if (b) b.classList.toggle("ativo", b.dataset.segment === "");
    });
    salvarConfiguracoesBusca().catch(() => {});
    aplicarFiltros();
    mostrarToast("Filtros limpos.", "info");
  }

  /* ─── Favoritos (rota dedicada) ─────────────────────── */

  async function carregarFavoritos() {
    const resposta = await send({ acao: "obterFavoritos" });
    const lista = document.getElementById("listaFavoritos");
    const vazio = document.getElementById("vazioFavoritos");
    if (!lista) return;
    const favoritos = resposta?.ok ? (resposta.favoritos || []) : [];
    vazio.classList.toggle("oculto", favoritos.length > 0);
    lista.innerHTML = "";
    favoritos.forEach((anuncio) => {
      const card = criarCard(anuncio);
      card.style.position = "relative";
      const btnRem = document.createElement("button");
      btnRem.className = "btn secundario";
      btnRem.textContent = "Remover";
      btnRem.title = "Remover dos favoritos";
      btnRem.style.cssText = "position:absolute;top:6px;right:6px;font-size:10px;padding:2px 6px;z-index:3;";
      btnRem.addEventListener("click", (e) => {
        e.stopPropagation();
        removerFavorito(anuncio.idAnuncio);
      });
      card.appendChild(btnRem);
      lista.appendChild(card);
    });
  }

  async function removerFavorito(idAnuncio) {
    if (!idAnuncio) return;
    const resposta = await send({ acao: "removerFavorito", idAnuncio });
    if (resposta?.ok) { mostrarToast("Favorito removido.", "sucesso"); carregarFavoritos(); }
    else mostrarToast(resposta?.erro || "Falha ao remover favorito.", "erro");
  }

  /* ─── F1: biblioteca de palavras-chave ──────────────── */

  let cacheBiblioteca = null;
  let somenteFavoritas = false;

  async function obterBiblioteca() {
    if (cacheBiblioteca) return cacheBiblioteca;
    const resposta = await send({ acao: "obterBibliotecaPalavras" });
    if (resposta?.ok) cacheBiblioteca = resposta;
    return resposta?.ok ? resposta : null;
  }

  function invalidarBiblioteca() { cacheBiblioteca = null; }

  async function renderizarBibliotecaPalavras() {
    const lib = await obterBiblioteca();
    const lista = document.getElementById("listaPalavrasChave");
    if (!lista) return;
    if (!lib) {
      lista.innerHTML = '<div class="estado-vazio">Não foi possível carregar a biblioteca.</div>';
      return;
    }
    popularCategoriasBiblioteca(lib);

    const busca = String(document.getElementById("buscaPalavraChave")?.value || "").trim().toLowerCase();
    const cat = document.getElementById("filtroCategoriaPalavra")?.value || "todas";

    const itens = [];
    (lib.embutidas?.categorias || []).forEach((catg) => {
      (catg.subcategorias || []).forEach((sub) => {
        (sub.palavrasChave || []).forEach((p) => {
          if (!p?.termo) return;
          if (lib.ocultasEmbutidas && lib.ocultasEmbutidas[p.termo]) return;
          itens.push({
            termo: p.termo,
            categoria: catg.categoria || "Geral",
            sinonimos: p.sinonimos || [],
            origemUsuario: false,
            favorito: !!(lib.favoritasEmbutidas || {})[p.termo],
            vezesUsado: 0
          });
        });
      });
    });
    (lib.personalizadas || []).forEach((p) => {
      if (!p?.termo) return;
      itens.push({
        termo: p.termo,
        categoria: p.categoria || "Geral",
        sinonimos: p.sinonimos || [],
        origemUsuario: true,
        id: p.id,
        favorito: p.favorito === true,
        vezesUsado: Number(p.vezesUsado || 0)
      });
    });

    const filtrados = itens.filter((i) => {
      if (busca && !i.termo.toLowerCase().includes(busca) && !(i.sinonimos || []).some((s) => String(s).toLowerCase().includes(busca))) return false;
      if (cat !== "todas" && i.categoria !== cat) return false;
      if (somenteFavoritas && !i.favorito) return false;
      return true;
    });

    lista.innerHTML = "";
    if (!filtrados.length) {
      lista.innerHTML = '<div class="estado-vazio">Nenhuma palavra-chave encontrada.</div>';
    } else {
      filtrados.forEach((i) => lista.appendChild(criarItemPalavra(lib, i)));
    }
    renderizarMaisUsadas(lib);
  }

  function criarItemPalavra(lib, item) {
    const div = document.createElement("div");
    div.className = "palavra-item";
    const termo = document.createElement("span");
    termo.className = "palavra-termo";
    termo.textContent = item.termo;
    if (item.sinonimos.length) termo.title = "Sinônimos: " + item.sinonimos.join(", ");
    const cat = document.createElement("span");
    cat.className = "palavra-categoria";
    cat.textContent = item.categoria;
    const uso = document.createElement("span");
    uso.className = "palavra-uso";
    uso.textContent = item.vezesUsado > 0 ? item.vezesUsado + "x" : "";
    const acoes = document.createElement("span");
    acoes.className = "palavra-acoes";

    const bFav = document.createElement("button");
    bFav.innerHTML = item.favorito
      ? '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/></svg>'
      : '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/></svg>';
    bFav.title = "Favoritar / desfavoritar";
    bFav.addEventListener("click", () => alternarFavoritoPalavra(item));
    acoes.appendChild(bFav);

    [["Rápida", "rapida"], ["Completa", "completa"], ["Nicho", "nicho"]].forEach((par) => {
      const b = document.createElement("button");
      b.textContent = par[0];
      b.title = "Buscar '" + item.termo + "' (" + par[0] + ")";
      b.addEventListener("click", () => usarPalavra(item.termo, par[1]));
      acoes.appendChild(b);
    });

    if (item.origemUsuario) {
      const bRem = document.createElement("button");
      bRem.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
      bRem.title = "Remover palavra-chave";
      bRem.addEventListener("click", () => removerPalavraPersonalizada(item.id));
      acoes.appendChild(bRem);
    }

    div.appendChild(termo);
    div.appendChild(cat);
    div.appendChild(uso);
    div.appendChild(acoes);
    return div;
  }

  function popularCategoriasBiblioteca(lib) {
    const sel = document.getElementById("filtroCategoriaPalavra");
    const selNova = document.getElementById("novaPalavraCategoria");
    const cats = new Set(["Geral"]);
    (lib.embutidas?.categorias || []).forEach((c) => { if (c.categoria) cats.add(c.categoria); });
    (lib.personalizadas || []).forEach((p) => { if (p.categoria) cats.add(p.categoria); });
    const lista = Array.from(cats);
    if (sel && !sel.__populado) {
      sel.__populado = true;
      sel.innerHTML = '<option value="todas">Todas as categorias</option>' + lista.map((c) => `<option value="${sanitizarHtml(c)}">${sanitizarHtml(c)}</option>`).join("");
    }
    if (selNova && !selNova.__populado) {
      selNova.__populado = true;
      selNova.innerHTML = lista.map((c) => `<option value="${sanitizarHtml(c)}">${sanitizarHtml(c)}</option>`).join("");
    }
  }

  function renderizarMaisUsadas(lib) {
    const secao = document.getElementById("secaoMaisUsadas");
    const container = document.getElementById("listaMaisUsadas");
    if (!secao || !container) return;
    const usadas = [];
    Object.keys(lib.ultimoUsoEmbutidas || {}).forEach((t) => usadas.push({ termo: t, ultimo: lib.ultimoUsoEmbutidas[t], vezes: 0 }));
    (lib.personalizadas || []).forEach((p) => {
      if (Number(p.vezesUsado || 0) > 0) usadas.push({ termo: p.termo, ultimo: p.ultimoUsoISO || "", vezes: Number(p.vezesUsado || 0) });
    });
    usadas.sort((a, b) => (b.vezes || 0) - (a.vezes || 0) || String(b.ultimo || "").localeCompare(String(a.ultimo || "")));
    const top = usadas.slice(0, 8);
    secao.classList.toggle("oculto", top.length === 0);
    container.innerHTML = "";
    top.forEach((u) => {
      const chip = document.createElement("button");
      chip.className = "ms-w-chip";
      chip.textContent = u.termo;
      chip.addEventListener("click", () => usarPalavra(u.termo, "rapida"));
      container.appendChild(chip);
    });
  }

  async function adicionarPalavra() {
    const termo = String(document.getElementById("novaPalavraTermo")?.value || "").trim();
    const sinonimosRaw = String(document.getElementById("novaPalavraSinonimos")?.value || "");
    const categoria = document.getElementById("novaPalavraCategoria")?.value || "Geral";
    if (!termo) { mostrarToast("Informe a palavra-chave.", "erro"); return; }
    const resposta = await send({
      acao: "adicionarPalavraChave",
      termo,
      categoria,
      sinonimos: sinonimosRaw.split(",").map((s) => s.trim()).filter(Boolean)
    });
    if (resposta?.ok) {
      mostrarToast("Palavra-chave adicionada.", "sucesso");
      invalidarBiblioteca();
      const t = document.getElementById("novaPalavraTermo");
      if (t) t.value = "";
      const s = document.getElementById("novaPalavraSinonimos");
      if (s) s.value = "";
      renderizarBibliotecaPalavras();
    } else {
      mostrarToast(resposta?.erro || "Falha ao adicionar palavra-chave.", "erro");
    }
  }

  async function removerPalavraPersonalizada(id) {
    const resposta = await send({ acao: "removerPalavraChave", id });
    if (resposta?.ok) {
      mostrarToast("Palavra-chave removida.", "sucesso");
      invalidarBiblioteca();
      renderizarBibliotecaPalavras();
    } else {
      mostrarToast(resposta?.erro || "Falha ao remover.", "erro");
    }
  }

  async function alternarFavoritoPalavra(item) {
    const resposta = await send({
      acao: "alternarFavoritoPalavra",
      termo: item.termo,
      favorito: !item.favorito,
      origemUsuario: item.origemUsuario
    });
    if (resposta?.ok) {
      invalidarBiblioteca();
      renderizarBibliotecaPalavras();
    }
  }

  async function usarPalavra(termo, modo) {
    if (!termo) return;
    send({ acao: "registrarUsoPalavra", termo }).catch(() => {});
    if (el.inputNicho) el.inputNicho.value = termo;
    navegarPara("resultados");
    if (modo === "completa") iniciarVarreduraCompleta();
    else if (modo === "nicho") buscarPorNicho();
    else iniciarBuscaRapida();
  }

  /* ─── F4: fila de downloads em lote ─────────────────── */

  let filaDownloadsCache = [];

  function desenharFilaDownloads(itens = []) {
    filaDownloadsCache = itens;
    const lista = document.getElementById("listaFilaDownloads");
    if (!lista) return;
    lista.innerHTML = "";
    if (!itens.length) {
      lista.innerHTML = '<div class="estado-vazio">Fila vazia. Use "Baixar todos os vídeos visíveis".</div>';
      return;
    }
    itens.forEach((item) => {
      const div = document.createElement("div");
      div.className = "item-fila";
      const nome = document.createElement("span");
      nome.className = "fila-nome";
      nome.textContent = item.idAnuncio || "anuncio";
      if (item.erro) nome.title = item.erro;
      const status = document.createElement("span");
      status.className = "fila-status " + item.status;
      status.textContent = item.status === "na_fila" ? "na fila" : item.status === "baixando" ? "baixando" : item.status === "concluido" ? "concluído" : item.status === "erro" ? "erro" : item.status;
      div.appendChild(nome);
      div.appendChild(status);
      lista.appendChild(div);
    });
  }

  async function renderizarFilaDownloads() {
    const resposta = await send({ acao: "obterFilaDownloads" });
    if (resposta?.ok) desenharFilaDownloads(resposta.itens || []);
  }

  async function baixarTodosVideosVisiveis() {
    let videos = [];
    const abasFB = await chrome.tabs.query({ url: ["*://*.facebook.com/*", "*://facebook.com/*"] });
    for (const aba of abasFB) {
      if (!aba?.id) continue;
      try {
        const resp = await chrome.tabs.sendMessage(aba.id, { acao: "coletarVideosVisiveis" });
        if (resp?.ok && Array.isArray(resp.videos)) videos = videos.concat(resp.videos);
      } catch {}
    }
    const vistos = new Set();
    const unicos = videos.filter((v) => {
      const url = String(v.url || v.videoUrl || "").trim();
      if (!url || vistos.has(url)) return false;
      vistos.add(url);
      return true;
    });
    if (!unicos.length) { mostrarToast("Nenhum vídeo detectado nos cards visíveis.", "erro"); return; }
    const resposta = await send({ acao: "iniciarDownloadLote", videos: unicos });
    if (resposta?.ok) {
      mostrarToast(`${resposta.adicionados || 0} vídeo(s) adicionado(s) à fila.`, "sucesso");
      renderizarFilaDownloads();
    } else {
      mostrarToast(resposta?.erro || "Falha ao iniciar fila de downloads.", "erro");
    }
  }

  async function limparFilaDownloads() {
    const resposta = await send({ acao: "limparFilaDownloads" });
    if (resposta?.ok) {
      mostrarToast("Itens concluídos/erro removidos da fila.", "sucesso");
      renderizarFilaDownloads();
    } else {
      mostrarToast(resposta?.erro || "Falha ao limpar a fila.", "erro");
    }
  }

  /* ─── F5: preferências ──────────────────────────────── */

  async function carregarPreferencias() {
    const resposta = await send({ acao: "obterPreferencias" });
    if (!resposta?.ok) return;
    const p = resposta.preferencias || {};
    const tema = document.getElementById("prefTema");
    const atalhos = document.getElementById("prefAtalhos");
    const pais = document.getElementById("prefPaisPadrao");
    const limite = document.getElementById("prefLimiteResultados");
    const novaAba = document.getElementById("prefAbrirNovaAba");
    if (tema) tema.value = p.tema || "escuro";
    if (atalhos) atalhos.checked = p.atalhosAtivos !== false;
    if (pais) pais.value = p.paisPadrao || "BR";
    if (limite) limite.value = String(p.limiteResultadosPorPagina || 100);
    if (novaAba) novaAba.checked = p.abrirNovaAba === true;
    aplicarTemaPreferencia(p.tema || "escuro");
    const email = document.getElementById("prefEmail");
    if (email) {
      const sessao = await chrome.storage.local.get(["userEmail"]);
      email.textContent = sessao.userEmail || "—";
    }
  }

  async function salvarPreferencias() {
    const preferencias = {
      tema: document.getElementById("prefTema")?.value || "escuro",
      atalhosAtivos: document.getElementById("prefAtalhos")?.checked !== false,
      paisPadrao: document.getElementById("prefPaisPadrao")?.value || "BR",
      limiteResultadosPorPagina: Number(document.getElementById("prefLimiteResultados")?.value || 100),
      abrirNovaAba: document.getElementById("prefAbrirNovaAba")?.checked === true
    };
    const resposta = await send({ acao: "salvarPreferencias", preferencias });
    if (resposta?.ok) {
      aplicarTemaPreferencia(preferencias.tema);
      mostrarToast("Preferências salvas.", "sucesso");
    } else {
      mostrarToast(resposta?.erro || "Falha ao salvar preferências.", "erro");
    }
  }

  function aplicarTemaPreferencia(tema) {
    document.body.classList.toggle("tema-claro", tema === "claro");
  }

  /* ─── Listeners do dashboard (U1/F1/F4/F5) ──────────── */

  function registrarDashboardEventos() {
    document.querySelectorAll(".nav-dash-btn").forEach((b) => {
      b.addEventListener("click", () => navegarPara(b.dataset.rota));
    });
    document.querySelectorAll("[data-atalho]").forEach((b) => {
      b.addEventListener("click", () => navegarPara(b.dataset.atalho));
    });
    const btnAjuda = document.getElementById("btnAjudaAtalhos");
    if (btnAjuda) {
      btnAjuda.addEventListener("click", () => {
        mostrarToast("Atalhos: / foca a busca · Esc fecha · G depois i/r/f/b/a/t/p navega", "info");
      });
    }

    document.getElementById("btnSalvarPresetAtual")?.addEventListener("click", () => salvarPresetAtual(obterNomePreset()));
    document.getElementById("btnSalvarPresetAtual2")?.addEventListener("click", () => salvarPresetAtual(obterNomePreset()));
    document.getElementById("btnLimparFiltros")?.addEventListener("click", limparFiltros);
    document.getElementById("selectPresetAplicar")?.addEventListener("change", (e) => {
      if (e.target.value) aplicarPresetFiltro(e.target.value);
    });

    document.getElementById("btnExportarCSV")?.addEventListener("click", exportarCsv);

    document.getElementById("btnAlternarSomenteFavoritas")?.addEventListener("click", (e) => {
      somenteFavoritas = !somenteFavoritas;
      e.target.classList.toggle("ativo", somenteFavoritas);
      const rotulo = e.target.querySelector(".btn-label");
      if (rotulo) rotulo.textContent = somenteFavoritas ? "Mostrar todas" : "Somente favoritas";
      renderizarBibliotecaPalavras();
    });
    document.getElementById("btnAdicionarPalavra")?.addEventListener("click", adicionarPalavra);
    document.getElementById("novaPalavraTermo")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") adicionarPalavra();
    });
    const buscaPalavra = document.getElementById("buscaPalavraChave");
    if (buscaPalavra) buscaPalavra.addEventListener("input", debounce(() => renderizarBibliotecaPalavras(), 300));
    document.getElementById("filtroCategoriaPalavra")?.addEventListener("change", () => renderizarBibliotecaPalavras());

    document.getElementById("btnBaixarTodosVideos")?.addEventListener("click", baixarTodosVideosVisiveis);
    document.getElementById("btnLimparFila")?.addEventListener("click", limparFilaDownloads);

    document.getElementById("btnSalvarPreferencias")?.addEventListener("click", salvarPreferencias);
    document.getElementById("btnTrocarUsuario2")?.addEventListener("click", async () => {
      await chrome.storage.local.remove(["userEmail", "metaspy_session"]);
      document.getElementById("dashboardView")?.classList.add("oculto");
      document.getElementById("appPrincipal")?.classList.add("oculto");
      document.getElementById("loginView")?.classList.remove("oculto");
    });
    document.getElementById("btnSalvarToken")?.addEventListener("click", salvarToken);
    document.getElementById("btnTestarApi")?.addEventListener("click", testarApi);
    document.getElementById("btnDiagnosticar")?.addEventListener("click", diagnosticarBiblioteca);

    [el.filtroDiasMin, el.filtroCopiasMin].forEach((campo) => {
      campo.addEventListener("change", sincronizarWidgetSliders);
    });
    chrome.storage.onChanged.addListener((mudancas, area) => {
      if (area !== "local" || !mudancas.metaspy_widget) return;
      const novo = mudancas.metaspy_widget.newValue;
      if (!novo) return;
      if (novo.diasMin !== undefined) el.filtroDiasMin.value = String(novo.diasMin);
      if (novo.copiasMin !== undefined) el.filtroCopiasMin.value = String(novo.copiasMin);
      salvarConfiguracoesBusca().catch(() => {});
      aplicarFiltrosDebounced();
    });
  }

  function sincronizarWidgetSliders() {
    chrome.storage.local.get(["metaspy_widget"]).then((dados) => {
      const w = (dados && dados.metaspy_widget) || {};
      /* 0 = sem filtro no popup; o slider do widget comeca em 1, entao so
         enviamos valor quando existe um minimo de verdade. */
      const copias = Number(el.filtroCopiasMin.value || 0);
      const proximo = { ...w, diasMin: Number(el.filtroDiasMin.value || 0) };
      if (copias >= 1) proximo.copiasMin = copias;
      chrome.storage.local.set({ metaspy_widget: proximo }).catch(() => {});
    });
  }

  function registrarAtalhos() {
    let teclaG = false;
    document.addEventListener("keydown", (ev) => {
      const atalhos = document.getElementById("prefAtalhos");
      if (atalhos && atalhos.checked === false) { teclaG = false; return; }
      const alvo = ev.target;
      const digitando = alvo && (alvo.tagName === "INPUT" || alvo.tagName === "TEXTAREA" || alvo.tagName === "SELECT");
      if (ev.key === "Escape") {
        fecharModal();
        if (el.modalAnalise?.open) fecharAnalise();
        return;
      }
      if (digitando) { teclaG = false; return; }
      if (ev.key === "/") {
        ev.preventDefault();
        el.inputNicho.focus();
        return;
      }
      if (ev.key.toLowerCase() === "g" && !teclaG) {
        teclaG = true;
        mostrarToast("Pressione a letra da tela: i/r/f/b/a/t/p", "info");
        return;
      }
      if (teclaG) {
        teclaG = false;
        const mapa = { i: "inicio", r: "resultados", f: "favoritos", b: "biblioteca", a: "analise", t: "ferramentas", p: "preferencias" };
        const alvo2 = mapa[ev.key.toLowerCase()];
        if (alvo2) navegarPara(alvo2);
      }
    });
  }

  async function bootstrap() {
    await inicializarLogin();
    registrarEventos();
    registrarDashboardEventos();
    registrarAtalhos();
    await atualizarStatusConexao();
    await carregarConfiguracoesBusca();
    if (el.tempoVarreduraProfundoMin) {
      chrome.storage.local.get(["tempoVarreduraProfundoMin"])
        .then((d) => {
          const v = Number(d.tempoVarreduraProfundoMin);
          if (v && [5, 10, 15, 25].includes(v)) el.tempoVarreduraProfundoMin.value = String(v);
        })
        .catch(() => {});
    }
    await carregarStatusVarredura();
    await carregarResultadosAtuais();
    await carregarToken();
    await atualizarDashboardStatus();
    send({ acao: "obterPreferencias" })
      .then((resp) => { if (resp?.ok) aplicarTemaPreferencia(resp.preferencias?.tema || "escuro"); })
      .catch(() => {});
  }

  bootstrap();
})();
