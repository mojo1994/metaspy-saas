(function initMetaSpyUtils(scope) {
  "use strict";

  const SINONIMOS_NICHO = {
    emagrecimento: ["perder peso", "dieta", "queima de gordura", "metabolismo", "fitness", "saude"],
    saude: ["bem-estar", "imunidade", "suplemento", "tratamento", "nutricao"],
    beleza: ["estetica", "pele", "cabelo", "cosmetico", "rejuvenescimento"],
    fitness: ["treino", "academia", "hipertrofia", "definicao", "performance"],
    marketing: ["trafego", "copy", "conversao", "funil", "vendas"],
    financas: ["renda extra", "investimento", "credito", "cartao", "consorcio"]
  };

  function debounce(fn, delay = 500) {
    let timer;
    return function debounced(...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  }

  function esperar(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function esperarAleatorio(minMs, maxMs) {
    const min = Math.max(0, Number(minMs || 0));
    const max = Math.max(min, Number(maxMs || min));
    const valor = Math.floor(Math.random() * (max - min + 1)) + min;
    return esperar(valor);
  }

  const METADADOS_FACEBOOK = [
    'biblioteca de anuncios', 'biblioteca de anúncios', 'ver anuncio', 'ver anúncio',
    'anuncio pausado', 'anúncio pausado', 'anuncio inativo', 'anúncio inativo',
    'sobre este anuncio', 'sobre este anúncio', 'por que este anuncio?', 'por que este anúncio?',
    'anuncios', 'anúncios', 'filtros', 'saiba mais', 'active', 'inactive',
    'conteudos de marca', 'conteúdos de marca', 'ad library',
    'relatorio', 'relatório', 'api da biblioteca',
    'identificacao da biblioteca', 'identificação da biblioteca',
    'library id', 'ad id', 'plataformas', 'platforms',
    'abrir menu', 'open menu', 'ver detalhes', 'see ad details',
    'detalhes', 'details', 'pendente', 'running for',
    'este anuncio tem varias versoes', 'este anúncio tem várias versões',
    'esse anuncio tem', 'esse anúncio tem', 'this ad has multiple versions',
    'todos os direitos reservados'
  ];

  function filtrarTextoUtil(texto = "") {
    if (!texto) return "";
    const linhas = String(texto).split("\n").filter(Boolean);
    const norm = linhas.filter((linha) => {
      const limpa = linha.replace(/\s+/g, " ").trim();
      if (limpa.length < 4) return false;
      const normalizada = normalizarTexto(limpa);
      return !METADADOS_FACEBOOK.some((meta) => normalizada.includes(meta));
    });
    return norm.length ? limparTexto(norm.join(" ")) : "";
  }

  function ehRealmenteAtivo(anuncio = {}) {
    const activeStatus = String(anuncio.adActiveStatus || "").toUpperCase();
    if (activeStatus !== "ACTIVE") return false;
    const dataFim = converterData(anuncio.dataFimISO || anuncio.ad_delivery_stop_time || null);
    if (dataFim && dataFim.getTime() < Date.now()) return false;
    return true;
  }

  function calcularGastoDiarioEstimado(anuncio = {}) {
    const dias = Math.max(1, Number(anuncio.diasAtivo || 0));
    return Math.round(Number(anuncio.spendMax || 0) / dias);
  }

  function calcularAlcanceDiario(anuncio = {}) {
    const dias = Math.max(1, Number(anuncio.diasAtivo || 0));
    return Math.round(Number(anuncio.impressionsMax || 0) / dias);
  }

  function calcularCustoPorMil(anuncio = {}) {
    const impressions = Number(anuncio.impressionsMax || 0);
    if (impressions <= 0) return 0;
    return Math.round((Number(anuncio.spendMax || 0) / impressions) * 1000 * 100) / 100;
  }

  function detectarMultiPagina(anuncios = []) {
    if (!Array.isArray(anuncios) || anuncios.length < 2) return [];
    const grupos = new Map();
    for (const a of anuncios) {
      const texto = normalizarTexto(a.textoCompleto || "");
      if (!texto) continue;
      let encontrou = false;
      for (const [chave, grupo] of grupos) {
        if (similaridadeTexto(texto, chave) >= 0.95) {
          grupo.push(a);
          encontrou = true;
          break;
        }
      }
      if (!encontrou) grupos.set(texto, [a]);
    }
    const multi = [];
    for (const grupo of grupos.values()) {
      const paginas = [...new Set(grupo.map((a) => a.anunciante).filter(Boolean))];
      if (paginas.length > 1) multi.push({ paginas, anuncios: grupo, texto: grupo[0]?.textoCompleto || "" });
    }
    return multi;
  }

  function normalizarTexto(texto = "") {
    return String(texto)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();
  }

  function limparTexto(texto = "") {
    return String(texto).replace(/\s+/g, " ").trim();
  }

  function paraNumero(valor) {
    if (typeof valor === "number" && Number.isFinite(valor)) return valor;
    if (typeof valor === "string") {
      const limpo = valor.replace(/[^\d.,-]/g, "").replace(/\./g, "").replace(",", ".");
      const n = Number(limpo);
      return Number.isFinite(n) ? n : 0;
    }
    return 0;
  }

  function extrairLimiteSuperior(campo) {
    if (!campo) return 0;
    if (typeof campo === "number") return Math.max(0, campo);
    if (typeof campo === "string") return Math.max(0, paraNumero(campo));
    if (typeof campo === "object") {
      const upper =
        campo.upper_bound ??
        campo.upperBound ??
        campo.max ??
        campo.value ??
        campo.impressions_max ??
        campo.spend_max;
      return Math.max(0, paraNumero(upper));
    }
    return 0;
  }

  function converterData(data) {
    if (!data) return null;
    if (data instanceof Date) return Number.isNaN(data.getTime()) ? null : data;
    const d = new Date(data);
    return Number.isNaN(d.getTime()) ? null : d;
  }

  function toIso(data) {
    const d = converterData(data);
    return d ? d.toISOString() : null;
  }

  function formatarDataBr(data) {
    const d = converterData(data);
    return d ? d.toLocaleDateString("pt-BR") : "-";
  }

  function calcularDiasAtivo(dataInicio, dataFim = null) {
    const inicio = converterData(dataInicio);
    if (!inicio) return 0;
    const fim = converterData(dataFim) || new Date();
    return Math.max(0, Math.floor((fim.getTime() - inicio.getTime()) / 86400000));
  }

  function normalizarPlataformas(plataformas) {
    const lista = Array.isArray(plataformas) ? plataformas : [];
    const mapa = {
      facebook: "Facebook",
      instagram: "Instagram",
      messenger: "Messenger",
      audience_network: "Audience Network",
      audiencenetwork: "Audience Network",
      "audience network": "Audience Network"
    };
    const normalizadas = lista
      .map((item) => normalizarTexto(item))
      .filter(Boolean)
      .map((item) => mapa[item] || item.charAt(0).toUpperCase() + item.slice(1));
    return [...new Set(normalizadas)];
  }

  function normalizarPais(pais = "") {
    const texto = normalizarTexto(pais);
    const mapa = {
      all: "ALL",
      todos: "ALL",
      "todos os países": "ALL",
      "todos os paises": "ALL",
      br: "BR",
      brasil: "BR",
      us: "US",
      usa: "US",
      eua: "US",
      pt: "PT",
      portugal: "PT",
      mx: "MX",
      mexico: "MX",
      "méxico": "MX",
      ar: "AR",
      argentina: "AR",
      cl: "CL",
      chile: "CL",
      co: "CO",
      colombia: "CO"
    };
    return mapa[texto] || String(pais || "BR").toUpperCase();
  }

  function obterTextoCriativo(campo) {
    if (!campo) return "";
    if (Array.isArray(campo)) return limparTexto(campo.filter(Boolean).join(" "));
    if (typeof campo === "string") return limparTexto(campo);
    return "";
  }

  function similaridadeTexto(a, b) {
    const na = normalizarTexto(a);
    const nb = normalizarTexto(b);
    if (na === nb) return 1;
    const maxLen = Math.max(na.length, nb.length);
    if (maxLen === 0) return 1;
    const dist = levenshtein(na, nb);
    return 1 - dist / maxLen;
  }

  function levenshtein(a, b) {
    const m = a.length, n = b.length;
    const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        dp[i][j] = a[i - 1] === b[j - 1] ? dp[i - 1][j - 1] : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
    }
    return dp[m][n];
  }

  function contarCopiasIguais(ad = {}) {
    const corpos = Array.isArray(ad.ad_creative_bodies) ? ad.ad_creative_bodies.filter(Boolean) : [];
    const titulos = Array.isArray(ad.ad_creative_link_titles) ? ad.ad_creative_link_titles.filter(Boolean) : [];
    const descricoes = Array.isArray(ad.ad_creative_link_descriptions) ? ad.ad_creative_link_descriptions.filter(Boolean) : [];
    const legendas = Array.isArray(ad.ad_creative_link_captions) ? ad.ad_creative_link_captions.filter(Boolean) : [];

    const todosTextos = [...corpos, ...titulos, ...descricoes, ...legendas].filter(Boolean);
    if (todosTextos.length < 2) return todosTextos.length;

    const grupos = [];
    for (const texto of todosTextos) {
      let encontrou = false;
      for (const grupo of grupos) {
        if (similaridadeTexto(texto, grupo[0]) >= 0.95) {
          grupo.push(texto);
          encontrou = true;
          break;
        }
      }
      if (!encontrou) grupos.push([texto]);
    }
    const maior = grupos.reduce((max, g) => Math.max(max, g.length), 0);
    return Math.max(1, maior);
  }

  /* Quantidade de copias: criativos praticamente identicos dentro do lote
     (texto com similaridade >= 0.95) + a contagem que a propria Biblioteca/API
     ja devolveu. Fonte unica para popup, background e widget. */
  function mapearCopiasPorAnuncio(anuncios = []) {
    const mapa = new Map();
    const lista = Array.isArray(anuncios) ? anuncios : [];
    const porChave = new Map();
    for (const a of lista) {
      if (!a || !a.idAnuncio) continue;
      const chave = normalizarTexto(a.textoCompleto || a.texto || "").replace(/\s+/g, " ");
      if (!chave) continue;
      const ids = porChave.get(chave) || [];
      ids.push(a.idAnuncio);
      porChave.set(chave, ids);
    }
    const grupos = [];
    for (const [chave, ids] of porChave) {
      let grupo = null;
      for (const g of grupos) {
        const la = chave.length;
        const lb = g.chave.length;
        if (
          Math.abs(la - lb) <= Math.max(2, Math.min(la, lb) * 0.06) &&
          similaridadeTexto(chave, g.chave) >= 0.95
        ) {
          grupo = g;
          break;
        }
      }
      if (!grupo) {
        grupo = { chave, ids: [] };
        grupos.push(grupo);
      }
      grupo.ids = grupo.ids.concat(ids);
    }
    for (const g of grupos) {
      const copias = g.ids.length;
      for (const id of g.ids) mapa.set(id, copias);
    }
    return mapa;
  }

  function contarCopiasAnuncio(anuncio = {}, mapaCopias = new Map()) {
    const agrupadas = Number((mapaCopias instanceof Map ? mapaCopias : new Map()).get(anuncio.idAnuncio) || 0);
    const criativas = Number(anuncio.quantidadeCopiasIguais || 0);
    return Math.max(1, agrupadas, criativas);
  }

  /* Regra da busca: manter somente anuncios com pelo menos `copiasMin` copias. */
  function filtrarPorCopiasMin(anuncios = [], copiasMin = 0) {
    const lista = Array.isArray(anuncios) ? anuncios.filter(Boolean) : [];
    const minimo = Math.max(0, Math.floor(Number(copiasMin) || 0));
    if (minimo <= 1) return lista;
    const mapaCopias = mapearCopiasPorAnuncio(lista);
    return lista.filter((anuncio) => contarCopiasAnuncio(anuncio, mapaCopias) >= minimo);
  }

  function normalizarAnuncioApi(ad = {}) {
    const id = String(ad.id || ad.ad_archive_id || "").trim();
    if (!id) return null;

    const textoCompletoRaw =
      obterTextoCriativo(ad.ad_creative_bodies) ||
      obterTextoCriativo(ad.ad_creative_link_descriptions) ||
      obterTextoCriativo(ad.ad_creative_link_titles);
    const textoCompleto = filtrarTextoUtil(textoCompletoRaw) || textoCompletoRaw;

    const plataformas = normalizarPlataformas(ad.publisher_platforms || []);
    const inicio = toIso(ad.ad_delivery_start_time || ad.ad_creation_time);
    const fim = toIso(ad.ad_delivery_stop_time);
    const diasAtivo = calcularDiasAtivo(inicio, fim);

    const spendMax = Math.max(paraNumero(ad.spend_max), extrairLimiteSuperior(ad.spend), extrairLimiteSuperior(ad.spend_max));
    const impressionsMax = Math.max(
      paraNumero(ad.impressions_max),
      extrairLimiteSuperior(ad.impressions),
      extrairLimiteSuperior(ad.impressions_max)
    );
    const audienceMax = Math.max(
      paraNumero(ad.estimated_audience_size_upper),
      extrairLimiteSuperior(ad.estimated_audience_size),
      extrairLimiteSuperior(ad.estimated_audience_size_upper)
    );

    const fimConvertido = converterData(fim);
    const fimNoPassado = !!(fimConvertido && fimConvertido.getTime() < Date.now());
    const activeStatusInformado = String(ad.ad_active_status || "").trim();
    const activeStatus = activeStatusInformado ? activeStatusInformado.toUpperCase() : fimNoPassado ? "INACTIVE" : "UNKNOWN";
    const ativo = activeStatus === "ACTIVE" && !fimNoPassado;

    const quantidadeCopiasIguais = contarCopiasIguais(ad);
    const pageName = String(ad.page_name || "").trim();
    const anunciante = pageName || (() => {
      const titulo = obterTextoCriativo(ad.ad_creative_link_titles);
      return titulo ? titulo.slice(0, 40) : "(sem nome)";
    })();

    const anuncio = {
      idAnuncio: id,
      anunciante,
      texto: textoCompleto.slice(0, 280),
      textoCompleto,
      midias: ad.ad_creative_thumbnail_url ? [{ url: ad.ad_creative_thumbnail_url, tipo: "imagem" }] : [],
      dataInicioISO: inicio,
      dataFimISO: fim,
      dataUltimaAtualizacaoISO: fim || inicio,
      plataformas,
      urlDestino: obterTextoCriativo(ad.ad_creative_link_url),
      urlBiblioteca: String(ad.ad_snapshot_url || `https://www.facebook.com/ads/library/?id=${id}`),
      cta: "Saiba mais",
      adActiveStatus: activeStatus,
      statusInformadoApi: Boolean(activeStatusInformado),
      statusTexto: ativo ? "Ativo" : "Inativo",
      ativo,
      diasAtivo,
      spendMax,
      impressionsMax,
      audienceMax,
      variacoesAtivasEstimadas: quantidadeCopiasIguais,
      consistenciaTemporal: 0,
      engajamentoEstimado: 0,
      scoreEscala: 0,
      quantidadeCopiasIguais
    };

    return anuncio;
  }

  function ehAnuncioAtivoRigoroso(anuncio = {}) {
    const status = String(anuncio.statusTexto || "Ativo");
    if (status !== "Ativo") return false;
    const dataFim = converterData(anuncio.dataFimISO || anuncio.ad_delivery_stop_time || null);
    if (dataFim && dataFim.getTime() < Date.now()) return false;
    const activeStatus = String(anuncio.adActiveStatus || "UNKNOWN").toUpperCase();
    if (activeStatus !== "ACTIVE") return false;
    return true;
  }

  function calcularVariacoesEstimadas(anuncio = {}) {
    const spend = Number(anuncio.spendMax || 0);
    const impressions = Number(anuncio.impressionsMax || 0);
    let pontos = 0;
    if (spend >= 100000) pontos += 4;
    else if (spend >= 50000) pontos += 3;
    else if (spend >= 10000) pontos += 2;
    else if (spend > 0) pontos += 1;

    if (impressions >= 1000000) pontos += 4;
    else if (impressions >= 250000) pontos += 3;
    else if (impressions >= 50000) pontos += 2;
    else if (impressions > 0) pontos += 1;

    return Math.min(10, Math.max(1, pontos));
  }

  function calcularScoreEscala(anuncio = {}) {
    const variacoes = calcularVariacoesEstimadas(anuncio);
    const diasAtivo = Number(anuncio.diasAtivo || 0);
    const semDataFim = !anuncio.dataFimISO;
    const plataformas = Array.isArray(anuncio.plataformas) ? anuncio.plataformas : [];
    const impressions = Number(anuncio.impressionsMax || 0);

    const pVariacoes = Math.min(100, variacoes * 10);
    const pTempo = Math.min(100, (diasAtivo / 90) * 100);
    const pConsistencia = semDataFim ? 100 : Math.max(20, 100 - Math.min(80, diasAtivo * 0.5));
    const pPlataformas = Math.min(100, (plataformas.length / 4) * 100);
    const pEngajamento = Math.min(100, impressions / 10000);

    const score =
      pVariacoes * 0.3 +
      pTempo * 0.25 +
      pConsistencia * 0.2 +
      pPlataformas * 0.15 +
      pEngajamento * 0.1;

    return Math.max(0, Math.min(100, Math.round(score)));
  }

  function enriquecerAnuncioComScore(anuncio = {}) {
    const variacoesAtivasEstimadas = calcularVariacoesEstimadas(anuncio);
    const consistenciaTemporal = !anuncio.dataFimISO ? 100 : 55;
    const engajamentoEstimado = Math.min(100, Number(anuncio.impressionsMax || 0) / 10000);
    const scoreEscala = calcularScoreEscala(anuncio);
    const oferta = classificarOfertaAvancada(anuncio);
    const statusEscala = scoreEscala >= 80 ? "ALTA ESCALA" : scoreEscala >= 60 || Number(anuncio.diasAtivo || 0) >= 150 ? "ESCALADA" : "TESTANDO";
    const gastoDiario = calcularGastoDiarioEstimado(anuncio);
    const alcanceDiario = calcularAlcanceDiario(anuncio);
    const cpm = calcularCustoPorMil(anuncio);
    return {
      ...anuncio,
      destino: oferta.destino,
      entregavel: oferta.entregavel,
      variacoesAtivas: variacoesAtivasEstimadas,
      variacoesAtivasEstimadas,
      consistenciaTemporal,
      engajamentoEstimado: Math.round(engajamentoEstimado),
      scoreEscala,
      statusEscala,
      evergreen: Number(anuncio.diasAtivo || 0) > 90,
      gastoDiarioEstimado: gastoDiario,
      alcanceDiarioEstimado: alcanceDiario,
      custoPorMil: cpm,
      multiPagina: false
    };
  }

  function gerarSinonimosNicho(termo = "") {
    const base = normalizarTexto(termo);
    const sinonimos = SINONIMOS_NICHO[base] || [];
    return [...new Set([base, ...sinonimos].filter(Boolean))];
  }

  function correspondeNicho(anuncio, termo = "") {
    if (!termo) return true;
    const termos = gerarSinonimosNicho(termo);
    const texto = normalizarTexto(`${anuncio.textoCompleto || ""} ${anuncio.anunciante || ""}`);
    return termos.some((item) => texto.includes(item));
  }

  function detectarDestino(anuncio = {}) {
    const texto = normalizarTexto(`${anuncio.textoCompleto || ""} ${anuncio.urlDestino || ""}`);
    const url = normalizarTexto(anuncio.urlDestino || "");
    if (/wa\.me|whatsapp\.com/.test(url) || /whatsapp/.test(texto)) return "WhatsApp";
    if (/instagram\.com/.test(url) || /instagram/.test(texto)) return "Instagram";
    if (/checkout|landing|sales|lp|funil|page|oferta|vendas/.test(texto)) return "Página de vendas";
    return "Página de vendas";
  }

  function detectarEntregavel(anuncio = {}) {
    const texto = normalizarTexto(`${anuncio.textoCompleto || ""} ${anuncio.urlDestino || ""}`);
    const mapa = [
      { chave: "Nutra", termos: ["nutra", "suplemento", "capsula", "capsulas", "comprimido"] },
      { chave: "App", termos: ["app", "aplicativo", "software", "sistema"] },
      { chave: "PDF", termos: ["pdf", "ebook", "apostila", "guia", "arquivo"] },
      { chave: "Curso", termos: ["curso", "aula", "treinamento", "formacao", "turma"] },
      { chave: "Instagram", termos: ["instagram", "perfil", "seguidores", "reels", "direct"] },
      { chave: "Tutorial", termos: ["tutorial", "passo a passo", "como fazer", "guia rapido"] },
      { chave: "Acompanhamento", termos: ["acompanhamento", "seguimento", "suporte", "mentoria"] },
      { chave: "Mentoria", termos: ["mentoria", "sessao", "1:1"] },
      { chave: "Consultoria", termos: ["consultoria", "diagnostico", "estrategia", "avaliacao"] }
    ];
    for (const item of mapa) {
      if (item.termos.some((termo) => texto.includes(normalizarTexto(termo)))) {
        return item.chave;
      }
    }
    return "Indefinido";
  }

  function classificarOfertaAvancada(anuncio = {}) {
    return {
      destino: detectarDestino(anuncio),
      entregavel: detectarEntregavel(anuncio)
    };
  }

  function calcularCompetitividadeNicho(anuncios = []) {
    if (!anuncios.length) return 0;
    const altos = anuncios.filter((a) => Number(a.scoreEscala || 0) >= 80).length;
    return Math.max(0, Math.min(100, Math.round((altos / anuncios.length) * 100)));
  }

  function escaparCsv(valor) {
    const texto = String(valor ?? "").replace(/"/g, "\"\"");
    return /[",;\n]/.test(texto) ? `"${texto}"` : texto;
  }

  function gerarCsv(anuncios = []) {
    const cabecalho = ["ID", "Anunciante", "Texto", "Score", "Variações (estimado)", "Tempo ativo", "Plataformas", "URL"];
    const linhas = anuncios.map((a) =>
      [
        a.idAnuncio || "",
        a.anunciante || "",
        a.texto || "",
        a.scoreEscala ?? "",
        a.variacoesAtivasEstimadas ?? "",
        a.diasAtivo ?? "",
        (a.plataformas || []).join(" | "),
        a.urlBiblioteca || ""
      ]
        .map(escaparCsv)
        .join(";")
    );
    return [cabecalho.join(";"), ...linhas].join("\n");
  }

  function sanitizarHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function escaparAspas(str) {
    return String(str).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  scope.MetaSpyUtils = {
    debounce,
    esperar,
    esperarAleatorio,
    normalizarTexto,
    limparTexto,
    filtrarTextoUtil,
    converterData,
    toIso,
    formatarDataBr,
    calcularDiasAtivo,
    normalizarPlataformas,
    normalizarPais,
    normalizarAnuncioApi,
    ehAnuncioAtivoRigoroso,
    ehRealmenteAtivo,
    enriquecerAnuncioComScore,
    calcularScoreEscala,
    calcularGastoDiarioEstimado,
    calcularAlcanceDiario,
    calcularCustoPorMil,
    detectarMultiPagina,
    gerarSinonimosNicho,
    correspondeNicho,
    detectarDestino,
    detectarEntregavel,
    classificarOfertaAvancada,
    calcularCompetitividadeNicho,
    gerarCsv,
    contarCopiasIguais,
    mapearCopiasPorAnuncio,
    contarCopiasAnuncio,
    filtrarPorCopiasMin,
    similaridadeTexto,
    sanitizarHtml,
    escaparAspas
  };
})(typeof self !== "undefined" ? self : window);
