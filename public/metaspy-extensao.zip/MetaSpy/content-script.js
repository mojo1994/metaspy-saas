﻿"use strict";

(function iniciarContentScriptMetaSpy() {
  const VERSAO_CONTENT = "5.0.0";
  if (window.__metaspyContentVersion === VERSAO_CONTENT) return;
  window.__metaspyContentIniciado = true;
  window.__metaspyContentVersion = VERSAO_CONTENT;

  console.log("[MetaSpy] Content script ativo na pagina");
  console.log("[MetaSpy] URL:", location.href);
  console.log("[MetaSpy] readyState:", document.readyState);

  const estado = {
    parar: false,
    varreduraAtiva: false
  };

  /* P1: scan rebalanced. Adaptive inter-scroll delay (was a flat 2000ms),
     more generous scroll budget, and a shorter batch-and-notify threshold. */
  const LIMITE_ROLAGENS_VARREDURA = 90;
  const PAUSA_ROLAGEM_INICIAL_MS = 450;
  const PAUSA_ROLAGEM_MAX_MS = 1600;
  const INCREMENTO_SCROLL_PX = 800;
  const CICLOS_SEM_NOVOS_CARDS_SAIDA = 12;
  const CICLOS_SEM_NOVIDADE_SAIDA = 6;
  const TIMEOUT_VARREDURA_MS = 60000;
  const LOTE_ANUNCIOS_POR_ENVIO = 5;

  /* F2c: margem de tempo (ms) reservada para tentar mais um lote de resultados
     ("Ver mais") no modo aprofundado — equivale a ~15s de conteudo seguro. */
  const BUFFER_PROXIMO_LOTE_MS = 15000;

  /* Overlay fixo de nivel superior (#metaspy-overlay) que desenha os aneis de
     destaque FORA da arvore de cards: anexado em <html>, position:fixed com
     z-index maximo — nenhum background/overflow/stacking do Facebook o cobre. */
  const METASPY_OVERLAY_ID = "metaspy-overlay";

  /* P1: cached detection strategy + resolved results container for the page session. */
  let estrategiaCardsCache = null;
  let containerResultados = null;
  let inicioVarreduraMs = 0;

  function normalizarTextoLocal(texto = "") {
    return String(texto)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();
  }

  function aguardar(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function extrairIdDoElemento(elemento) {
    try {
      if (!elemento) return null;
      const link = elemento.closest("a[href*='id=']") || elemento.querySelector("a[href*='id=']") ||
                   elemento.closest("a[href*='ad_archive_id']") || elemento.querySelector("a[href*='ad_archive_id']") ||
                   elemento.closest("a[href*='ads/library']") || elemento.querySelector("a[href*='ads/library']");
      const href = link?.href || link?.getAttribute("href") || "";
      const matchHref = href.match(/[?&]id=(\d{5,})/i) || href.match(/[?&]ad_archive_id=(\d{5,})/i) || href.match(/\/ads\/library\/?[?&].*?id=(\d{5,})/i);
      if (matchHref) return matchHref[1];

      const texto = String(elemento.innerText || "");
      const patternsTexto = [
        /(?:ID|id|Id)\s*(?:do|da)?\s*(?:an[u\u00fa]ncio|biblioteca)?\s*[:\s#]*(\d{5,})/,
        /Identifica[cç][aã]o\s+da\s+biblioteca\s*[:\s#]*(\d{5,})/i,
        /Library\s+ID\s*[:\s#]*(\d{5,})/i,
        /Ad\s+ID\s*[:\s#]*(\d{5,})/i,
        /(\d{14,})/
      ];
      for (const pat of patternsTexto) {
        const m = texto.match(pat);
        if (m) return m[1];
      }
      return null;
    } catch (erro) {
      console.error("MetaSpy: Falha ao extrair ID do elemento:", erro);
      return null;
    }
  }

  function extrairStatusTextoCard(card) {
    try {
      const texto = String(card?.innerText || "");
      const match = texto.match(/Status\s*:?\s*(Ativo|Inativo|Removido|Conclu[i\u00ed]do|Pausado)/i);
      if (match) return match[1];
      if (texto.includes("Ativo")) return "Ativo";
      if (texto.includes("Inativo")) return "Inativo";
      if (texto.includes("Removido")) return "Removido";
      if (/Conclu[i\u00ed]do/i.test(texto)) return "Concluido";
      if (texto.includes("Pausado")) return "Pausado";
      return "";
    } catch (erro) {
      console.error("MetaSpy: Falha ao extrair status textual:", erro);
      return "";
    }
  }

  function cardPareceAtivo(card) {
    const status = extrairStatusTextoCard(card);
    if (!status) return true;
    return !/Inativo|Removido|Conclu[i\u00ed]do|Pausado/i.test(status);
  }

  function extrairDataFimCard(card) {
    try {
      const texto = String(card?.innerText || "");
      const match = texto.match(
        /(T[e\u00e9]rmino|Fim da veicula[c\u00e7][a\u00e3]o|Termina em)\s*:?\s*([0-9]{1,2}[\/.-][0-9]{1,2}[\/.-][0-9]{2,4})/i
      );
      if (!match) return null;
      const [dia, mes, ano] = match[2].split(/[\/.-]/).map((v) => Number(v));
      const anoFinal = ano < 100 ? Number(`20${ano}`) : ano;
      const data = new Date(anoFinal, mes - 1, dia);
      return Number.isNaN(data.getTime()) ? null : data;
    } catch (erro) {
      console.error("MetaSpy: Falha ao extrair data de termino:", erro);
      return null;
    }
  }

  const MESES = { jan:0,fev:1,mar:2,abr:3,mai:4,jun:5,jul:6,ago:7,set:8,out:9,nov:10,dez:11,
    janeiro:0,fevereiro:1,marco:2,abril:3,maio:4,junho:5,julho:6,agosto:7,setembro:8,outubro:9,novembro:10,dezembro:11,
    jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,oct:9,nov:10,dec:11,
    january:0,february:1,march:2,april:3,june:5,july:6,august:7,september:8,october:9,november:10,december:11 };

  function parseData(dia, mes, ano) {
    const d = Number(dia), a = Number(ano);
    const m = MESES[String(mes).toLowerCase().trim().slice(0, 3)];
    if (m !== undefined) {
      const dt = new Date(a, m, d);
      if (!Number.isNaN(dt.getTime())) return dt;
    }
    const mn = Number(mes);
    if (!Number.isNaN(mn)) {
      const anoFinal = a < 100 ? 2000 + a : a;
      const dt = new Date(anoFinal, mn - 1, d);
      if (!Number.isNaN(dt.getTime())) return dt;
    }
    return null;
  }

  function extrairQualquerData(texto) {
    const datas = [];
    const padroes = [
      { re: /(\d{1,2})\s+de\s+(janeiro|fevereiro|mar[çc]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s+de\s+(\d{4})/gi, extrair: (m) => [m[1], m[2], m[3]] },
      { re: /(\d{1,2})\s+de\s+(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)\s+de\s+(\d{4})/gi, extrair: (m) => [m[1], m[2], m[3]] },
      { re: /(\d{1,2})\s+de\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s+de\s+(\d{4})/gi, extrair: (m) => [m[1], m[2], m[3]] },
      { re: /(\d{1,2})\s+(?:de\s+)?(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)\s+(\d{4})/gi, extrair: (m) => [m[1], m[2], m[3]] },
      { re: /(\d{1,2})\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s+(\d{4})/gi, extrair: (m) => [m[1], m[2], m[3]] },
      { re: /(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/g, extrair: (m) => [m[1], m[2], m[3]] },
      { re: /(\d{4})-(\d{2})-(\d{2})/g, extrair: (m) => [m[3], m[2], m[1]] },
      { re: /(janeiro|fevereiro|mar[çc]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s+(\d{1,2}),?\s*(\d{4})/gi, extrair: (m) => [m[2], m[1], m[3]] },
      { re: /(january|february|march|april|june|july|august|september|october|november|december)\s+(\d{1,2}),?\s*(\d{4})/gi, extrair: (m) => [m[2], m[1], m[3]] },
      { re: /(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s+(\d{1,2}),?\s*(\d{4})/gi, extrair: (m) => [m[2], m[1], m[3]] }
    ];
    for (const { re, extrair } of padroes) {
      for (const m of texto.matchAll(re)) {
        const [diaStr, mesStr, anoStr] = extrair(m);
        if (!diaStr || !mesStr || !anoStr) continue;
        const d = Number(diaStr);
        const a = Number(anoStr);
        if (a < 100) continue;
        const mesIdx = MESES[String(mesStr).toLowerCase().slice(0, 3)];
        const mn = mesIdx !== undefined ? mesIdx : Number(mesStr) - 1;
        if (mn < 0 || mn > 11 || d < 1 || d > 31) continue;
        const dt = new Date(a, mn, d);
        if (!Number.isNaN(dt.getTime()) && dt.getFullYear() >= 2010) {
          datas.push(dt);
        }
      }
    }
    return datas;
  }

  function extrairDataInicioCard(card) {
    try {
      const texto = String(card?.innerText || "").replace(/\s+/g, " ");
      const datas = extrairQualquerData(texto);
      if (datas.length) {
        datas.sort((a, b) => a - b);
        return datas[0];
      }
      return null;
    } catch (erro) {
      console.error("MetaSpy: Falha ao extrair data de inicio:", erro);
      return null;
    }
  }

  function extrairDiasAtivoCard(card) {
    try {
      const inicio = extrairDataInicioCard(card);
      if (inicio) {
        const diff = Math.max(0, Math.floor((Date.now() - inicio.getTime()) / 86400000));
        if (diff > 0) return diff;
      }
      const texto = String(card?.innerText || "");
      const diasPatterns = [
        /(?:h[aá]|por|durante|running for|rodando)\s+(\d{1,4})\s+dias?/i,
        /(\d{1,4})\s+dias?\s+(?:em|no ar|rodando|running|ativa|no ar)/i,
        /(\d{1,4})\s+dias?\s*$/im,
        /running\s+for\s+(\d{1,4})\s+days?/i,
        /(?:h[aá]|por|ha|desde)\s+(\d{1,4})\s+(?:dias?|days?)/i
      ];
      for (const pat of diasPatterns) {
        const m = texto.match(pat);
        if (m) return Math.max(1, Number(m[1]));
      }
      return 0;
    } catch (erro) {
      console.error("MetaSpy: Falha ao calcular dias ativos do card:", erro);
      return 0;
    }
  }

  function extrairQuantidadeAnunciosCard(card) {
    try {
      const texto = String(card?.innerText || "");
      const matches = [
        ...texto.matchAll(/(\d{1,4})\s+(?:an[u\u00fa]ncios?|ads?|criativos?|varia[c\u00e7][o\u00f5]es?|vers[o\u00f5]es?|creatives?|versions?)/gi),
        ...texto.matchAll(/(?:an[u\u00fa]ncios?|ads?|criativos?|varia[c\u00e7][o\u00f5]es?|vers[o\u00f5]es?|creatives?|versions?)\s*[:\-]?\s*(\d{1,4})/gi)
      ];
      return matches.reduce((maior, item) => Math.max(maior, Number(item[1] || 0)), 0);
    } catch (erro) {
      console.error("MetaSpy: Falha ao extrair quantidade de anuncios do card:", erro);
      return 0;
    }
  }

  function extrairTextoPrincipalCard(card) {
    const texto = String(card?.innerText || "").replace(/\s+/g, " ").trim();
    return texto.slice(0, 3000);
  }

  function linhasLimpasCard(card) {
    return String(card?.innerText || "")
      .split("\n")
      .map((linha) => linha.replace(/\s+/g, " ").trim())
      .filter(Boolean);
  }

  function linhaEhMetadado(linha = "") {
    return /^(conte[uú]dos de marca|biblioteca de an[uú]ncios|relat[oó]rio|api da biblioteca)$/i.test(linha) ||
      /identifica[cç][aã]o da biblioteca|library id|ad id/i.test(linha) ||
      /come[cç]ou(?:\s+a\s+ser\s+publicado)?|started(?:\s+running)?/i.test(linha) ||
      /veiculad[ao]|veicula[cç][aã]o/i.test(linha) ||
      /^(ativo|active|inativo|inactive|pendente|plataformas?|platforms?|detalhes|ver detalhes|abrir menu|open menu)$/i.test(linha) ||
      /[e]?s?te an[uú]ncio tem v[aá]rias vers[oõ]es|this ad has multiple versions/i.test(linha) ||
      /ver detalhes do an[uú]ncio|see ad details/i.test(linha) ||
      /meta\s*[©\u00a9]\s*\d{4}/i.test(linha) ||
      /portugu[êe]s\s*\(brasil\)/i.test(linha) ||
      /todos\s+os\s+direitos\s+reservados/i.test(linha);
  }

  function limparTextoOferta(texto = "") {
    var limpo = String(texto || "")
      .replace(/Identifica[cç][aã]o(?:\s+da)?\s*biblioteca\s*:?\s*\d*/gi, " ")
      .replace(/Library ID\s*:?\s*\d+/gi, " ")
      .replace(/\bAtivo\b|\bActive\b|\bInativo\b|\bInactive\b|\bPendente\b/gi, " ")
      .replace(/Status\s*:?\s*(?:Ativo|Inativo|Active|Inactive)/gi, " ")
      .replace(/Come[cç]ou(?:\s+a\s+ser\s+publicado)?\s*(?:a|em)?\s*\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4}/gi, " ")
      .replace(/Veiculad[ao]|Veicula[cç][aã]o(?:\s+iniciada)?(?:\s*(?:a|em|:))?\s*\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4}/gi, " ")
      .replace(/Started(?:\s+running)?\s*(?:on)?\s*\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4}/gi, " ")
      .replace(/Plataformas?|Platforms?/gi, " ")
      .replace(/Abrir menu(?: per)?|Open menu|[e]?ste an[uú]ncio(?: tem v[aá]rias vers[oõ]es)?|Esse an[uú]ncio(?: tem v[aá]rias vers[oõ]es)?|This ad(?: has multiple versions)?/gi, " ")
      .replace(/Ver detalhes do an[uú]ncio|See ad details|pendente/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (typeof MetaSpyUtils !== 'undefined' && MetaSpyUtils.filtrarTextoUtil) {
      limpo = MetaSpyUtils.filtrarTextoUtil(limpo);
    }
    return limpo;
  }

  function extrairTituloOfertaCard(card) {
    const linhas = linhasLimpasCard(card)
      .map((linha) => limparTextoOferta(linha))
      .filter((linha) => linha.length >= 6 && linha.length <= 150 && !linhaEhMetadado(linha));
    const ignorar = /conte[u\u00fa]dos de marca|biblioteca de an[u\u00fa]ncios|ad library|relat[o\u00f3]rio|api da biblioteca|identifica[c\u00e7][a\u00e3]o|plataformas?|platforms?|abrir menu|open menu|detalhes|details|status|[e]?s?te an[uú]ncio tem v[aá]rias vers[oõ]es|esse an[uú]ncio|this ad has multiple versions|meta\s*[©\u00a9]\s*\d{4}|portugu[êe]s\s*\(brasil\)/i;
    const encontrada = linhas.find((linha) => !ignorar.test(linha) && /[a-zA-Z\u00c0-\u00ff]{4,}/.test(linha));
    if (encontrada) return encontrada;
    const textoCard = String(card.innerText || "").replace(/\s+/g, " ").trim();
    const limpo = limparTextoOferta(textoCard);
    if (limpo.length >= 6) return limpo.slice(0, 150);
    return "Oferta";
  }

  function extrairAnuncianteCard(card) {
    const linksPagina = card.querySelectorAll("a[href*='facebook.com']");
    for (const linkPagina of linksPagina) {
      if (!/\/ads\/library/i.test(linkPagina.href)) {
        const nomeLink = String(linkPagina.innerText || linkPagina.textContent || "").trim();
        if (nomeLink.length >= 2 && nomeLink.length <= 80 && !linhaEhMetadado(nomeLink)) return nomeLink;
      }
    }
    const imagemPerfil = card.querySelector("img[alt][src], image[alt][src]");
    if (imagemPerfil) {
      const alt = String(imagemPerfil.getAttribute("alt") || "").trim();
      if (alt.length >= 2 && alt.length <= 80) return alt;
    }
    const linhas = linhasLimpasCard(card);
    const ignorar = /conte[u\u00fa]dos de marca|biblioteca de an[u\u00fa]ncios|ad library|relat[o\u00f3]rio|api da biblioteca|id\s*(do|da)?\s*(an[u\u00fa]ncio|biblioteca)?|identifica[c\u00e7][a\u00e3]o|library id|ad id|status|ativo|active|inativo|inactive|come[c\u00e7]ou|started|veiculad[ao]|veicula[c\u00e7][a\u00e3o]o|plataforma|platform|detalhes|details|abrir menu|ver detalhes|[e]?s?te an[uú]ncio tem v[aá]rias vers[oõ]es|esse an[uú]ncio|meta\s*[©\u00a9]\s*\d{4}|portugu[êe]s\s*\(brasil\)/i;
    const candidato = linhas.find((linha) => linha.length >= 2 && linha.length <= 80 && !ignorar.test(linha) && !linhaEhMetadado(linha));
    if (candidato) return candidato;
    return extrairTituloOfertaCard(card) || "Anunciante";
  }

  function extrairDescricaoAnuncioCard(card) {
    const linhas = linhasLimpasCard(card);
    const candidatos = linhas
      .map((linha) => limparTextoOferta(linha))
      .filter((linha) => !linhaEhMetadado(linha))
      .filter((linha) => !/^https?:\/\//i.test(linha))
      .filter((linha) => /[a-zA-Z\u00c0-\u00ff]{6,}/.test(linha) && linha.length >= 10);

    if (candidatos.length) {
      const preferida = candidatos.find((linha) =>
        /curso|pdf|ebook|e-book|guia|aula|treinamento|mentoria|oferta|desconto|aprenda|m[eé]todo|protocolo|suplemento|c[aá]psula|tratamento|app|download|checkout|whatsapp/i.test(linha)
      );
      return (preferida || candidatos.sort((a, b) => b.length - a.length)[0] || "").slice(0, 500);
    }
    const textoCard = String(card.innerText || "").replace(/\s+/g, " ").trim();
    const limpo = limparTextoOferta(textoCard);
    return limpo.length >= 10 ? limpo.slice(0, 500) : textoCard.slice(0, 500);
  }

  function classificarEntregavelTexto(texto = "") {
    const normalizado = normalizarTextoLocal(texto);
    if (/pdf|ebook|e-book|apostila|guia/.test(normalizado)) return "PDF";
    if (/curso|aula|treinamento|formacao|turma|mentoria/.test(normalizado)) return "Curso";
    if (/app|aplicativo|software|sistema/.test(normalizado)) return "App";
    if (/instagram|reels|perfil|seguidores|direct/.test(normalizado)) return "Instagram";
    return "Indefinido";
  }

  function classificarDestinoTexto(texto = "") {
    const normalizado = normalizarTextoLocal(texto);
    if (/wa\.me|whatsapp/.test(normalizado)) return "WhatsApp";
    if (/instagram\.com|instagram/.test(normalizado)) return "Instagram";
    return "Pagina de vendas";
  }

  /* P1: resolve (and cache) the real results container so expensive card-detection
     strategies can be scoped to it instead of re-querying the whole document. */
  function resolverContainerResultados() {
    if (containerResultados && document.contains(containerResultados)) return containerResultados;
    const candidatos = [
      document.querySelector('div[role="feed"]'),
      document.querySelector('div[role="main"]'),
      document.querySelector("main"),
      document.querySelector('[data-pagelet*="AdsLibrary"], [data-pagelet*="AdLibrary"]'),
      document.querySelector("#root")
    ].filter(Boolean);
    let melhor = null;
    for (const el of candidatos) {
      const qtd = el.querySelectorAll('a[href*="ads/library"], a[href*="?id="], [role="article"]').length;
      if (qtd === 0) continue;
      if (!melhor || qtd > melhor._metaspyCards) {
        el._metaspyCards = qtd;
        melhor = el;
      }
    }
    containerResultados = melhor || null;
    return containerResultados;
  }

  const ESTRATEGIAS_DETECCAO = [];

  function montarEstrategiasDetecao() {
    if (ESTRATEGIAS_DETECCAO.length) return;

    function adicionarCard(cards, visitados, card) {
      if (!card || visitados.has(card) || !(card instanceof HTMLElement)) return;
      if (ehChrome(card)) return;
      if (!temSinalDeAnuncio(card)) return;
      const rect = card.getBoundingClientRect();
      if (rect.width < 180 || rect.height < 60) return;
      if (rect.top < -5000 || rect.bottom < -5000) return;
      visitados.add(card);
      cards.push(card);
    }

    function adicionarContainer(cards, visitados, container) {
      if (!container || visitados.has(container)) return;
      adicionarCard(cards, visitados, container);
    }

    /* Sinal real de anuncio: link do card da biblioteca (?id= / ad_archive_id /
       ad_snapshot), conteudo com role="article" ou midia (img/video). O cabecalho,
       barra de busca e rodape NAO possuem esses sinais e deixam de ser "cards". */
    function temSinalDeAnuncio(el) {
      if (!el) return false;
      return !!(
        el.querySelector('a[href*="?id="], a[href*="&id="], a[href*="ad_archive_id"], a[href*="ad_snapshot"], [role="article"]') ||
        el.querySelector("img, video")
      );
    }

    function ehChrome(el) {
      return !!el.closest("header, footer, nav, [role='banner'], [role='navigation'], [role='contentinfo'], [role='search'], [role='dialog'], form, aside");
    }

    function buscarContainer(el, minW = 200, minH = 80) {
      const r = el.getBoundingClientRect();
      if (r.width > minW && r.height > minH) return el;
      for (let i = 0; i < 12; i++) {
        const pai = el.parentElement;
        if (!pai) break;
        if (pai.getBoundingClientRect().width > minW && pai.getBoundingClientRect().height > minH) return pai;
        el = pai;
      }
      return el.parentElement || el;
    }

    function raizBusca() {
      return resolverContainerResultados() || document;
    }

    function query(seletor) {
      return raizBusca().querySelectorAll(seletor);
    }

    ESTRATEGIAS_DETECCAO.push(
      function estrategiaVerDetalhes() {
        const cards = [], visitados = new Set();
        const raiz = raizBusca();
        let nodos = null;
        try {
          nodos = document.evaluate(
            "//text()[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'ver detalhes') or contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'see details')]",
            raiz,
            null,
            XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
            null
          );
        } catch (e) { nodos = null; }
        if (nodos) {
          const vistos = new Set();
          for (let i = 0; i < nodos.snapshotLength; i++) {
            const no = nodos.snapshotItem(i);
            const pai = no.nodeType === 3 ? no.parentElement : no;
            if (vistos.has(pai)) continue;
            vistos.add(pai);
            let c = pai;
            for (let j = 0; j < 10 && c; j++) {
              const r = c.getBoundingClientRect();
              if (r.width > 300 && r.height > 100) { adicionarContainer(cards, visitados, c); break; }
              c = c.parentElement;
            }
          }
        }
        return cards;
      },

      function estrategiaLinksAds() {
        const cards = [], visitados = new Set();
        query("a[href*='ads/library'], a[href*='ad_archive'], a[href*='ad_snapshot'], a[href*='/ads/'], a[href*='/ads/library/report'], a[href*='?id='], a[href*='&id='], a[data-href*='id='], a[href*='id=']")
          .forEach((el) => adicionarContainer(cards, visitados, buscarContainer(el)));
        return cards;
      },

      function estrategiaRoleLink() {
        const cards = [], visitados = new Set();
        const els = query('[role="link"]:not(a)');
        for (const el of els) {
          if (el.closest("header, footer, nav, [role='banner']")) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 200 || r.height < 100) continue;
          if (el.querySelector('a[href*="id="], a[href*="?id="]')) continue;
          const txt = ((el.innerText || "") + " " + (el.textContent || "")).trim();
          const links = el.querySelectorAll("a");
          const imgs = el.querySelectorAll("img");
          if (imgs.length > 1 && links.length > 0 && txt.length > 120) adicionarCard(cards, visitados, el);
        }
        return cards;
      },

      function estrategiaTextoAd() {
        const cards = [], visitados = new Set();
        const padraoAd = /Status\s*:?\s*(Ativo|Inativo|Active|Inactive)|Come[cç]ou\s+a\s+ser\s+publicado|Started running|dias\s*restantes|impress[oõ]es|alcance|or[cç]amento|p[uú]blico[- ]alvo/i;
        const candidatos = query("div, section, article");
        for (const el of candidatos) {
          if (el.closest("header, footer, nav, [role='banner'], [role='navigation'], [role='contentinfo']")) continue;
          const txt = (el.innerText || "").trim();
          if (txt.length < 120) continue;
          if (!padraoAd.test(txt)) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 220 || r.height < 100) continue;
          if (el.querySelector('img') || el.querySelector('a')) adicionarCard(cards, visitados, el);
        }
        return cards;
      },

      function estrategiaFallback() {
        const cards = [], visitados = new Set();
        const chromeTags = "header, footer, nav, [role='banner'], [role='navigation'], [role='contentinfo']";
        const candidatos = query("div, section, article");
        for (const el of candidatos) {
          if (el.closest(chromeTags)) continue;
          const txt = (el.innerText || "").trim();
          if (txt.length < 100) continue;
          if (!el.querySelector('a[href*="id="], a[href*="?id="]')) continue;
          if (!el.querySelector('img')) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 250 || r.height < 100) continue;
          adicionarCard(cards, visitados, el);
        }
        return cards;
      }
    );
  }

  function coletarCardsVisiveis() {
    montarEstrategiasDetecao();

    /* Fast path: cached winning strategy (P1) — skip the 5 fallbacks on every tick. */
    if (estrategiaCardsCache) {
      const cards = estrategiaCardsCache();
      if (cards.length > 0) return cards;
      estrategiaCardsCache = null; /* page may have navigated → re-detect once */
    }

    let melhor = [];
    for (const estrategia of ESTRATEGIAS_DETECCAO) {
      const cards = estrategia();
      if (cards.length > melhor.length) melhor = cards;
      if (cards.length >= 3) {
        estrategiaCardsCache = estrategia;
        return cards;
      }
    }
    return melhor;
  }

  /* Meta embrulha o link do CTA em um redirecionador proprio:
     https://l.facebook.com/l.php?u=<url-encoded>&h=<hash>.
     Desembrulha e devolve o destino real. */
  function decodificarLinkFacebook(href) {
    try {
      const bruto = String(href || "").trim();
      if (!bruto) return "";
      const url = new URL(bruto);
      const host = url.hostname.replace(/^www\./i, "").toLowerCase();
      if (!/^(l|lm)\.facebook\.com$/i.test(host)) return bruto;
      if (!/\/l\.php$/i.test(url.pathname)) return bruto;
      let destino = url.searchParams.get("u") || "";
      for (let i = 0; i < 2; i++) {
        try {
          const proximo = decodeURIComponent(destino);
          if (proximo === destino) break;
          destino = proximo;
        } catch (e) { break; }
      }
      return destino.trim() || bruto;
    } catch (e) {
      return "";
    }
  }

  function ehLinkWhatsApp(url) {
    const alvo = normalizarTextoLocal(String(url || ""));
    if (!alvo) return false;
    if (alvo.indexOf("whatsapp:") === 0) return true;
    return /(?:^|[@./])(?:api\.|web\.|chat\.|next\.|business\.)?whatsapp\.com/.test(alvo) ||
           /(?:^|[@./])wa\.me(?:$|[/?#])/.test(alvo);
  }

  /* A Biblioteca, por padrao, NAO expoe o destino real do CTA: no lugar do
     link de saida ela coloca o link do perfil do anunciante (facebook.com/...)
     ou um botao sem href. Por isso "facebook.com" aqui e descartado como
     destino — ele nunca e o link da oferta. */
  function ehLinkInternoFacebook(url) {
    try {
      const u = new URL(String(url));
      const host = u.hostname.replace(/^www\./i, "").toLowerCase();
      if (!/(^|\.)(facebook|fb|meta)\.com$/i.test(host)) return false;
      if (/^(l|lm)\.facebook\.com$/i.test(host)) return false;
      if (/\/[a-zA-Z0-9._-]+\/(posts|videos|photos|reels)\//i.test(u.pathname)) return false;
      return true;
    } catch (e) {
      return false;
    }
  }

  /* O CTA do Facebook e um <div role="button">/span, nao um <a href>. O
     destino real fica nos props do React do no. */
  function ehRotuloCta(texto = "") {
    const t = normalizarTextoLocal(String(texto || ""));
    if (!t || t.length > 40) return false;
    return /^(saiba mais|learn more|enviar mensagem|send message|fale conosco|conversar|converse|conversa|conversar agora|converse agora|falar agora|falar com|chame no|entrar|entrar agora|instalar|instalar agora|comprar|comprar agora|pedido|order now|shop now|signup|sign up|enviar|contato|contato agora|whatsapp)/.test(t);
  }

  function acharNoCtaDoCard(card) {
    try {
      const seletor = "a[href], [role='button'], [role='link'], button, [tabindex]";
      for (const el of card.querySelectorAll(seletor)) {
        if (!(el instanceof HTMLElement)) continue;
        const txt = el.innerText || el.textContent || "";
        if (ehRotuloCta(txt)) return el;
      }
    } catch (e) { /* ignore */ }
    return null;
  }

  const CHAVES_URL_PROPS = [
    "href", "url", "link_url", "linkUrl", "link", "cta_link", "ctaLink",
    "cta_link_url", "redirect_url", "redirectUrl", "outbound_url",
    "outboundUrl", "external_url", "externalUrl", "destination_url",
    "destinationUrl", "website", "website_url"
  ];

  function urlAceitavelDoProps(valor) {
    if (typeof valor !== "string" || !valor) return "";
    const alvo = valor.trim();
    if (!/^(https?:\/\/|whatsapp:)/i.test(alvo)) return "";
    const resolvido = decodificarLinkFacebook(alvo);
    if (!resolvido || !/^(https?:\/\/|whatsapp:)/i.test(resolvido)) return "";
    if (ehLinkWhatsApp(resolvido)) return resolvido;
    if (ehLinkInternoFacebook(resolvido)) return "";
    return resolvido;
  }

  function buscarUrlEmProps(objeto, profundidade, vistos) {
    if (!objeto || typeof objeto !== "object" || profundidade > 4 || vistos.has(objeto)) return "";
    try {
      vistos.add(objeto);
      if (Array.isArray(objeto)) {
        for (const item of objeto) {
          const achado = buscarUrlEmProps(item, profundidade + 1, vistos);
          if (achado) return achado;
        }
        return "";
      }
      for (const chave of CHAVES_URL_PROPS) {
        const achado = urlAceitavelDoProps(objeto[chave]);
        if (achado) return achado;
      }
      for (const chave of ["memoizedProps", "pendingProps", "stateNode", "child", "sibling", "return", "a", "next", "element"]) {
        const filho = objeto[chave];
        if (filho && typeof filho === "object") {
          const achado = buscarUrlEmProps(filho, profundidade + 1, vistos);
          if (achado) return achado;
        }
      }
    } catch (e) { /* ignore */ }
    return "";
  }

  function extrairUrlDasPropsReact(el) {
    if (!el) return "";
    try {
      for (const chave of Object.keys(el)) {
        if (!/^__react(Props|Fiber|InternalInstance)/.test(chave)) continue;
        const achado = buscarUrlEmProps(el[chave], 0, new Set());
        if (achado) return achado;
      }
    } catch (e) { /* ignore */ }
    return "";
  }

  function extrairLPhpDoHtml(card) {
    try {
      const html = card.innerHTML || "";
      const m = html.match(/l\.php\?u=([^"'\\\s<>]+)/);
      if (!m) return "";
      const alvo = m[1].replace(/&amp;/g, "&");
      const bruto = "https://l.facebook.com/l.php?u=" + alvo;
      const resolvido = decodificarLinkFacebook(bruto);
      if (ehLinkWhatsApp(resolvido)) return resolvido;
      return ehLinkInternoFacebook(resolvido) ? "" : resolvido;
    } catch (e) {
      return "";
    }
  }

  /* Link de destino da oferta. Prioriza WhatsApp e nunca devolve o perfil
     do anunciante (que e o que o Facebook coloca no lugar do CTA bloqueado). */
  function extrairLinkOfertaCard(card) {
    try {
      let externo = "";
      for (const link of card.querySelectorAll("a[href]")) {
        const bruto = String(link.href || link.getAttribute("href") || "").trim();
        if (!bruto || !/^https?:\/\//i.test(bruto)) continue;
        const resolvido = decodificarLinkFacebook(bruto);
        if (!resolvido || !/^https?:\/\//i.test(resolvido)) continue;
        if (ehLinkWhatsApp(resolvido)) return resolvido;
        if (!externo && !ehLinkInternoFacebook(resolvido)) externo = resolvido;
      }
      if (externo) return externo;

      const noCta = acharNoCtaDoCard(card);
      if (noCta) {
        const doProps = extrairUrlDasPropsReact(noCta);
        if (doProps) return doProps;
      }
      const doHtml = extrairLPhpDoHtml(card);
      if (doHtml) return doHtml;
      const doCard = extrairUrlDasPropsReact(card);
      if (doCard) return doCard;
    } catch (e) { /* ignore */ }
    return "";
  }

  /* ─── RECUPERACAO DO LINK VIA O DIALOGO "SOBRE ESTE ANUNCIO" ───
     Ultimo recurso: o destino que a Biblioteca esconde so aparece dentro do
     dialogo de detalhes, que e a propria UI do Facebook (clicavel com login).
     Limitado para nao hammering: 1 a cada 2s, no maximo 20 por sessao. */

  const INTERVALO_MODAL_MS = 2000;
  const MAX_MODAL_SESSAO = 20;
  const estadoModal = { ultimoEm: 0, total: 0 };

  function clicarNoDetalheDoCard(card) {
    const rotulos = /(sobre este an[uú]ncio|this ad|ver detalhes do an[uú]ncio|see ad details|see details|ver detalhes|see more about this ad)/i;
    try {
      for (const el of card.querySelectorAll("a, button, [role='button'], [role='link'], span")) {
        if (!(el instanceof HTMLElement)) continue;
        const txt = normalizarTextoLocal(el.innerText || el.textContent || "");
        if (!txt || txt.length > 45) continue;
        if (rotulos.test(txt)) {
          el.click();
          return true;
        }
      }
    } catch (e) { /* ignore */ }
    return false;
  }

  function extrairLinkDoDialogo(dialogo) {
    try {
      let externo = "";
      for (const a of dialogo.querySelectorAll("a[href]")) {
        const bruto = String(a.href || a.getAttribute("href") || "").trim();
        if (!bruto) continue;
        const resolvido = decodificarLinkFacebook(bruto);
        if (!resolvido || !/^(https?:\/\/|whatsapp:)/i.test(resolvido)) continue;
        if (ehLinkWhatsApp(resolvido)) return resolvido;
        if (!externo && !ehLinkInternoFacebook(resolvido)) externo = resolvido;
      }
      const m = (dialogo.innerHTML || "").match(/l\.php\?u=([^"'\\\s<>]+)/);
      if (m) {
        const resolvido = decodificarLinkFacebook(
          "https://l.facebook.com/l.php?u=" + m[1].replace(/&amp;/g, "&")
        );
        if (ehLinkWhatsApp(resolvido)) return resolvido;
        if (resolvido && !ehLinkInternoFacebook(resolvido)) return resolvido;
      }
      return externo;
    } catch (e) {
      return "";
    }
  }

  function fecharDialogo() {
    try {
      const btn = document.querySelector(
        "[role='dialog'] [aria-label*='Fechar' i], [role='dialog'] [aria-label*='Close' i]," +
        "[role='dialog'] [aria-label*='Cancelar' i], [role='dialog'] div[role='button'][aria-label]"
      );
      if (btn) btn.click();
      else document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
    } catch (e) { /* ignore */ }
  }

  async function recuperarLinkViaDialogo(card) {
    const agora = Date.now();
    if (estadoModal.total >= MAX_MODAL_SESSAO) {
      return { url: "", erro: "limite de recuperacoes por sessao atingido" };
    }
    if (agora - estadoModal.ultimoEm < INTERVALO_MODAL_MS) {
      return { url: "", erro: "aguardando o intervalo entre recuperacoes" };
    }
    estadoModal.ultimoEm = agora;
    estadoModal.total++;

    if (!clicarNoDetalheDoCard(card)) {
      return { url: "", erro: "botao de detalhes nao encontrado no card" };
    }
    const inicio = Date.now();
    let url = "";
    try {
      while (Date.now() - inicio < 6000) {
        const dialogos = document.querySelectorAll("[role='dialog'], div[aria-label*='Sobre este an' i]");
        for (const d of dialogos) {
          url = extrairLinkDoDialogo(d);
          if (url) break;
        }
        if (url) break;
        await aguardar(250);
      }
    } finally {
      fecharDialogo();
    }
    return url ? { url, erro: "" } : { url: "", erro: "o dialogo nao revelou nenhum link de destino" };
  }

  function extrairUrlDestinoCard(card) {
    try {
      const links = card.querySelectorAll("a[href]");
      for (const link of links) {
        const href = (link.href || "").trim();
        if (!href || !/^https?:\/\//i.test(href)) continue;
        const urlObj = new URL(href);
        const host = urlObj.hostname.replace(/^www\./, "");
        if (/facebook\.com|fb\.com|meta\.com/i.test(host)) {
          if (/ads\/library|ad_archive|ad_snapshot|sharer|sharer\.php|login|plugins/i.test(href)) continue;
          if (/\/pg\/|\/profile\.php|\/people\//i.test(href)) continue;
          if (/^\/(?:[^/]+\/)?(?:photos|videos|posts|reels|stories|watch|events|groups|marketplace)/i.test(urlObj.pathname)) continue;
          if (/l\.facebook|lm\.facebook|go\.facebook/i.test(host)) return href;
          if (urlObj.pathname.match(/\/[a-zA-Z0-9._-]+\/posts\/|\/[a-zA-Z0-9._-]+\/videos\/|\/[a-zA-Z0-9._-]+\/photos\//)) return href;
          continue;
        }
        if (/google|youtube|twitter|x\.com|linkedin|instagram|pinterest|tiktok/i.test(host)) continue;
        return href;
      }
      for (const link of links) {
        const href = (link.href || "").trim();
        if (!href || !/^https?:\/\//i.test(href)) continue;
        const urlObj = new URL(href);
        const host = urlObj.hostname.replace(/^www\./, "");
        if (/facebook\.com|fb\.com/i.test(host) && !/ads\/library|ad_archive/i.test(href)) {
          if (urlObj.pathname.match(/\/[a-zA-Z0-9._-]+(?:\/posts\/|\/videos\/|\/photos\/)/) || /l\.facebook/i.test(host)) return href;
        }
      }
    } catch (e) {}
    return "";
  }

  function extrairVideoCard(card) {
    try {
      const videoEl = card.querySelector("video");
      if (videoEl) {
        const url = extrairUrlVideo(videoEl);
        if (url) return url;
      }
      const sourceEl = card.querySelector("video source[src], source[src*='.mp4'], source[src*='fbcdn']");
      if (sourceEl) {
        const url = sourceEl.src || sourceEl.getAttribute("src");
        if (url && urlVideoValida(url)) return url;
      }
      const links = card.querySelectorAll("a[href*='.mp4'], a[href*='fbcdn'], a[href*='video.fb']");
      for (const link of links) {
        const url = link.href || link.getAttribute("href");
        if (url && urlVideoValida(url)) return url;
      }
      const allEls = card.querySelectorAll("[data-video], [data-video-source], [data-src*='.mp4'], [data-url*='fbcdn']");
      for (const el of allEls) {
        const url = el.getAttribute("data-video") || el.getAttribute("data-video-source") || el.getAttribute("data-src") || el.getAttribute("data-url");
        if (url && urlVideoValida(url)) return url;
      }
      const html = card.innerHTML || "";
      const videoUrlMatch = html.match(/(https?:\/\/[^"'\s]+fbcdn[^"'\s]*\.mp4[^"'\s]*)/);
      if (videoUrlMatch && urlVideoValida(videoUrlMatch[1])) return videoUrlMatch[1];
      return null;
    } catch (e) { return null; }
  }

  function extrairThumbnailCard(card) {
    const img = card.querySelector("img");
    if (img) {
      return img.currentSrc || img.src || img.getAttribute("data-src") || img.getAttribute("data-lazy-src") || img.getAttribute("data-original-src") || "";
    }
    const source = card.querySelector("picture source[srcset], source[srcset]");
    if (source) {
      const srcset = source.getAttribute("srcset") || "";
      const firstSrc = srcset.split(",")[0]?.trim().split(" ")[0] || "";
      if (firstSrc) return firstSrc;
    }
    const svgImg = card.querySelector("image");
    if (svgImg) {
      return svgImg.getAttribute("href") || svgImg.getAttribute("xlink:href") || "";
    }
    const elsComBg = card.querySelectorAll("[style*='background-image'], [style*='background']");
    for (const el of elsComBg) {
      const style = el.getAttribute("style") || "";
      const m = style.match(/background(?:-image)?\s*:\s*url\(['"]?([^'"]+)['"]?\)/i);
      if (m) return m[1];
    }
    const cardStyle = card.getAttribute("style") || "";
    const mCard = cardStyle.match(/background(?:-image)?\s*:\s*url\(['"]?([^'"]+)['"]?\)/i);
    if (mCard) return mCard[1];
    return "";
  }

  function coletarAnunciosVisiveis(termo = "") {
    const termoNormalizado = normalizarTextoLocal(termo);
    const anuncios = [];
    const ids = new Set();
    coletarCardsVisiveis().forEach((card, indice) => {
      try {
      const textoCompleto = extrairTextoPrincipalCard(card);
      if (indice < 5) console.log(`[MetaSpy] Card ${indice} texto:`, textoCompleto.slice(0, 300));

      const idExtraido = extrairIdDoElemento(card);
      const textoLimpo = limparTextoOferta(textoCompleto);
      const idAnuncio = idExtraido || `dom-${indice}-${normalizarTextoLocal(textoLimpo).slice(0, 24) || indice}`;
      if (ids.has(idAnuncio)) return;
      ids.add(idAnuncio);

      const dataInicio = extrairDataInicioCard(card);
      const dataFim = extrairDataFimCard(card);
      const ativo = (window.cardPareceAtivo || cardPareceAtivo)(card) && !(dataFim && dataFim.getTime() < Date.now());
      const diasAtivo = extrairDiasAtivoCard(card);
      if (indice < 5) console.log(`[MetaSpy] Card ${indice} diasAtivo:`, diasAtivo, `dataInicio:`, dataInicio);
      const quantidadeAnuncios = extrairQuantidadeAnunciosCard(card);
      const thumb = extrairThumbnailCard(card);
      const videoUrl = extrairVideoCard(card);
      const midias = [];
      if (thumb) midias.push({ url: thumb, tipo: "imagem" });
      if (videoUrl) midias.push({ url: videoUrl, tipo: "video" });
      const anunciante = extrairAnuncianteCard(card);
      const descricao = extrairDescricaoAnuncioCard(card);
const linkOferta = extrairLinkOfertaCard(card);
  let urlDestino = linkOferta || decodificarLinkFacebook(extrairUrlDestinoCard(card)) || "";
  /* O perfil do anunciante nao e o destino da oferta: sem destino real o
     anuncio fica sem badge, em vez de aparecer como "Pg. Vendas". */
  if (urlDestino && ehLinkInternoFacebook(urlDestino)) urlDestino = "";
  const destinoWhatsApp = ehLinkWhatsApp(urlDestino);

      if (indice < 5) console.log(`[MetaSpy] Card ${indice}: anunciante="${anunciante}" descricao="${descricao.slice(0, 80)}" urlDestino="${urlDestino.slice(0, 120)}" whatsapp=${destinoWhatsApp}`);
      anuncios.push({
        idAnuncio,
        anunciante,
        tituloOferta: anunciante,
        texto: (descricao || limparTextoOferta(textoCompleto)).slice(0, 280),
        textoCompleto: descricao || limparTextoOferta(textoCompleto) || textoCompleto,
        midias,
        dataInicioISO: dataInicio ? dataInicio.toISOString() : null,
        dataFimISO: dataFim ? dataFim.toISOString() : null,
        dataUltimaAtualizacaoISO: dataFim ? dataFim.toISOString() : dataInicio ? dataInicio.toISOString() : null,
        plataformas: [],
        urlDestino,
        destinoWhatsApp,
        urlBiblioteca: idExtraido ? `https://www.facebook.com/ads/library/?id=${idExtraido}` : location.href,
        cta: "",
        adActiveStatus: ativo ? "ACTIVE" : "INACTIVE",
        statusTexto: ativo ? "Ativo" : "Inativo",
        ativo,
        diasAtivo,
        spendMax: 0,
        impressionsMax: 0,
        audienceMax: 0,
        variacoesAtivasEstimadas: Math.max(1, quantidadeAnuncios || 1),
        variacoesAtivas: Math.max(1, quantidadeAnuncios || 1),
        quantidadeCopiasIguais: Math.max(1, quantidadeAnuncios || 1),
        consistenciaTemporal: ativo ? 100 : 40,
        engajamentoEstimado: 0,
        scoreEscala: 0,
        statusEscala: "TESTANDO",
        evergreen: diasAtivo > 90,
        entregavel: classificarEntregavelTexto(textoCompleto),
        destino: destinoWhatsApp ? "WhatsApp" : classificarDestinoTexto(textoCompleto),
        origem: "biblioteca"
      });

      /* F3: per-card shortcuts on every scanned/visible card (not only highlighted). */
      injetarAcoesCard(card, anuncios[anuncios.length - 1]);
      } catch (erroCard) {
        console.error("[MetaSpy] Erro ao extrair card " + indice + ":", erroCard);
      }
    });
    console.log(`[MetaSpy] Extraidos ${anuncios.length} anuncio(s) da pagina.`);
    return anuncios;
  }

  /* F2b: devolve os anuncios completos dos cards atualmente destacados
     (.metaspy-neon) para que o widget compartilhe os mesmos resultados
     com o painel lateral (storage/background). */
  function coletarAnunciosDestacados() {
    const idsNeon = new Set();
    document.querySelectorAll(".metaspy-neon").forEach((card) => {
      try {
        const id = extrairIdDoElemento(card);
        if (id) idsNeon.add(id);
      } catch (e) { /* ignore */ }
    });
    if (!idsNeon.size) return [];
    let anuncios = [];
    try {
      anuncios = coletarAnunciosVisiveis("");
    } catch (e) { return []; }
    return anuncios.filter((a) => idsNeon.has(a.idAnuncio));
  }

  /* F2c: aprofundamento em lotes — quando a passada de scrolls estagna, tenta
     avancar para o proximo lote de resultados ("Ver mais"/"Carregar mais") e
     repete a passada, respeitando o prazo configurado. */
  function clicarProximoLote() {
    if (!document.body) return false;
    const alvos = [];
    const raiz = containerResultados || document.body;
    try {
      raiz.querySelectorAll("a, button, [role='button'], [role='link']").forEach((el) => {
        if (!(el instanceof HTMLElement)) return;
        const texto = normalizarTextoLocal(el.innerText || el.textContent || "");
        if (!texto || texto.length > 60) return;
        if (/(ver mais|see more|carregar mais|load more|show more)/i.test(texto)) {
          alvos.push(el);
        }
      });
    } catch (e) { /* ignore */ }
    if (alvos.length === 0) return false;
    /* Prefere o elemento mais ao fundo da lista. */
    alvos.sort((a, b) => {
      const ta = a.getBoundingClientRect().top;
      const tb = b.getBoundingClientRect().top;
      return ta === tb ? 0 : (ta < tb ? -1 : 1);
    });
    const alvo = alvos[alvos.length - 1];
    try {
      alvo.scrollIntoView({ block: "center", behavior: "auto" });
      alvo.click();
      return true;
    } catch (e) {
      return false;
    }
  }

  async function varrerBibliotecaCompleta(termo = "", tempoMaximoMs = 0) {
    estado.parar = false;
    const agregados = new Map();
    const idsJaEnviados = new Set();
    let contadorLote = 0;
    let msgBuffer = [];
    const INICIO_MS = Date.now();
    inicioVarreduraMs = INICIO_MS;

    /* F2c: prazo total da varredura. Por padrao mantem o limite legado
       (TIMEOUT_VARREDURA_MS); quando um tempoMaximoMs >= 30s e informado, vira
       o novo teto de tempo (modo aprofundado). */
    const prazoMs = tempoMaximoMs && tempoMaximoMs >= 30000 ? tempoMaximoMs : TIMEOUT_VARREDURA_MS;
    const dentroDoPrazo = () => Date.now() - INICIO_MS < prazoMs;

    function flushMessages() {
      if (msgBuffer.length === 0) return;
      const batch = msgBuffer.splice(0);
      contadorLote++;
      chrome.runtime.sendMessage({
        tipo: "loteVarreduraBiblioteca",
        anuncios: batch,
        pagina: contadorLote
      }).catch(() => {});
    }

    const coletarComPatch = (termoAtual) =>
      (window.coletarAnunciosVisiveis || coletarAnunciosVisiveis)(termoAtual);

    resolverContainerResultados();
    const container = containerResultados || document;

    /* F2c: multiplas passadas de scroll — uma por lote de resultados. */
    let paginas = 0;
    while (!estado.parar && dentroDoPrazo()) {
      paginas++;
      let alturaAnterior = 0;
      let scrollAtual = 0;
      let scrollsSemCards = 0;
      let atrasoAtual = PAUSA_ROLAGEM_INICIAL_MS;
      let ciclosSemNovosCards = 0;
      let ciclosSemNovidade = 0;

      /* Espera inicial pelas primeiras cards (reduzida para ~7s max). */
      for (let w = 0; w < 10; w++) {
        if (coletarCardsVisiveis().length > 0) break;
        await aguardar(700);
      }

      const processarEstado = () => {
        const novaAltura = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
        coletarComPatch(termo).forEach((a) => agregados.set(a.idAnuncio, a));

        if (agregados.size === 0) {
          scrollsSemCards++;
        } else {
          scrollsSemCards = 0;
        }

        const novos = [];
        agregados.forEach((a, id) => {
          if (!idsJaEnviados.has(id)) {
            novos.push(a);
            idsJaEnviados.add(id);
          }
        });

        if (novos.length > 0) {
          ciclosSemNovosCards = 0;
          msgBuffer.push(...novos);
          if (msgBuffer.length >= LOTE_ANUNCIOS_POR_ENVIO) flushMessages();
        } else {
          ciclosSemNovosCards++;
        }

        ciclosSemNovidade = novaAltura <= alturaAnterior && novos.length === 0 ? ciclosSemNovidade + 1 : 0;
        alturaAnterior = novaAltura;
        return novos.length;
      };

      /* P1: MutationObserver scoped to the results container (not document.body),
         debounced, purely as an early-wake signal for the polling loop. */
      let observer = null;
      let observerTerminou = false;
      let timerReage = null;
      try {
        observer = new MutationObserver(() => {
          if (observerTerminou || timerReage) return;
          timerReage = setTimeout(() => {
            timerReage = null;
            if (observerTerminou) return;
            processarEstado();
            if (
              ciclosSemNovosCards >= CICLOS_SEM_NOVOS_CARDS_SAIDA ||
              ciclosSemNovidade >= CICLOS_SEM_NOVIDADE_SAIDA ||
              !dentroDoPrazo()
            ) {
              observerTerminou = true;
            }
          }, 300);
        });
        observer.observe(container, { childList: true, subtree: true });
      } catch (e) {
        observer = null;
      }

      for (let i = 0; i < LIMITE_ROLAGENS_VARREDURA; i++) {
        if (estado.parar) break;
        if (observerTerminou) break;
        if (!dentroDoPrazo()) break;
        if (ciclosSemNovosCards >= CICLOS_SEM_NOVOS_CARDS_SAIDA || ciclosSemNovidade >= CICLOS_SEM_NOVIDADE_SAIDA) break;

        const alturaTotal = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
        scrollAtual = window.scrollY;
        const proximoScroll = Math.min(scrollAtual + INCREMENTO_SCROLL_PX, alturaTotal);

        if (proximoScroll > scrollAtual) {
          window.scrollTo({ top: proximoScroll, behavior: "auto" });
        } else {
          window.scrollTo({ top: alturaTotal, behavior: "auto" });
        }

        await aguardar(atrasoAtual);

        const novosCount = processarEstado();

        if (scrollsSemCards >= 8) {
          console.log("[MetaSpy] Nenhum card encontrado apos 8 scrolls nesta passada.");
          break;
        }

        /* P1: adaptive delay — speed up while cards keep appearing, back off otherwise. */
        if (novosCount > 0) {
          atrasoAtual = Math.max(PAUSA_ROLAGEM_INICIAL_MS, atrasoAtual - 100);
        } else {
          atrasoAtual = Math.min(PAUSA_ROLAGEM_MAX_MS, atrasoAtual + 300);
        }

        if (i % 2 === 0) {
          chrome.runtime.sendMessage({ tipo: "heartbeatVarredura", ciclo: i, total: agregados.size }).catch(() => {});
        }
      }

      observerTerminou = true;
      if (observer) { try { observer.disconnect(); } catch (e) {} }
      flushMessages();

      /* F2c: fim de passada — avanca para o proximo lote de resultados se ainda
         sobrar tempo suficiente (margem BUFFER_PROXIMO_LOTE_MS) e existir
         botao "Ver mais". */
      if (estado.parar || !dentroDoPrazo()) break;
      if (Date.now() - INICIO_MS > prazoMs - BUFFER_PROXIMO_LOTE_MS) break;
      if (!clicarProximoLote()) break;
      await aguardar(1200);
    }

    /* P7: timing instrumentation for the scan phase. */
    const duracaoMs = Date.now() - INICIO_MS;
    chrome.runtime.sendMessage({
      tipo: "varreduraFinalizada",
      duracaoMs,
      total: agregados.size,
      paginas
    }).catch(() => {});

    return [...agregados.values()];
  }
  function encontrarContainerCard(elementoInterno) {
    try {
      if (!elementoInterno || !(elementoInterno instanceof HTMLElement)) return null;

      const container = elementoInterno.closest("div[role='article'], article, [data-pagelet]");
      if (container) {
        return container;
      }

      let atual = elementoInterno.parentElement;
      for (let i = 0; i < 8 && atual; i++) {
        const rect = atual.getBoundingClientRect();
        if (rect.width > 220 && rect.height > 120) {
          if (atual.querySelector('a[href*="ads/library/?id="], a[href*="id="]')) {
            return atual;
          }
        }
        atual = atual.parentElement;
      }

      return null;
    } catch (erro) {
      console.error("MetaSpy: Falha ao encontrar container do card:", erro);
      return null;
    }
  }

  /* ─── F3: ATALHOS POR CARD (favoritar / baixar / vendas / biblioteca) ── */

  function injetarAcoesCard(card, anuncio) {
    try {
      if (!card || !(card instanceof HTMLElement)) return;
      if (card.querySelector(".metaspy-card-actions")) return;
      card.dataset.metaspyAcoes = "1";
      card.style.position = card.style.position || "relative";

      const actions = document.createElement("div");
      actions.className = "metaspy-card-actions";

      const criarBtn = (rotulo, classe, fn) => {
        const btn = document.createElement("button");
        if (classe) btn.className = classe;
        btn.textContent = rotulo;
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          e.preventDefault();
          fn();
        });
        return btn;
      };

      const idCard = extrairIdDoElemento(card);

      actions.appendChild(criarBtn("Favoritar", "", () => {
        const mini = anuncio || {
          idAnuncio: idCard || `dom-${Date.now()}`,
          anunciante: extrairAnuncianteCard(card),
          texto: extrairDescricaoAnuncioCard(card).slice(0, 280),
          textoCompleto: extrairDescricaoAnuncioCard(card),
          midias: [],
          urlBiblioteca: idCard ? `https://www.facebook.com/ads/library/?id=${idCard}` : location.href,
          origem: "biblioteca"
        };
        chrome.runtime.sendMessage({ acao: "salvarFavorito", anuncio: mini }).catch(() => {});
        btn.textContent = "Favoritado ✓";
        setTimeout(() => { btn.textContent = "Favoritar"; }, 1500);
      }));

      const urlDestCard = extrairLinkOfertaCard(card);
      if (ehLinkWhatsApp(urlDestCard)) {
        actions.appendChild(criarBtn("Abrir WhatsApp", "ms-zap", () => window.open(urlDestCard, "_blank")));
      } else if (urlDestCard) {
        actions.appendChild(criarBtn("Abrir oferta", "", () => window.open(urlDestCard, "_blank")));
      } else {
        /* A Biblioteca escondeu o destino: recupera pelo dialogo de detalhes. */
        const btnRec = criarBtn("🔗 Recuperar link", "ms-rec", async () => {
          btnRec.disabled = true;
          btnRec.textContent = "Recuperando...";
          const r = await recuperarLinkViaDialogo(card);
          if (r.url) {
            const zap = ehLinkWhatsApp(r.url);
            btnRec.className = zap ? "ms-zap" : "";
            btnRec.textContent = zap ? "Abrir WhatsApp" : "Abrir oferta";
            btnRec.disabled = false;
            btnRec.onclick = () => window.open(r.url, "_blank");
            if (anuncio) {
              anuncio.urlDestino = r.url;
              anuncio.destinoWhatsApp = zap;
              anuncio.destino = zap ? "WhatsApp" : (anuncio.destino || "Página de vendas");
            }
          } else {
            btnRec.disabled = false;
            btnRec.textContent = "🔗 Recuperar link";
            console.warn("[MetaSpy] Recuperacao falhou:", r.erro);
          }
        });
        actions.appendChild(btnRec);
      }

      const vUrlCard = extrairVideoCard(card);
      const imgCard = card.querySelector("img");
      if (vUrlCard || imgCard) {
        actions.appendChild(criarBtn(vUrlCard ? "Baixar vídeo" : "Baixar imagem", "ms-dl", () => {
          const adId = idCard || location.href.match(/[?&]id=(\d+)/)?.[1] || "card";
          if (vUrlCard) {
            baixarVideoComoBlob(vUrlCard, `metaspy_video_${adId}_${Date.now()}.mp4`).catch(() => {});
          } else if (imgCard) {
            const iUrl = imgCard.currentSrc || imgCard.src || imgCard.getAttribute("data-src") || "";
            if (iUrl) {
              const a = document.createElement("a");
              a.href = iUrl;
              a.download = `metaspy_img_${adId}.jpg`;
              a.style.display = "none";
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
            }
          }
        }));
      }

      if (idCard) {
        actions.appendChild(criarBtn("Abrir", "", () => {
          window.open(`https://www.facebook.com/ads/library/?id=${idCard}`, "_blank");
        }));
      }

      if (actions.childNodes.length) card.appendChild(actions);
    } catch (e) { /* ignore */ }
  }

  function limparDestaques() {
    document.querySelectorAll(".metaspy-neon").forEach((el) => {
      el.classList.remove("metaspy-neon");
      el.style.position = "";
      el.style.zIndex = "";
      el.style.outline = "";
      el.style.boxShadow = "";
    });
    document.querySelectorAll(".metaspy-card-actions").forEach((el) => el.remove());
    const overlay = document.getElementById(METASPY_OVERLAY_ID);
    if (overlay) overlay.remove();
    if (window.__metaspyAneis) window.__metaspyAneis = new WeakMap();
  }

  function cardPassaFiltros(card, diasMin = 100, copiasMin = 5) {
    try {
      const diasAtivo = extrairDiasAtivoCard(card);
      const quantAnuncios = extrairQuantidadeAnunciosCard(card);
      if (diasAtivo >= diasMin) return true;
      if (quantAnuncios >= copiasMin) return true;
      return false;
    } catch (e) { return false; }
  }

  /* ─── ANEIS DE DESTAQUE EM OVERLAY FIXO DE NIVEL SUPERIOR ── */

  function obterOverlayDestaque() {
    let overlay = document.getElementById(METASPY_OVERLAY_ID);
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = METASPY_OVERLAY_ID;
      overlay.setAttribute("aria-hidden", "true");
      overlay.style.cssText =
        "position:fixed; left:0; top:0; width:0; height:0; overflow:visible; " +
        "pointer-events:none; z-index:2147483647;";
      document.documentElement.appendChild(overlay);
    }
    return overlay;
  }

  function atualizarAnel(card) {
    const mapa = window.__metaspyAneis || (window.__metaspyAneis = new WeakMap());
    const ring = mapa.get(card);
    if (!ring) return;
    if (!card.isConnected) {
      ring.remove();
      mapa.delete(card);
      return;
    }
    const r = card.getBoundingClientRect();
    const visivel =
      r.width > 0 && r.height > 0 &&
      r.bottom > -50 && r.top < window.innerHeight + 50 &&
      r.right > -50 && r.left < window.innerWidth + 50;
    if (!visivel) {
      ring.style.display = "none";
      return;
    }
    ring.style.display = "block";
    ring.style.left = Math.round(r.left - 2) + "px";
    ring.style.top = Math.round(r.top - 2) + "px";
    ring.style.width = Math.max(4, Math.round(r.width + 4)) + "px";
    ring.style.height = Math.max(4, Math.round(r.height + 4)) + "px";
  }

  function atualizarTodosAneis() {
    const mapa = window.__metaspyAneis;
    if (!mapa) return 0;
    document.querySelectorAll(".metaspy-neon").forEach((card) => {
      if (!mapa.has(card)) aplicarAnelDestaque(card);
    });
    let ativos = 0;
    mapa.forEach((ring, card) => {
      if (!card.isConnected) {
        ring.remove();
        mapa.delete(card);
        return;
      }
      atualizarAnel(card);
      ativos++;
    });
    return ativos;
  }

  function agendarAtualizacaoAneis() {
    if (window.__metaspyRafAneis) return;
    window.__metaspyRafAneis = requestAnimationFrame(() => {
      window.__metaspyRafAneis = 0;
      try { atualizarTodosAneis(); } catch (e) { /* ignore */ }
    });
  }

  /* Loop contínuo em requestAnimationFrame: reposiciona e poda os anéis a cada
     frame. O React da Biblioteca remonta/reflowa cards sem disparar scroll —
     anel fixo parado na posição antiga vira "moldura fantasma" colada na tela.
     Com o loop, o anel acompanha o card mesmo durante a rolagem do usuário. */
  function ligarLoopAneis() {
    if (window.__metaspyLoopAneis) return;
    window.__metaspyLoopAneis = true;
    const passo = () => {
      window.__metaspyLoopAneis = false;
      try {
        if (atualizarTodosAneis() > 0) {
          window.__metaspyLoopAneis = true;
          requestAnimationFrame(passo);
        }
      } catch (e) { /* ignore */ }
    };
    requestAnimationFrame(passo);
  }

  function iniciarManutencaoAneis() {
    if (window.__metaspyManutencaoAneis) return;
    window.__metaspyManutencaoAneis = true;
    setInterval(() => {
      try { ligarLoopAneis(); } catch (e) { /* ignore */ }
    }, 1500);
  }

  /* Overlay de aneis desativado: o neon agora e o outline + glow desenhado no
     proprio card (via .metaspy-neon), que rola junto com o conteudo — sem
     "moldura fixa na tela" nem aneis-fantasma. Mantida como no-op para nao
     quebrar referencias existentes. */
  function aplicarAnelDestaque() { /* no-op */ }

  function destacarCard(card) {
    if (!card || !(card instanceof HTMLElement)) return;
    injetarEstilosAcoes();
    card.classList.add("metaspy-neon");
    card.style.position = "relative";
    injetarAcoesCard(card);
  }

  /* F2b: fixa (pina) as ofertas destacadas no topo do feed, ordenadas pelas
     mais escaladas (dias ativos primeiro, depois quantidade de anuncios). */
  function fixarOfertasNoTopo(rolarParaTopo = true) {
    const container = resolverContainerResultados();
    if (!container) return 0;
    const cards = Array.from(container.querySelectorAll(".metaspy-neon"))
      .filter((c) => container.contains(c));
    cards.sort((a, b) => {
      const da = extrairDiasAtivoCard(a);
      const ca = extrairQuantidadeAnunciosCard(a);
      const db = extrairDiasAtivoCard(b);
      const cb = extrairQuantidadeAnunciosCard(b);
      return (db - da) || (cb - ca);
    });
    for (let i = cards.length - 1; i >= 0; i--) {
      container.insertBefore(cards[i], container.firstChild);
      if (cards[i].classList.contains("metaspy-neon")) aplicarAnelDestaque(cards[i]);
    }
    if (rolarParaTopo && cards.length > 0) window.scrollTo(0, 0);
    return cards.length;
  }

  /* F2: scan engine compartilhado (widget e painel) — destaca cards que passam
     nos filtros de dias/copias minimos, com contador em tempo real. */
  async function destacarCards({ diasMin = 100, copiasMin = 5, onProgress = null, sinalParada = null, fixarNoTopo = false, rolagem = true }) {
    limparDestaques();
    const INICIO_MS = Date.now();
    let cardsEncontrados = 0;
    let cardsDestacados = 0;
    let alturaAnterior = document.body.scrollHeight || document.documentElement.scrollHeight;
    let scrollsSemCrescimento = 0;
    const maxScrolls = rolagem ? 40 : 1;
    const cardsVistos = new Set();
    let atrasoAtual = PAUSA_ROLAGEM_INICIAL_MS;

    /* A biblioteca faz lazy-load dos anuncios. Se a pagina ainda estiver
       carregando (readyState "interactive"), a primeira varredura pode nao
       achar nenhum card real e encerrar antes do conteudo montar. Espera
       ate aparecer sinal de anuncio antes de comecar a rolagem. */
    const inicioEsperaMs = Date.now();
    while (!(sinalParada && sinalParada())) {
      if (Date.now() - inicioEsperaMs > 8000) break;
      let qtd = 0;
      try { qtd = coletarCardsVisiveis().length; } catch (e) { qtd = 0; }
      if (qtd > 0) break;
      await aguardar(400);
    }

    for (let i = 0; i < maxScrolls; i++) {
      if (sinalParada && sinalParada()) break;
      if (Date.now() - INICIO_MS > TIMEOUT_VARREDURA_MS) break;

      const cards = coletarCardsVisiveis();
      cards.forEach((c) => {
        if (!cardsVistos.has(c)) {
          cardsVistos.add(c);
          cardsEncontrados++;
        }
        if (cardPassaFiltros(c, diasMin, copiasMin)) {
          try { destacarCard(c); } catch (erro) { console.error("[MetaSpy] Erro ao destacar card:", erro); }
          cardsDestacados = document.querySelectorAll(".metaspy-neon").length;
        }
      });

      /* F2b: pina no topo conforme forem encontradas (sem rolar ainda). */
      if (fixarNoTopo) fixarOfertasNoTopo(false);

      if (onProgress) onProgress({ cardsEncontrados, cardsDestacados });

      if (i >= maxScrolls - 1) break;

      if (!rolagem) break;

      window.scrollBy(0, INCREMENTO_SCROLL_PX);
      await aguardar(atrasoAtual);

      const alturaAtual = document.body.scrollHeight || document.documentElement.scrollHeight;
      if (alturaAtual <= alturaAnterior) {
        scrollsSemCrescimento++;
        atrasoAtual = Math.min(PAUSA_ROLAGEM_MAX_MS, atrasoAtual + 200);
      } else {
        scrollsSemCrescimento = 0;
        atrasoAtual = Math.max(PAUSA_ROLAGEM_INICIAL_MS, atrasoAtual - 100);
      }
      alturaAnterior = alturaAtual;

      if (scrollsSemCrescimento >= 4) break;
    }

    /* F2b: pin final no topo, ordenado pelas mais escaladas, e rola ao topo. */
    let fixados = 0;
    if (fixarNoTopo) fixados = fixarOfertasNoTopo(true);

    /* Re-forca o destaque apos o pinning: o React da biblioteca pode remontar
       os cards e remover classe/anel dos nos movidos — re-detectar e re-aplicar. */
    try {
      coletarCardsVisiveis().forEach((c) => {
        if (cardPassaFiltros(c, diasMin, copiasMin)) destacarCard(c);
      });
    } catch (e) { /* ignore */ }

    const totaisFinal = {
      cardsEncontrados,
      cardsDestacados: document.querySelectorAll(".metaspy-neon").length,
      fixados,
      duracaoMs: Date.now() - INICIO_MS
    };

    console.log("[MetaSpy] Scan concluido: " + totaisFinal.cardsEncontrados + " cards encontrados, " +
      totaisFinal.cardsDestacados + " destacados, " + fixados + " fixados no topo (" +
      (totaisFinal.duracaoMs / 1000).toFixed(1) + "s).");
    if (totaisFinal.cardsDestacados === 0 && totaisFinal.cardsEncontrados > 0) {
      console.warn("[MetaSpy] Nenhum card passou nos filtros (dias >= " + diasMin + " ou copias >= " +
        copiasMin + "). Reduza os sliders do widget para destacar mais ofertas.");
    }
    agendarAtualizacaoAneis();
    return totaisFinal;
  }

  /* F4: coleta todas as URLs de video dos cards atualmente detectados. */
  function coletarVideosVisiveis() {
    const videos = [];
    const vistos = new Set();
    coletarCardsVisiveis().forEach((card) => {
      const url = extrairVideoCard(card);
      if (url && urlVideoValida(url) && !vistos.has(url)) {
        vistos.add(url);
        const id = extrairIdDoElemento(card);
        videos.push({ url, adId: id || `card-${videos.length}` });
      }
    });
    return videos;
  }

  chrome.runtime.onMessage.addListener((mensagem, sender, sendResponse) => {
    try {
      if (mensagem?.acao === "pararVarredura" || mensagem?.acao === "pararBusca") {
        estado.parar = true;
        sendResponse({ ok: true });
        return true;
      }
      if (mensagem?.acao === "aplicarMoldura") {
        sendResponse({ ok: true });
        return true;
      }
      if (mensagem?.acao === "togglePainelMetaSpy") {
        criarPainelMetaSpy();
        var panel = document.querySelector("#" + METASPY_ID + " .ms-panel");
        var toggle = document.querySelector("#" + METASPY_ID + " .ms-toggle");
        var overlay = document.querySelector("#" + METASPY_ID + " .ms-overlay");
        if (panel && !panel.classList.contains("aberto")) {
          panel.classList.add("aberto");
          if (toggle) toggle.classList.add("aberto");
          if (overlay) overlay.classList.add("aberto");
          if (toggle) {
            var arrow = toggle.querySelector(".ms-arrow");
            if (arrow) arrow.textContent = "▶";
          }
        }
        sendResponse({ ok: true });
        return true;
      }

      if (mensagem?.acao === "diagnosticoMetaSpy") {
        const cards = coletarCardsVisiveis();
        sendResponse({
          ok: true,
          url: location.href,
          titulo: document.title,
          cardsDetectados: cards.length,
          anunciosDetectados: coletarAnunciosVisiveis("").length,
          bodyTextLength: String(document.body?.innerText || "").length
        });
        return true;
      }
      if (mensagem?.acao === "coletarAnunciosVisiveis") {
        const cards = coletarCardsVisiveis();
        sendResponse({
          ok: true,
          anuncios: coletarAnunciosVisiveis(mensagem.termo || ""),
          diagnostico: {
            cardsDetectados: cards.length,
            bodyTextLength: String(document.body?.innerText || "").length,
            url: location.href
          }
        });
        return true;
      }
      if (mensagem?.acao === "varrerBibliotecaCompleta") {
        estado.parar = false;
        varrerBibliotecaCompleta(mensagem.termo || "", mensagem.tempoMaximoMs || 0)
          .then((anuncios) =>
            sendResponse({
              ok: true,
              anuncios,
              diagnostico: {
                cardsDetectados: coletarCardsVisiveis().length,
                bodyTextLength: String(document.body?.innerText || "").length,
                url: location.href
              }
            })
          )
          .catch((erro) => sendResponse({ ok: false, erro: erro.message || "Falha na varredura da Biblioteca." }));
        return true;
      }
      if (mensagem?.acao === "extrairEBaixarVideo") {
        const videoUrl = mensagem.url || (function(){
          const el = document.querySelector("video[src]");
          return el ? extrairUrlVideo(el) : null;
        })();
        if (!videoUrl) {
          sendResponse({ ok: false, erro: "Nenhum video encontrado na pagina." });
          return true;
        }
        if (!urlVideoValida(videoUrl)) {
          sendResponse({ ok: false, erro: "URL do video nao pertence a um dominio confiavel." });
          return true;
        }
        sendResponse({ ok: true, videoUrl });
        return true;
      }
      if (mensagem?.acao === "extrairVideosPagina") {
        const videos = new Set();
        document.querySelectorAll("video").forEach(function(el){
          var u = extrairUrlVideo(el);
          if (u && urlVideoValida(u)) videos.add(u);
        });
        document.querySelectorAll("[data-video], [data-video-source], a[href*='.mp4'], a[href*='fbcdn']").forEach(function(el){
          var u = el.getAttribute("data-video") || el.getAttribute("data-video-source") || el.href || el.getAttribute("href");
          if (u && urlVideoValida(u)) videos.add(u);
        });
        if (!videos.size) {
          var html = document.body.innerHTML || "";
          var matches = html.matchAll(/(https?:\/\/[^"'\s]+fbcdn[^"'\s]*\.mp4[^"'\s]*)/g);
          for (var m of matches) { if (urlVideoValida(m[1])) videos.add(m[1]); }
        }
        // Also check video elements that might be inside shadow DOM or dynamic inserts
        document.querySelectorAll('[class*="x1c"], [class*="x1q"], [role="dialog"], [role="presentation"]').forEach(function(container){
          var v = container.querySelector("video");
          if (v) {
            var u = extrairUrlVideo(v);
            if (u && urlVideoValida(u)) videos.add(u);
          }
        });
        sendResponse({ ok: true, videos: Array.from(videos) });
        return true;
      }
      if (mensagem?.acao === "aguardarVideoPagina") {
        var timeout = Math.min(Number(mensagem.timeout) || 20000, 30000);
        var inicio = Date.now();
        var encontrou = false;

        function verificarVideo() {
          var els = document.querySelectorAll("video");
          for (var i = 0; i < els.length; i++) {
            var u = extrairUrlVideo(els[i]);
            if (u && urlVideoValida(u)) return u;
          }
          return null;
        }

        var jaTem = verificarVideo();
        if (jaTem) {
          sendResponse({ ok: true, videoUrl: jaTem });
          return true;
        }

        var timer = setInterval(function(){
          var r = verificarVideo();
          if (r) {
            clearInterval(timer);
            sendResponse({ ok: true, videoUrl: r });
          } else if (Date.now() - inicio > timeout) {
            clearInterval(timer);
            sendResponse({ ok: false, erro: "Nenhum video encontrado na pagina apos aguardar." });
          }
        }, 800);
        return true;
      }
      if (mensagem?.acao === "coletarVideosVisiveis") {
        sendResponse({ ok: true, videos: coletarVideosVisiveis() });
        return true;
      }
      sendResponse({ ok: false, erro: "Acao nao suportada no content script." });
      return true;
    } catch (erro) {
      console.error("MetaSpy: Erro ao processar mensagem no content script:", erro);
      sendResponse({ ok: false, erro: erro.message || "Erro inesperado." });
      return true;
    }
  });

  /* ─── DOWNLOAD DE VIDEO ──────────────────────────── */

  const VIDEO_SELETORES = [
    "video[src]",
    "video source[src]",
    "[role='dialog'] video",
    "[role='presentation'] video",
    ".x1lliihq video",
    ".x5yr21d video",
    '[class*="x1c"] video',
    '[class*="x1q"] video'
  ];

  function extrairUrlVideo(elementoVideo) {
    if (!elementoVideo) return null;
    return (
      elementoVideo.currentSrc ||
      elementoVideo.src ||
      elementoVideo.getAttribute("src") ||
      elementoVideo.getAttribute("data-src") ||
      elementoVideo.querySelector("source")?.src ||
      elementoVideo.querySelector("source")?.getAttribute("src") ||
      null
    );
  }

  function urlVideoValida(url) {
    if (!url || typeof url !== "string") return false;
    try {
      const u = new URL(url);
      const permitidos = [
        "facebook.com", "www.facebook.com", "video.facebook.com",
        "fbcdn.net", "video.fbcdn.net", "scontent.f",
        "cdn.fbsbx.com", "lookaside.fbsbx.com",
        "cdninstagram.com", "video.instagram.com"
      ];
      return permitidos.some((d) => u.hostname === d || u.hostname.endsWith("." + d));
    } catch { return false; }
  }

  async function baixarVideoComoBlob(videoUrl, nomeArquivo) {
    if (!urlVideoValida(videoUrl)) {
      throw new Error("URL de video invalida. Permitido apenas dominios do Facebook.");
    }
    const resposta = await fetch(videoUrl, {
      credentials: "include",
      headers: { "Range": "bytes=0-" }
    });
    if (!resposta.ok && resposta.status !== 206) {
      throw new Error(`HTTP ${resposta.status}`);
    }
    const blob = await resposta.blob();
    const extensao = blob.type.includes("mp4") ? ".mp4" : blob.type.includes("webm") ? ".webm" : ".mp4";
    const nomeFinal = nomeArquivo || `metaspy_video_${Date.now()}${extensao}`;
    const urlObj = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = urlObj;
    a.download = nomeFinal.endsWith(".mp4") || nomeFinal.endsWith(".webm") ? nomeFinal : nomeFinal + extensao;
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(urlObj), 60000);
    return nomeFinal;
  }

  function criarBotaoDownload(video) {
    const container =
      video.closest('[class*="x1lliihq"], [class*="x5yr21d"], [role="dialog"], [role="presentation"]') ||
      video.parentElement;
    if (!container || container.querySelector(".metaspy-dl-btn")) return;

    container.style.position = container.style.position || "relative";

    const btn = document.createElement("button");
    btn.className = "metaspy-dl-btn";
    btn.textContent = "Baixar video";
    Object.assign(btn.style, {
      position: "absolute",
      bottom: "60px",
      right: "12px",
      zIndex: "9999",
      padding: "8px 14px",
      background: "rgba(157, 78, 221, 0.92)",
      color: "#fff",
      border: "1px solid rgba(199, 125, 255, 0.6)",
      borderRadius: "8px",
      cursor: "pointer",
      fontSize: "12px",
      fontWeight: "600",
      fontFamily: "Arial, sans-serif",
      boxShadow: "0 2px 12px rgba(0,0,0,0.4)",
      transition: "background 0.2s"
    });

    btn.addEventListener("mouseenter", () => {
      btn.style.background = "rgba(124, 58, 237, 0.95)";
    });
    btn.addEventListener("mouseleave", () => {
      btn.style.background = "rgba(157, 78, 221, 0.92)";
    });

    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      e.preventDefault();

      const videoUrl = extrairUrlVideo(video);
      if (!videoUrl) {
        btn.textContent = "Sem URL";
        setTimeout(() => { btn.textContent = "Baixar video"; }, 2000);
        return;
      }

      const adId = location.href.match(/[?&]id=(\d+)/)?.[1] || "video";
      btn.textContent = "Baixando...";
      btn.disabled = true;

      try {
        await baixarVideoComoBlob(videoUrl, `metaspy_video_${adId}_${Date.now()}.mp4`);
        btn.textContent = "OK";
        setTimeout(() => {
          btn.textContent = "Baixar video";
          btn.disabled = false;
        }, 3000);
      } catch (erro) {
        btn.textContent = "Erro";
        setTimeout(() => {
          btn.textContent = "Baixar video";
          btn.disabled = false;
        }, 3000);
      }
    });

    container.appendChild(btn);
  }

  function injetarBotoesVideo() {
    document.querySelectorAll(VIDEO_SELETORES.join(",")).forEach((el) => {
      const video = el.tagName === "VIDEO" ? el : el.querySelector("video");
      if (video && !video.hasAttribute("data-metaspy-dl")) {
        video.setAttribute("data-metaspy-dl", "true");
        criarBotaoDownload(video);
      }
    });
  }

  let _videoTimer = null;
  const videoObserver = new MutationObserver(() => {
    if (_videoTimer) clearTimeout(_videoTimer);
    _videoTimer = setTimeout(injetarBotoesVideo, 400);
  });
  videoObserver.observe(document.body, { childList: true, subtree: true });

  let tentativasVideo = 0;
  function tentarInjetarVideo() {
    injetarBotoesVideo();
    if (tentativasVideo < 8 && !document.querySelector(".metaspy-dl-btn")) {
      tentativasVideo++;
      setTimeout(tentarInjetarVideo, 1200);
    }
  }
  setTimeout(tentarInjetarVideo, 800);

  /* ─── PAINEL FLUTUANTE METASPY ──────────────────── */

  const METASPY_ID = "metaspy-root";

  function criarPainelMetaSpy() {
    if (document.getElementById(METASPY_ID)) return;

    var root = document.createElement("div");
    root.id = METASPY_ID;

    var css = document.createElement("style");
    css.textContent = [
      "#" + METASPY_ID + " * { margin:0; padding:0; box-sizing:border-box; }",
      "#" + METASPY_ID + " { all:initial; position:fixed; top:0; right:0; width:430px; height:100vh; z-index:999997; font-family:system-ui,sans-serif; }",
      "#" + METASPY_ID + " .ms-overlay { position:fixed; inset:0; z-index:999997; background:rgba(0,0,0,0.3); opacity:0; pointer-events:none; transition:opacity 0.3s ease; }",
      "#" + METASPY_ID + " .ms-overlay.aberto { opacity:1; pointer-events:auto; }",
      "#" + METASPY_ID + " .ms-panel { position:fixed; top:0; right:0; width:430px; height:100vh; z-index:999998; background:#0a0a0a; border-radius:16px 0 0 16px; overflow:hidden; box-shadow:-4px 0 25px rgba(0,0,0,0.5); transform:translateX(100%); transition:transform 0.35s cubic-bezier(0.4,0,0.2,1); }",
      "#" + METASPY_ID + " .ms-panel.aberto { transform:translateX(0); }",
      "#" + METASPY_ID + " .ms-panel iframe { width:100%; height:100%; border:none; background:transparent; }",
      "#" + METASPY_ID + " .ms-handle { position:absolute; left:0; top:0; bottom:0; width:7px; cursor:ew-resize; z-index:999999; background:transparent; transition:background 0.15s; }",
      "#" + METASPY_ID + " .ms-handle:hover { background:rgba(139, 92, 246, 0.25); }",
      "#" + METASPY_ID + " .ms-handle.arrastando { background:rgba(139, 92, 246, 0.35); }",
      "#" + METASPY_ID + " .ms-toggle { position:fixed; right:0; top:50%; transform:translateY(-50%); z-index:999999; width:36px; height:60px; background:linear-gradient(135deg,#7c3aed,#8b5cf6); border:none; border-radius:8px 0 0 8px; cursor:pointer; display:flex; align-items:center; justify-content:center; box-shadow:-2px 2px 12px rgba(124, 58, 237, 0.4); transition:right 0.2s ease,transform 0.2s ease; user-select:none; }",
      "#" + METASPY_ID + " .ms-toggle:hover { right:4px; }",
      "#" + METASPY_ID + " .ms-toggle .ms-arrow { color:#fff; font-size:18px; font-weight:700; line-height:1; transition:transform 0.35s cubic-bezier(0.4,0,0.2,1); }",
      "#" + METASPY_ID + " .ms-toggle.aberto .ms-arrow { transform:rotate(180deg); }"
    ].join("\n");

    root.appendChild(css);

    var overlay = document.createElement("div");
    overlay.className = "ms-overlay";
    root.appendChild(overlay);

    var panel = document.createElement("div");
    panel.className = "ms-panel";

    /* U5: restaura largura persistida do painel. */
    chrome.storage.local.get(["metaspy_panelWidth"], function (stored) {
      const largura = Number(stored && stored.metaspy_panelWidth);
      if (largura >= 340 && largura <= 640) {
        panel.style.width = largura + "px";
      }
    });

    var iframe = document.createElement("iframe");
    iframe.src = chrome.runtime.getURL("popup.html");
    iframe.setAttribute("allowtransparency", "true");
    iframe.title = "MetaSpy";
    panel.appendChild(iframe);

    /* U5: arrastar borda esquerda para redimensionar. */
    var handle = document.createElement("div");
    handle.className = "ms-handle";
    handle.title = "Arraste para redimensionar";
    handle.addEventListener("mousedown", function (evInicio) {
      evInicio.preventDefault();
      handle.classList.add("arrastando");
      var larguraInicio = panel.getBoundingClientRect().width;
      function aoMover(ev) {
        var novaLargura = Math.max(340, Math.min(640, larguraInicio + (evInicio.clientX - ev.clientX)));
        panel.style.width = novaLargura + "px";
      }
      function aoSoltar() {
        handle.classList.remove("arrastando");
        document.removeEventListener("mousemove", aoMover);
        document.removeEventListener("mouseup", aoSoltar);
        var final = panel.getBoundingClientRect().width;
        chrome.storage.local.set({ metaspy_panelWidth: Math.round(final) }).catch(() => {});
      }
      document.addEventListener("mousemove", aoMover);
      document.addEventListener("mouseup", aoSoltar);
    });
    panel.appendChild(handle);
    root.appendChild(panel);

    var toggle = document.createElement("button");
    toggle.className = "ms-toggle";
    toggle.setAttribute("aria-label", "Abrir/Fechar MetaSpy");
    var arrow = document.createElement("span");
    arrow.className = "ms-arrow";
    arrow.textContent = "\u25C0";
    toggle.appendChild(arrow);
    root.appendChild(toggle);

    function alternarPainel() {
      var aberto = panel.classList.toggle("aberto");
      toggle.classList.toggle("aberto", aberto);
      overlay.classList.toggle("aberto", aberto);
      arrow.textContent = aberto ? "\u25B6" : "\u25C0";
    }

    toggle.addEventListener("click", alternarPainel);
    overlay.addEventListener("click", alternarPainel);

    document.documentElement.appendChild(root);

    if (window.__metaspyPainelObserver) {
      window.__metaspyPainelObserver.disconnect();
    }
    var observerPainel = new MutationObserver(function () {
      if (!document.getElementById(METASPY_ID)) {
        criarPainelMetaSpy();
      }
    });
    observerPainel.observe(document.documentElement, { childList: true });
    window.__metaspyPainelObserver = observerPainel;
  }

  /* ─── OVERLAY TOP BAR NA PÁGINA ──────────────────── */

  const METASPY_TOP_ID = "metaspy-topbar";

  function criarTopBarMetaSpy() {
    if (document.getElementById(METASPY_TOP_ID)) return;

    var paisAtual = new URLSearchParams(location.search).get("country") || "ALL";
    var ordenarAtual = new URLSearchParams(location.search).get("sort") || "recent";
    var estadoScan = { rodando: false, parar: false, cardsEncontrados: 0, cardsDestacados: 0 };

    var root = document.createElement("div");
    root.id = METASPY_TOP_ID;

    var css = document.createElement("style");
    css.textContent = [
      "#" + METASPY_TOP_ID + " * { margin:0; padding:0; box-sizing:border-box; }",
      "#" + METASPY_TOP_ID + " { all:initial; position:fixed; top:0; left:0; right:0; z-index:999995; font-family:system-ui,sans-serif; }",
      "#" + METASPY_TOP_ID + " .ms-topbar { display:flex; align-items:center; gap:8px; padding:6px 12px; background:rgba(10,10,15,0.92); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); border-bottom:1px solid rgba(139, 92, 246,0.25); flex-wrap:wrap; min-height:42px; }",
      "#" + METASPY_TOP_ID + " .ms-topbar-logo { display:flex; align-items:center; gap:6px; color:#8b5cf6; font-weight:700; font-size:13px; white-space:nowrap; }",
      "#" + METASPY_TOP_ID + " .ms-topbar-logo svg { flex-shrink:0; }",
      "#" + METASPY_TOP_ID + " .ms-topbar select { padding:4px 8px; border-radius:6px; border:1px solid rgba(139, 92, 246,0.3); background:rgba(20,20,30,0.9); color:#e5e5e5; font-size:11px; font-family:inherit; cursor:pointer; outline:none; }",
      "#" + METASPY_TOP_ID + " .ms-topbar select:focus { border-color:#8b5cf6; }",
      "#" + METASPY_TOP_ID + " .ms-topbar input { width:50px; padding:4px 6px; border-radius:6px; border:1px solid rgba(139, 92, 246,0.3); background:rgba(20,20,30,0.9); color:#e5e5e5; font-size:11px; font-family:inherit; outline:none; }",
      "#" + METASPY_TOP_ID + " .ms-topbar input:focus { border-color:#8b5cf6; }",
      "#" + METASPY_TOP_ID + " .ms-topbar label { display:flex; align-items:center; gap:4px; color:#9ca3af; font-size:11px; white-space:nowrap; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-btn { padding:5px 12px; border-radius:6px; border:1px solid rgba(139, 92, 246,0.25); background:transparent; color:#9ca3af; font-size:11px; font-weight:500; font-family:inherit; cursor:pointer; transition:all 0.15s; white-space:nowrap; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-btn:hover { border-color:rgba(139, 92, 246,0.5); color:#e5e5e5; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-btn.primario { background:linear-gradient(135deg,#7c3aed,#8b5cf6); color:#fff; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-btn.primario:hover { box-shadow:0 0 16px rgba(139, 92, 246,0.4); }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-btn.primario:disabled { opacity:0.5; cursor:default; box-shadow:none; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-btn.perigo { background:rgba(255, 32, 32,0.85); color:#fff; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-btn.perigo:hover { background:rgba(255, 32, 32,1); }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-status { color:#9ca3af; font-size:11px; margin-left:auto; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-fechar { flex-shrink:0; width:24px; height:24px; display:flex; align-items:center; justify-content:center; border:none; background:rgba(255,255,255,0.05); color:#9ca3af; border-radius:4px; cursor:pointer; font-size:14px; line-height:1; transition:all 0.12s; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-fechar:hover { background:rgba(255,255,255,0.12); color:#fff; }",
      "#" + METASPY_TOP_ID + ".ms-oculto { display:none !important; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-status .ms-destaque { color:#8b5cf6; font-weight:600; }",
      "#" + METASPY_TOP_ID + " .ms-topbar .ms-separador { width:1px; height:20px; background:rgba(139, 92, 246,0.2); flex-shrink:0; }",
      /* neon: card limpo — o anel pulsante e o overlay (#metaspy-overlay-ring) */
      ".metaspy-neon { position:relative !important; border-radius:12px !important; }",
      /* banter loader animation */
      "@keyframes banterMove1 { 9.09% { transform:translate(-5px,0); } 18.18% { transform:translate(0,0); } 36.36% { transform:translate(5px,0); } 45.45% { transform:translate(5px,5px); } 72.73% { transform:translate(5px,0); } 81.82% { transform:translate(0,0); } 90.91% { transform:translate(-5px,0); } 100% { transform:translate(0,0); } }",
      "@keyframes banterMove2 { 18.18% { transform:translate(5px,0); } 27.27% { transform:translate(0,0); } 36.36% { transform:translate(5px,0); } 45.45% { transform:translate(5px,5px); } 81.82% { transform:translate(0,5px); } 90.91% { transform:translate(0,5px); } 100% { transform:translate(0,0); } }",
      "@keyframes banterMove3 { 9.09% { transform:translate(-5px,0); } 18.18% { transform:translate(-5px,0); } 27.27% { transform:translate(0,0); } 36.36% { transform:translate(-5px,0); } 81.82% { transform:translate(-10px,0); } 90.91% { transform:translate(-5px,0); } 100% { transform:translate(0,0); } }",
      "@keyframes banterMove4 { 9.09% { transform:translate(-5px,0); } 18.18% { transform:translate(-5px,0); } 27.27% { transform:translate(-5px,-5px); } 36.36% { transform:translate(0,-5px); } 45.45% { transform:translate(0,0); } 54.55% { transform:translate(0,-5px); } 81.82% { transform:translate(5px,-5px); } 90.91% { transform:translate(5px,0); } 100% { transform:translate(0,0); } }",
      "@keyframes banterMove5 { 36.36% { transform:translate(5px,0); } 81.82% { transform:translate(5px,-5px); } 90.91% { transform:translate(0,-5px); } 100% { transform:translate(0,0); } }",
      "@keyframes banterMove6 { 9.09% { transform:translate(0,0); } 18.18% { transform:translate(-5px,0); } 27.27% { transform:translate(-5px,0); } 36.36% { transform:translate(0,0); } 72.73% { transform:translate(0,5px); } 81.82% { transform:translate(-5px,5px); } 90.91% { transform:translate(-5px,0); } 100% { transform:translate(0,0); } }",
      "@keyframes banterMove7 { 9.09% { transform:translate(5px,0); } 18.18% { transform:translate(5px,0); } 27.27% { transform:translate(5px,0); } 36.36% { transform:translate(0,0); } 45.45% { transform:translate(0,-5px); } 54.55% { transform:translate(5px,-5px); } 63.64% { transform:translate(0,-5px); } 81.82% { transform:translate(0,0); } 90.91% { transform:translate(5px,0); } 100% { transform:translate(0,0); } }",
      "@keyframes banterMove8 { 18.18% { transform:translate(-5px,0); } 27.27% { transform:translate(-5px,-5px); } 36.36% { transform:translate(0,-5px); } 81.82% { transform:translate(5px,-5px); } 90.91% { transform:translate(5px,0); } 100% { transform:translate(0,0); } }",
      "@keyframes banterMove9 { 9.09% { transform:translate(-5px,0); } 18.18% { transform:translate(-5px,0); } 27.27% { transform:translate(0,0); } 36.36% { transform:translate(-5px,0); } 45.45% { transform:translate(0,0); } 63.64% { transform:translate(-5px,0); } 72.73% { transform:translate(-5px,0); } 81.82% { transform:translate(-10px,0); } 90.91% { transform:translate(-5px,0); } 100% { transform:translate(0,0); } }",
      /* botoes flutuantes dentro do card */
      ".metaspy-card-actions { position:absolute; top:6px; right:6px; display:flex; gap:4px; z-index:99; }",
      ".metaspy-card-actions button { padding:4px 10px; border:none; border-radius:5px; background:rgba(10,10,15,0.88); color:#8b5cf6; cursor:pointer; font-size:10px; font-weight:600; font-family:system-ui,sans-serif; transition:all 0.12s; backdrop-filter:blur(4px); -webkit-backdrop-filter:blur(4px); }",
      ".metaspy-card-actions button:hover { background:#8b5cf6; color:#fff; }",
      ".metaspy-card-actions .ms-dl { color:#34d399; }",
      ".metaspy-card-actions .ms-dl:hover { background:#34d399; color:#fff; }"
    ].join("\n");
    root.appendChild(css);

    var barra = document.createElement("div");
    barra.className = "ms-topbar";

    /* Logo */
    var logo = document.createElement("div");
    logo.className = "ms-topbar-logo";
    logo.innerHTML = '<div style="display:inline-flex;flex-wrap:wrap;width:15px;height:15px;gap:1px;"><div style="width:4px;height:4px;background:#8b5cf6;border-radius:1px;animation:banterMove1 4s infinite;"></div><div style="width:4px;height:4px;background:#8b5cf6;border-radius:1px;animation:banterMove2 4s infinite;"></div><div style="width:4px;height:4px;background:#8b5cf6;border-radius:1px;animation:banterMove3 4s infinite;"></div><div style="width:4px;height:4px;background:#8b5cf6;border-radius:1px;animation:banterMove4 4s infinite;"></div><div style="width:4px;height:4px;background:#8b5cf6;border-radius:1px;animation:banterMove5 4s infinite;"></div><div style="width:4px;height:4px;background:#8b5cf6;border-radius:1px;animation:banterMove6 4s infinite;"></div><div style="width:4px;height:4px;background:#8b5cf6;border-radius:1px;animation:banterMove7 4s infinite;"></div><div style="width:4px;height:4px;background:#8b5cf6;border-radius:1px;animation:banterMove8 4s infinite;"></div><div style="width:4px;height:4px;background:#8b5cf6;border-radius:1px;animation:banterMove9 4s infinite;"></div></div><span><span style="color:#fff;font-style:italic;">Meta</span><span style="color:#8b5cf6;font-weight:700;">Spy</span></span>';
    barra.appendChild(logo);

    barra.appendChild(criarSeparador());

    /* Pais */
    var labelPais = document.createElement("label");
    labelPais.textContent = "País";
    var selPais = document.createElement("select");
    var paises = [["ALL","Todos"],["BR","Brasil"],["US","EUA"],["PT","Portugal"],["MX","México"],["AR","Argentina"],["CL","Chile"],["CO","Colômbia"],["ES","Espanha"]];
    paises.forEach(function(p){ var o=document.createElement("option"); o.value=p[0]; o.textContent=p[1]; if(p[0]===paisAtual) o.selected=true; selPais.appendChild(o); });
    selPais.addEventListener("change", function(){
      var url = new URL(location.href);
      url.searchParams.set("country", selPais.value);
      location.href = url.href;
    });
    labelPais.appendChild(selPais);
    barra.appendChild(labelPais);

    barra.appendChild(criarSeparador());

    /* Ordenar */
    var labelOrd = document.createElement("label");
    labelOrd.textContent = "Ordenar";
    var selOrd = document.createElement("select");
    var ordens = [["recent","Mais recente"],["active_time","Maior tempo de atividade"]];
    ordens.forEach(function(o){ var opt=document.createElement("option"); opt.value=o[0]; opt.textContent=o[1]; if(o[0]===ordenarAtual) opt.selected=true; selOrd.appendChild(opt); });
    selOrd.addEventListener("change", function(){
      var url = new URL(location.href);
      url.searchParams.set("sort", selOrd.value);
      location.href = url.href;
    });
    labelOrd.appendChild(selOrd);
    barra.appendChild(labelOrd);

    barra.appendChild(criarSeparador());

    /* Dias minimos */
    var labelDias = document.createElement("label");
    labelDias.textContent = "Min dias";
    var inpDias = document.createElement("input");
    inpDias.type = "number";
    inpDias.min = "0";
    inpDias.max = "9999";
    inpDias.value = "30";
    labelDias.appendChild(inpDias);
    barra.appendChild(labelDias);

    /* Copias minimas */
    var labelCopias = document.createElement("label");
    labelCopias.textContent = "Min cópias";
    var inpCopias = document.createElement("input");
    inpCopias.type = "number";
    inpCopias.min = "1";
    inpCopias.max = "999";
    inpCopias.value = "5";
    labelCopias.appendChild(inpCopias);
    barra.appendChild(labelCopias);

    barra.appendChild(criarSeparador());

    /* Botoes */
    var btnIniciar = document.createElement("button");
    btnIniciar.className = "ms-btn primario";
    btnIniciar.textContent = "Varredura";
    barra.appendChild(btnIniciar);

    var btnParar = document.createElement("button");
    btnParar.className = "ms-btn perigo";
    btnParar.textContent = "Parar";
    btnParar.style.display = "none";
    barra.appendChild(btnParar);

    var btnLimpar = document.createElement("button");
    btnLimpar.className = "ms-btn";
    btnLimpar.textContent = "Limpar";
    btnLimpar.addEventListener("click", function(){ limparDestaques(); });
    barra.appendChild(btnLimpar);

    /* Status */
    var statusEl = document.createElement("div");
    statusEl.className = "ms-status";
    statusEl.innerHTML = '0 cards — <span class="ms-destaque">0</span> destacados';
    barra.appendChild(statusEl);

    /* Fechar */
    var btnFechar = document.createElement("button");
    btnFechar.className = "ms-fechar";
    btnFechar.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
    btnFechar.title = "Fechar barra MetaSpy";
    btnFechar.addEventListener("click", function(){ root.classList.add("ms-oculto"); });
    barra.appendChild(btnFechar);

    root.appendChild(barra);
    document.documentElement.appendChild(root);

    function criarSeparador() {
      var s = document.createElement("div");
      s.className = "ms-separador";
      return s;
    }

    function limparDestaques() {
      document.querySelectorAll(".metaspy-neon").forEach(function(el){
        el.classList.remove("metaspy-neon");
        el.style.position = "";
      });
      document.querySelectorAll(".metaspy-card-actions").forEach(function(el){ el.remove(); });
      estadoScan.cardsDestacados = 0;
      estadoScan.cardsEncontrados = 0;
      atualizarStatus();
    }

    function atualizarStatus() {
      statusEl.innerHTML = estadoScan.cardsEncontrados + ' cards — <span class="ms-destaque">' + estadoScan.cardsDestacados + '</span> destacados';
    }

    function cardPassaFiltros(card) {
      try {
        var texto = String(card.innerText || "").replace(/\s+/g, " ").trim();
        var diasMin = parseInt(inpDias.value) || 100;
        var copiasMin = parseInt(inpCopias.value) || 5;
        var diasAtivo = extrairDiasAtivoCard(card);
        var quantAnuncios = extrairQuantidadeAnunciosCard(card);
        if (diasAtivo >= diasMin) return true;
        if (quantAnuncios >= copiasMin) return true;
        return false;
      } catch (e) { return false; }
    }

    function destacarCard(card) {
      if (!card || card.classList.contains("metaspy-neon")) return;
      card.classList.add("metaspy-neon");
      card.style.position = "relative";
      estadoScan.cardsDestacados++;

      var actions = document.createElement("div");
      actions.className = "metaspy-card-actions";

      /* Detalhes */
      var btnDet = document.createElement("button");
      btnDet.textContent = "Detalhes";
      btnDet.addEventListener("click", function(e){
        e.stopPropagation();
        var id = extrairIdDoElemento(card);
        if (id) window.open("https://www.facebook.com/ads/library/?id=" + id, "_blank");
      });
      actions.appendChild(btnDet);

      /* Página de Vendas */
      var urlDest = extrairUrlDestinoCard(card);
      if (urlDest) {
        var btnVendas = document.createElement("button");
        btnVendas.textContent = "Página de Vendas";
        btnVendas.addEventListener("click", function(e){
          e.stopPropagation();
          window.open(urlDest, "_blank");
        });
        actions.appendChild(btnVendas);
      }

      /* Download criativo */
      var vUrlCard = extrairVideoCard(card);
      var imgCard = card.querySelector("img");
      if (vUrlCard || imgCard) {
        var btnDL = document.createElement("button");
        btnDL.className = "ms-dl";
        btnDL.textContent = vUrlCard ? "Baixar Video" : "Baixar Imagem";
        btnDL.addEventListener("click", function(e){
          e.stopPropagation();
          var adId = location.href.match(/[?&]id=(\d+)/)?.[1] || "card";
          if (vUrlCard) {
            baixarVideoComoBlob(vUrlCard, "metaspy_video_" + adId + "_" + Date.now() + ".mp4");
          } else if (imgCard) {
            var iUrl = imgCard.currentSrc || imgCard.src || imgCard.getAttribute("data-src") || "";
            if (iUrl) {
              var a = document.createElement("a");
              a.href = iUrl;
              a.download = "metaspy_img_" + adId + ".jpg";
              a.click();
            }
          }
        });
        actions.appendChild(btnDL);
      }

      card.appendChild(actions);
    }

    async function executarVarredura() {
      if (estadoScan.rodando) return;
      estadoScan.rodando = true;
      estadoScan.parar = false;
      estadoScan.cardsEncontrados = 0;
      estadoScan.cardsDestacados = 0;
      btnIniciar.disabled = true;
      btnIniciar.textContent = "Escaneando...";
      btnParar.style.display = "";
      limparDestaques();

      var alturaAnterior = document.body.scrollHeight || document.documentElement.scrollHeight;
      var scrollsSemCrescimento = 0;
      var maxScrolls = 40;

      var cardsVistos = new Set();

      for (var i = 0; i < maxScrolls && !estadoScan.parar; i++) {
        var cards = coletarCardsVisiveis();
        cards.forEach(function(c){
          if (!cardsVistos.has(c)) {
            cardsVistos.add(c);
            estadoScan.cardsEncontrados++;
          }
          if (cardPassaFiltros(c)) {
            destacarCard(c);
          }
        });

        atualizarStatus();

        if (i >= maxScrolls - 1) break;

        window.scrollBy(0, 800);
        await aguardar(1800);

        var alturaAtual = document.body.scrollHeight || document.documentElement.scrollHeight;
        if (alturaAtual <= alturaAnterior) {
          scrollsSemCrescimento++;
        } else {
          scrollsSemCrescimento = 0;
        }
        alturaAnterior = alturaAtual;

        if (scrollsSemCrescimento >= 4) break;
      }

      estadoScan.rodando = false;
      btnIniciar.disabled = false;
      btnIniciar.textContent = "Varredura";
      btnParar.style.display = "none";
      statusEl.innerHTML = 'Pronto — <span class="ms-destaque">' + estadoScan.cardsDestacados + '</span> cards destacados';
    }

    btnIniciar.addEventListener("click", executarVarredura);
    btnParar.addEventListener("click", function(){ estadoScan.parar = true; });

    if (window.__metaspyTopObserver) {
      window.__metaspyTopObserver.disconnect();
    }
    var observerTop = new MutationObserver(function(){
      if (!document.getElementById(METASPY_TOP_ID)) {
        criarTopBarMetaSpy();
      }
    });
    observerTop.observe(document.documentElement, { childList: true });
    window.__metaspyTopObserver = observerTop;
  }

  function tentarIniciarOverlay() {
    /* F2: a antiga topbar fixa foi removida — o widget flutuante (#metaspy-widget)
       e injetado por widget.js, mantendo os mesmos controles de scan. */
  }

  function injetarEstilosAcoes() {
    if (document.getElementById("metaspy-acoes-css")) return;
    const css = document.createElement("style");
    css.id = "metaspy-acoes-css";
    css.textContent = [
      ".metaspy-neon { position:relative !important; border-radius:12px !important; outline:3px solid rgba(139,92,246,0.9) !important; outline-offset:-1px; animation:metaspyPulse 1.6s ease-in-out infinite; }",
      "@keyframes metaspyPulse { 0%,100% { box-shadow:0 0 10px rgba(139,92,246,0.45), 0 0 22px rgba(139,92,246,0.22), inset 0 0 10px rgba(139,92,246,0.08); outline-color:rgba(139,92,246,0.6); } 50% { box-shadow:0 0 22px rgba(139,92,246,0.85), 0 0 46px rgba(139,92,246,0.35), inset 0 0 18px rgba(139,92,246,0.15); outline-color:rgba(139,92,246,1); } }",
      ".metaspy-card-actions { position:absolute; top:6px; right:6px; display:flex; gap:4px; z-index:99; }",
      ".metaspy-card-actions button { padding:4px 10px; border:none; border-radius:5px; background:rgba(10,10,15,0.88); color:#8b5cf6; cursor:pointer; font-size:10px; font-weight:600; font-family:system-ui,sans-serif; transition:all 0.12s; backdrop-filter:blur(4px); -webkit-backdrop-filter:blur(4px); }",
      ".metaspy-card-actions button:hover { background:#8b5cf6; color:#fff; }",
      ".metaspy-card-actions .ms-dl { color:#34d399; }",
      ".metaspy-card-actions .ms-dl:hover { background:#34d399; color:#fff; }",
      ".metaspy-card-actions .ms-zap { background:#25D366; color:#05320f; }",
      ".metaspy-card-actions .ms-zap:hover { background:#1eb857; color:#05320f; }",
      ".metaspy-card-actions .ms-rec { background:rgba(37,211,102,0.16); color:#25D366; border:1px solid rgba(37,211,102,0.4); }",
      ".metaspy-card-actions .ms-rec:hover { background:#25D366; color:#05320f; }",
      ".metaspy-card-actions button:disabled { opacity:0.6; cursor:progress; }"
    ].join("\n");
    document.documentElement.appendChild(css);
  }

  setTimeout(function(){
    try { criarPainelMetaSpy(); } catch (e) { console.error("MetaSpy: falha ao criar painel:", e); }
    injetarEstilosAcoes();
    iniciarManutencaoAneis();
    setTimeout(tentarIniciarOverlay, 2000);
  }, 1500);

  window.addEventListener("popstate", function(){
    setTimeout(tentarIniciarOverlay, 1000);
  });

  /* Mantem os aneis de destaque colados nos cards durante scroll/resize. */
  window.addEventListener("scroll", agendarAtualizacaoAneis, true);
  window.addEventListener("resize", agendarAtualizacaoAneis);

  /* Globals para o monkey-patch do orchestrator.js (status ativo/inativo) e
     para o scan compartilhado (widget.js F2 + painel). */
  window.cardPareceAtivo = cardPareceAtivo;
  window.coletarCardsVisiveis = coletarCardsVisiveis;
  window.coletarAnunciosVisiveis = coletarAnunciosVisiveis;

  window.MetaSpyScan = {
    coletarCardsVisiveis,
    coletarAnunciosVisiveis,
    coletarAnunciosDestacados,
    varrerBibliotecaCompleta,
    coletarVideosVisiveis,
    destacarCards,
    destacarCard,
    limparDestaques,
    fixarOfertasNoTopo,
    cardPassaFiltros,
    injetarAcoesCard,
    extrairDiasAtivoCard,
    extrairQuantidadeAnunciosCard,
    extrairIdDoElemento,
    extrairUrlDestinoCard,
    extrairVideoCard,
    urlVideoValida,
    resolverContainerResultados,
    estado,
    getInicioVarreduraMs: () => inicioVarreduraMs
  };
})();
